# Simple Java Docs Pipeline

An AI-powered documentation generation pipeline for Java projects using Amazon Bedrock or the Anthropic API, backed by AWS serverless infrastructure.

## Overview

This repository contains:

1. **docgen-ai-tool** - AI-powered documentation generator (Bedrock or Anthropic API)
2. **users-api** - Sample Spring Boot CRUD application for testing
3. **infra** - Complete AWS serverless infrastructure using Terraform

## Architecture

### Complete Flow

```
1. Client → API Gateway → Generate Lambda
   ├─ Validates request
   ├─ Uploads source to S3 (input bucket)
   ├─ Creates DynamoDB record (status: "created")
   ├─ Publishes message to SQS queue
   └─ Returns 202 Accepted with jobId

2. SQS Queue → Process Job Lambda
   ├─ Consumes message from queue
   ├─ Triggers CodeBuild with job parameters
   └─ Updates DynamoDB (status: "running")

3. CodeBuild
   ├─ Downloads JAR from S3
   ├─ Downloads input source from S3
   ├─ Runs docgen-ai-tool with Bedrock
   └─ Uploads output to S3 (output bucket)

4. EventBridge → Status Update Lambda
   ├─ Captures CodeBuild completion event
   └─ Updates DynamoDB (status: "finished")

5. Client polls GET /status/{jobId}
   └─ Returns job status + CloudFront download URL
```

### Infrastructure Components

**API Layer:**
- **API Gateway**: HTTP API with CORS enabled (POST, GET, DELETE, OPTIONS)
- **Generate Lambda**: Handles job submission (Python 3.11)
- **Get Status Lambda**: Returns job status and download URL (Python 3.11)
- **List Jobs Lambda**: Returns all jobs (Python 3.11)
- **Delete Job Lambda**: Soft deletes jobs (Python 3.11)

**Processing Layer:**
- **SQS Queue**: Decouples API from processing (15min visibility, 24h retention)
- **Dead Letter Queue**: Captures failed jobs after 3 retries
- **Process Job Lambda**: Consumes SQS and triggers CodeBuild (Python 3.11)
- **CodeBuild**: Runs docgen-ai-tool with Bedrock access (Java 17)

**Storage Layer:**
- **S3 Input Bucket**: Stores source code and JAR file
- **S3 Output Bucket**: Stores generated documentation
- **CloudFront**: Secure CDN for output downloads (OAI protected)

**Data Layer:**
- **DynamoDB**: Job tracking with TTL (7 days auto-cleanup)
- **EventBridge**: Monitors CodeBuild state changes
- **Status Update Lambda**: Updates job status on completion (Python 3.11)

**Security:**
- IAM roles with least-privilege policies
- S3 buckets with public access blocked
- CloudFront OAI for secure S3 access
- Bedrock model access for AI generation

## Quick Start

### Prerequisites

- Java 17+
- Maven 3.6+
- Terraform 1.5+
- AWS CLI configured
- Node.js 18+ (for frontend development)
- **AI backend** (at least one):
  - Anthropic API key (`ANTHROPIC_API_KEY`) — no AWS setup required for local use
  - AWS Account with Bedrock access enabled

### 1. Deploy Infrastructure

```bash
cd infra
terraform init
terraform apply
```

**Note**: The JAR will be automatically built and uploaded if `docgen-ai-tool/pom.xml` exists. The frontend will also be built and deployed automatically.

Outputs:
```
api_endpoint = "https://xxx.execute-api.us-east-1.amazonaws.com/dev"
api_key = <sensitive>
frontend_url = "https://xxx.cloudfront.net"
frontend_cloudfront_domain = "xxx.cloudfront.net"
output_cloudfront_domain = "https://xxx.cloudfront.net"
input_bucket = "docgen-ai-input-dev"
output_bucket = "docgen-ai-output-dev"
```

### 2. Access the Web Interface

Open the frontend URL in your browser:
```
https://xxx.cloudfront.net
```

**Features:**
- 📤 Upload ZIP files with your Java projects
- 📊 View all jobs with real-time status
- 📥 Download generated documentation
- 🔄 Auto-refresh and polling
- 🔍 View detailed job information (timestamps, buildId, input path)
- 🗑️ Delete jobs (soft delete)
- 🔐 Secure API key authentication

### 3. Or Use the API Directly

**Option A: Upload Source Code (Base64)**
```bash
# Zip your Java project
cd users-api
zip -r ../my-project.zip . -x "target/*"

# Convert to base64
base64 -i ../my-project.zip | tr -d '\n' > ../my-project.b64

# Submit job
curl -X POST https://xxx.execute-api.us-east-1.amazonaws.com/dev/generate \
  -H "Content-Type: application/json" \
  -d '{
    "jobName": "my-project",
    "sourceType": "upload",
    "fileContent": "'$(cat ../my-project.b64)'"
  }'
```

**Option B: Copy from S3**
```bash
# Upload to your own S3 bucket first
aws s3 cp my-project.zip s3://my-bucket/my-project.zip

# Submit job
curl -X POST https://xxx.execute-api.us-east-1.amazonaws.com/dev/generate \
  -H "Content-Type: application/json" \
  -d '{
    "jobName": "my-project",
    "sourceType": "s3",
    "sourceBucket": "my-bucket",
    "sourceKey": "my-project.zip"
  }'
```

Response (202 Accepted):
```json
{
  "jobId": "my-project-abc123",
  "status": "created",
  "message": "Job created and queued for processing"
}
```

**Note**: Status "created" means the job is queued in SQS and will be processed asynchronously.

### 3. Check Status

```bash
curl https://xxx.execute-api.us-east-1.amazonaws.com/dev/status/my-project-abc123
```

Response (when finished):
```json
{
  "jobId": "my-project-abc123",
  "status": "finished",
  "downloadUrl": "https://xxx.cloudfront.net/my-project-abc123/my-project-abc123-output.zip",
  "createdAt": "2026-01-18T15:00:00Z",
  "updatedAt": "2026-01-18T15:05:00Z"
}
```

### 4. List All Jobs

```bash
curl https://xxx.execute-api.us-east-1.amazonaws.com/dev/jobs
```

Response:
```json
{
  "jobs": [
    {
      "jobId": "my-project-abc123",
      "jobName": "my-project",
      "status": "finished",
      "downloadUrl": "https://xxx.cloudfront.net/...",
      "createdAt": "2026-01-18T15:00:00Z"
    }
  ],
  "count": 1
}
```

### 5. Delete Job

```bash
curl -X DELETE https://xxx.execute-api.us-east-1.amazonaws.com/dev/jobs/my-project-abc123
```

Response:
```json
{
  "message": "Job deleted successfully"
}
```

**Note**: This is a soft delete - the job is marked as deleted but data is preserved.

### 6. Download Results

```bash
curl -O https://xxx.cloudfront.net/my-project-abc123/my-project-abc123-output.zip
unzip my-project-abc123-output.zip
```

Output structure:
```
output/
├── code/                        # Source with AI-generated Javadocs
├── analysis/                    # JSON reports
│   ├── manifest.json
│   ├── javadoc_report.json      # includes selectionSummary, rank, complexityStats
│   ├── docs_generation_report.json
│   └── javadoc_metrics.csv      # DocAgent metrics (--metrics only)
└── docs/                        # AI-generated documentation
    ├── README.md
    ├── ARCHITECTURE.md
    ├── API.md
    ├── MANUAL_TESTS.md          # Index of per-controller test scenarios
    └── manual-tests/            # One file per controller
```

## Local Development

### Build the Tool

```bash
cd docgen-ai-tool
mvn clean package
```

### Run Locally

**Option A: Anthropic API (simplest)**
```bash
export ANTHROPIC_API_KEY=sk-ant-...

java -jar docgen-ai-tool/target/docgen-ai-tool-1.0.0.jar run \
  --input users-api \
  --output output \
  --useAnthropicApi
```

**Option B: Amazon Bedrock**
```bash
java -jar docgen-ai-tool/target/docgen-ai-tool-1.0.0.jar run \
  --input users-api \
  --output output \
  --useBedrock \
  --useBedrockDocs \
  --bedrockRegion us-east-1 \
  --bedrockModelId us.anthropic.claude-opus-4-8-20251101-v1:0
```

### CLI Reference

```
Usage: java -jar docs-generator.jar run --input <path> --output <path> [options]

Core options:
  --include <path>                Source subdirectory (default: src/main/java)
  --maxTargets <n>                Max documentation targets after ranking (default: 200; 0 = no limit)
  --dryRun                        Scan only, skip injection
  --docs <type1,type2,...>         Only generate specified documents (default: all)
                                    Valid types: javadoc, readme, architecture, api, manual-tests
  --metrics                        Compute DocAgent-style quality metrics for generated javadocs
                                    Outputs analysis/javadoc_metrics.csv
  --language <en|pt>              Documentation language (default: en)

Anthropic API (covers javadoc + docs + LLM prioritization):
  --useAnthropicApi               Use Anthropic Claude API (reads ANTHROPIC_API_KEY)
  --anthropicModelId <modelId>    (default: claude-opus-4-8)

Javadoc generation (Bedrock):
  --useBedrock                    Use Bedrock to generate Javadocs
  --bedrockRegion <region>
  --bedrockModelId <modelId>
  --maxBedrockCalls <n>           (default: 200)
  --bedrockTimeoutSeconds <n>     (default: 30)

Markdown docs generation (Bedrock):
  --useBedrockDocs                Use Bedrock to generate project docs
  --docsBedrockRegion <region>    (defaults to --bedrockRegion)
  --docsBedrockModelId <modelId>  (defaults to --bedrockModelId)
  --docsBedrockTimeoutSeconds <n> (default: 30)

Prioritization strategies (composable):
  --useStructuralFilter           Skip DTOs and simple data classes
  --useMetricsPrioritization      Rank by cyclomatic complexity; filter below threshold
  --minComplexityScore <n>        Minimum CC score to document (default: 2)
  --useLLMPrioritization          Use AI to rank and prune targets
```

### Test the Sample App

```bash
cd users-api
mvn clean package
java -jar target/users-api-1.0.0.jar
```

## Configuration

### Terraform Variables

Edit `infra/terraform.tfvars`:
```hcl
project_name      = "docgen-ai"
environment       = "dev"
aws_region        = "us-east-1"
bedrock_model_id  = "anthropic.claude-3-sonnet-20240229-v1:0"
enable_cloudfront = true  # Set to false to disable CloudFront (blocks downloads)
```

### CloudFront Distribution Control

You can temporarily disable both CloudFront distributions to block all access:

```hcl
# infra/terraform.tfvars
enable_cloudfront = false
```

When disabled:
- Both CloudFront distributions are disabled (not destroyed)
- Frontend UI will not be accessible
- Download URLs will not work
- All resources remain (no data loss)
- Suitable for temporarily blocking all access

When re-enabled:
- Both CloudFront distributions are enabled again
- Frontend and downloads become accessible immediately
- No resources are recreated

### Supported Bedrock Models

- `global.anthropic.claude-opus-4-5-20251101-v1:0` (recommended - most capable, cross-region)
- `global.anthropic.claude-sonnet-4-5-20250929-v1:0` (balanced, cross-region)
- `global.anthropic.claude-haiku-4-5-20251001-v1:0` (fastest, cross-region)
- `us.anthropic.claude-opus-4-5-20251101-v1:0` (US only)
- `us.anthropic.claude-sonnet-4-5-20250929-v1:0` (US only)

**Note**: Global inference profiles provide cross-region support for better availability.

### Cost Controls

The tool includes built-in cost controls:
- `--maxBedrockCalls 200` - Limits Javadoc generation calls (Bedrock path)
- `--maxTargets 200` - Caps the number of documented targets after ranking
- **Retry with exponential backoff**: 3 attempts (1s, 2s, 3s delays)
- Low temperature (0.2) for deterministic responses
- Validation prevents wasted API calls
- **Pipeline fails if AI calls fail** after retries

## Infrastructure Management

### Update JAR

```bash
cd docgen-ai-tool
mvn clean package
aws s3 cp target/docgen-ai-tool-1.0.0.jar s3://docgen-ai-input-dev/docgen-ai-tool.jar
```

Or let Terraform handle it:
```bash
cd infra
terraform apply
```

### Monitor Jobs

```bash
# Check SQS queue
aws sqs get-queue-attributes \
  --queue-url https://sqs.us-east-1.amazonaws.com/xxx/docgen-ai-jobs-dev \
  --attribute-names ApproximateNumberOfMessages

# Check Lambda logs
aws logs tail /aws/lambda/docgen-ai-generate-dev --follow
aws logs tail /aws/lambda/docgen-ai-process-job-dev --follow

# Check CodeBuild logs
aws codebuild batch-get-builds --ids <build-id>
```

### Destroy Infrastructure

```bash
cd infra
terraform destroy
```

## Troubleshooting

### Job Stuck in "created" Status
- Check SQS queue has messages:
  ```bash
  aws sqs get-queue-attributes \
    --queue-url https://sqs.us-east-1.amazonaws.com/xxx/docgen-ai-jobs-dev \
    --attribute-names ApproximateNumberOfMessages
  ```
- Check process-job Lambda logs:
  ```bash
  aws logs tail /aws/lambda/docgen-ai-process-job-dev --follow
  ```

### Job Stuck in "running" Status
- Check CodeBuild logs in AWS Console or:
  ```bash
  aws logs tail /aws/codebuild/docgen-ai-dev --follow
  ```
- Verify JAR exists in S3:
  ```bash
  aws s3 ls s3://docgen-ai-input-dev/docgen-ai-tool.jar
  ```
- Check Bedrock model access in AWS Console

### Job Failed (status: "finished", result: "error")
- Check CodeBuild logs for detailed error messages
- Common issues:
  - Invalid Java project structure
  - Missing pom.xml or build.gradle
  - Bedrock API rate limits
  - Insufficient IAM permissions

### "Access Denied" Errors
- Verify Bedrock model access is enabled in AWS Console
- Check IAM roles have correct permissions
- Ensure AWS credentials are configured

### Download URL Returns 403
- CloudFront distribution may still be deploying (wait 5-10 minutes)
- Check S3 output bucket has the file:
  ```bash
  aws s3 ls s3://docgen-ai-output-dev/{jobId}/
  ```

## Project Structure

```
simple-java-docs-pipeline/
├── docgen-ai-tool/          # Documentation generator
│   ├── src/main/java/br/unb/cic/docsgenerator/
│   │   ├── manifest/        # Project scanning
│   │   ├── parser/          # JavaParser integration
│   │   ├── javadoc/         # Javadoc generation + metrics
│   │   ├── docs/            # Documentation generation
│   │   ├── prioritization/  # Structural filter + complexity ranking
│   │   ├── anthropic/       # Anthropic API client
│   │   └── bedrock/         # Bedrock client
│   └── pom.xml
├── users-api/               # Sample application
│   ├── src/main/java/com/example/usersapi/
│   └── pom.xml
├── frontend/                # React web interface
│   ├── src/
│   │   ├── App.js          # Main component
│   │   └── index.js        # Entry point
│   ├── public/
│   └── package.json
└── infra/                   # Terraform infrastructure
    ├── modules/
    │   ├── storage/         # S3 + CloudFront + JAR upload
    │   ├── database/        # DynamoDB + SQS
    │   ├── codebuild/       # CodeBuild + EventBridge
    │   ├── api/             # API Gateway + Lambdas
    │   └── frontend/        # Frontend S3 + CloudFront
    ├── lambda/
    │   ├── generate/        # Job submission
    │   ├── process-job/     # SQS consumer
    │   └── status-update/   # CodeBuild events
    ├── main.tf
    ├── modules.tf
    └── variables.tf
```

## Features

### Web Interface
- **Beautiful React UI**: Bootstrap-based responsive design
- **File Upload**: Drag & drop ZIP files with your Java projects
- **Real-time Status**: Automatic polling for job progress
- **Jobs Dashboard**: View all jobs with status and download links
- **Job Details**: Expandable view with timestamps, buildId, and input path
- **Job Management**: Delete jobs with soft delete (preserves data)
- **One-Click Download**: Direct download for completed documentation
- **API Key Authentication**: Secure access with auto-generated API keys

### AI Backends
- **Anthropic API** (`--useAnthropicApi`): direct Claude access via `ANTHROPIC_API_KEY`; covers javadoc generation, project docs, and LLM-based prioritization
- **Amazon Bedrock** (`--useBedrock` / `--useBedrockDocs`): existing AWS-native path; separate model config for javadoc and docs generation

### Smart Target Prioritization
Composable ranking pipeline applied before `--maxTargets` cuts off the list, so the tool always documents the most valuable code first:
- **`--useStructuralFilter`** — skips DTOs and trivial data classes
- **`--useMetricsPrioritization`** — ranks by cyclomatic complexity; `--minComplexityScore <n>` sets a floor (default: 2)
- **`--useLLMPrioritization`** — AI reranks and prunes the candidate list
- `javadoc_report.json` includes `selectionSummary` (stage counts), per-entry rank and complexity scores, and `complexityStats`

### Selective Document Generation (`--docs`)
Pass a comma-separated list to generate only the artifacts you need:
```
--docs javadoc,api          # only inject javadocs and produce API.md
--docs readme,architecture  # only produce README.md and ARCHITECTURE.md
--docs manual-tests         # only generate per-controller test scenarios
```
Defaults to generating all document types.

### AI-Generated Javadocs
- Contextually accurate documentation for classes, methods, and constructors
- Validates parameter names, return types, and exceptions
- Falls back to deterministic placeholders on failure
- Retry logic with exponential backoff (3 attempts)

### AI-Generated Project Documentation
- **README.md** - Project overview, build instructions, and key components
- **ARCHITECTURE.md** - System architecture, components, and data flow
- **API.md** - REST endpoints with method signatures for accurate payload inference
- **MANUAL_TESTS.md** - Index of per-controller business-scenario test documents
- **manual-tests/\*.md** - One scenario-based test document per REST controller

### Documentation Language (`--language`)
Generate all documentation in English (`en`, default) or Portuguese (`pt`).

### DocAgent Quality Metrics (`--metrics`)
Implements the three-dimensional evaluation framework from the DocAgent paper (ACL 2025). After injection, the pipeline scores each generated javadoc and writes `analysis/javadoc_metrics.csv`:

| Metric | Method | Range |
|--------|--------|-------|
| Completeness | Structural check — summary sentence, `@param` per parameter, `@return` for non-void | 0–1 |
| Truthfulness | CamelCase identifiers in the javadoc verified against the full class manifest | 0–1 |
| Helpfulness | LLM-as-judge (clarity, depth, parameter utility, guidance) — AI entries only | 1–5 per dimension |

### Safety & Quality
- Validates all AI-generated content before injection
- Preserves code formatting using JavaParser
- Comprehensive reporting of all operations
- Async processing with SQS for scalability
- Dead Letter Queue for failed jobs
- Pipeline fails if AI calls fail after retries

### Security & Access Control
- **API Key Authentication**: All endpoints protected with x-api-key header
- **CloudFront Control**: Enable/disable both distributions with single flag
- **S3 Security**: Public access blocked, CloudFront OAI for secure access
- **IAM Least Privilege**: Minimal permissions for all resources

## License

This project is part of the UnB/CIC research initiative.

## Authors

- Universidade de Brasília (UnB)
- Centro de Informática (CIC)


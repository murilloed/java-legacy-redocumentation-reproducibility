output "api_endpoint" {
  description = "API Gateway endpoint URL"
  value       = module.api.api_endpoint
}

output "api_key" {
  description = "API Key for authentication"
  value       = module.api.api_key
  sensitive   = true
}

output "frontend_url" {
  description = "Frontend CloudFront URL"
  value       = module.frontend.frontend_url
}

output "frontend_cloudfront_domain" {
  description = "Frontend CloudFront distribution domain"
  value       = module.storage.cloudfront_domain
}

output "output_cloudfront_domain" {
  description = "Output CloudFront distribution domain (for downloads)"
  value       = "https://${module.storage.cloudfront_domain}"
}

output "input_bucket" {
  description = "Input S3 bucket name"
  value       = module.storage.input_bucket_name
}

output "output_bucket" {
  description = "Output S3 bucket name"
  value       = module.storage.output_bucket_name
}

resource "aws_sqs_queue" "jobs" {
  name                       = "${var.project_name}-jobs-${var.environment}"
  visibility_timeout_seconds = 900
  message_retention_seconds  = 86400

  tags = {
    Name = "${var.project_name}-jobs-queue"
  }
}

resource "aws_sqs_queue" "jobs_dlq" {
  name = "${var.project_name}-jobs-dlq-${var.environment}"

  tags = {
    Name = "${var.project_name}-jobs-dlq"
  }
}

resource "aws_sqs_queue_redrive_policy" "jobs" {
  queue_url = aws_sqs_queue.jobs.id

  redrive_policy = jsonencode({
    deadLetterTargetArn = aws_sqs_queue.jobs_dlq.arn
    maxReceiveCount     = 3
  })
}

output "api_endpoint" {
  value = aws_apigatewayv2_stage.main.invoke_url
}

output "api_id" {
  value = aws_apigatewayv2_api.main.id
}

output "api_key" {
  value     = random_password.api_key.result
  sensitive = true
}

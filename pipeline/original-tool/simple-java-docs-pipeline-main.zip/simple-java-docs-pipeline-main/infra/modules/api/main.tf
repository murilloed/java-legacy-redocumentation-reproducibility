resource "aws_iam_role" "generate_lambda" {
  name = "${var.project_name}-generate-${var.environment}"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Action = "sts:AssumeRole"
        Effect = "Allow"
        Principal = {
          Service = "lambda.amazonaws.com"
        }
      }
    ]
  })
}

# Authorizer Lambda Role
resource "aws_iam_role" "authorizer_lambda" {
  name = "${var.project_name}-authorizer-${var.environment}"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Action = "sts:AssumeRole"
        Effect = "Allow"
        Principal = {
          Service = "lambda.amazonaws.com"
        }
      }
    ]
  })
}

resource "aws_iam_role_policy_attachment" "authorizer_lambda_basic" {
  role       = aws_iam_role.authorizer_lambda.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"
}

resource "aws_iam_role_policy" "authorizer_lambda" {
  name = "${var.project_name}-authorizer-policy"
  role = aws_iam_role.authorizer_lambda.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = [
          "ssm:GetParameter"
        ]
        Resource = "arn:aws:ssm:*:*:parameter/${var.project_name}/${var.environment}/api-key"
      }
    ]
  })
}

resource "aws_iam_role_policy_attachment" "generate_lambda_basic" {
  role       = aws_iam_role.generate_lambda.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"
}

resource "aws_iam_role_policy" "generate_lambda" {
  name = "${var.project_name}-generate-policy"
  role = aws_iam_role.generate_lambda.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = [
          "s3:GetObject",
          "s3:PutObject"
        ]
        Resource = [
          "arn:aws:s3:::${var.input_bucket_name}/*",
          "arn:aws:s3:::*/*"
        ]
      },
      {
        Effect = "Allow"
        Action = [
          "dynamodb:PutItem",
          "dynamodb:GetItem",
          "dynamodb:UpdateItem",
          "dynamodb:Scan"
        ]
        Resource = "arn:aws:dynamodb:*:*:table/${var.jobs_table_name}"
      },
      {
        Effect = "Allow"
        Action = [
          "sqs:SendMessage"
        ]
        Resource = var.jobs_queue_arn
      }
    ]
  })
}

data "archive_file" "generate_lambda" {
  type        = "zip"
  source_file = "${path.module}/../../lambda/generate/index.py"
  output_path = "${path.module}/../../lambda/generate/function.zip"
}

resource "aws_lambda_function" "generate" {
  filename         = data.archive_file.generate_lambda.output_path
  function_name    = "${var.project_name}-generate-${var.environment}"
  role             = aws_iam_role.generate_lambda.arn
  handler          = "index.handler"
  source_code_hash = data.archive_file.generate_lambda.output_base64sha256
  runtime          = "python3.11"
  timeout          = 60

  environment {
    variables = {
      JOBS_TABLE         = var.jobs_table_name
      INPUT_BUCKET       = var.input_bucket_name
      OUTPUT_BUCKET      = var.output_bucket_name
      JOBS_QUEUE_URL     = var.jobs_queue_url
      CLOUDFRONT_DOMAIN  = var.cloudfront_domain
    }
  }
}

resource "aws_lambda_function" "get_status" {
  filename         = data.archive_file.generate_lambda.output_path
  function_name    = "${var.project_name}-get-status-${var.environment}"
  role             = aws_iam_role.generate_lambda.arn
  handler          = "index.get_status_handler"
  source_code_hash = data.archive_file.generate_lambda.output_base64sha256
  runtime          = "python3.11"
  timeout          = 30

  environment {
    variables = {
      JOBS_TABLE        = var.jobs_table_name
      CLOUDFRONT_DOMAIN = var.cloudfront_domain
    }
  }
}

resource "aws_lambda_function" "list_jobs" {
  filename         = data.archive_file.generate_lambda.output_path
  function_name    = "${var.project_name}-list-jobs-${var.environment}"
  role             = aws_iam_role.generate_lambda.arn
  handler          = "index.list_jobs_handler"
  source_code_hash = data.archive_file.generate_lambda.output_base64sha256
  runtime          = "python3.11"
  timeout          = 30

  environment {
    variables = {
      JOBS_TABLE        = var.jobs_table_name
      CLOUDFRONT_DOMAIN = var.cloudfront_domain
    }
  }
}

resource "aws_lambda_function" "delete_job" {
  filename         = data.archive_file.generate_lambda.output_path
  function_name    = "${var.project_name}-delete-job-${var.environment}"
  role             = aws_iam_role.generate_lambda.arn
  handler          = "index.delete_job_handler"
  source_code_hash = data.archive_file.generate_lambda.output_base64sha256
  runtime          = "python3.11"
  timeout          = 30

  environment {
    variables = {
      JOBS_TABLE = var.jobs_table_name
    }
  }
}

resource "aws_apigatewayv2_api" "main" {
  name          = "${var.project_name}-api-${var.environment}"
  protocol_type = "HTTP"

  cors_configuration {
    allow_origins = ["*"]
    allow_methods = ["POST", "GET", "OPTIONS", "DELETE"]
    allow_headers = ["content-type", "x-api-key"]
  }
}

resource "aws_apigatewayv2_stage" "main" {
  api_id      = aws_apigatewayv2_api.main.id
  name        = var.environment
  auto_deploy = true
}

# API Key
resource "aws_apigatewayv2_authorizer" "api_key" {
  api_id           = aws_apigatewayv2_api.main.id
  authorizer_type  = "REQUEST"
  authorizer_uri   = aws_lambda_function.authorizer.invoke_arn
  identity_sources = ["$request.header.x-api-key"]
  name             = "${var.project_name}-authorizer-${var.environment}"
  authorizer_payload_format_version = "2.0"
  enable_simple_responses = true
}

resource "random_password" "api_key" {
  length  = 32
  special = false
}

resource "aws_ssm_parameter" "api_key" {
  name  = "/${var.project_name}/${var.environment}/api-key"
  type  = "SecureString"
  value = random_password.api_key.result
}

resource "aws_apigatewayv2_integration" "generate" {
  api_id           = aws_apigatewayv2_api.main.id
  integration_type = "AWS_PROXY"
  integration_uri  = aws_lambda_function.generate.invoke_arn
}

resource "aws_apigatewayv2_route" "generate" {
  api_id             = aws_apigatewayv2_api.main.id
  route_key          = "POST /generate"
  target             = "integrations/${aws_apigatewayv2_integration.generate.id}"
  authorization_type = "CUSTOM"
  authorizer_id      = aws_apigatewayv2_authorizer.api_key.id
}

resource "aws_lambda_permission" "api_generate" {
  statement_id  = "AllowAPIGatewayInvoke"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.generate.function_name
  principal     = "apigateway.amazonaws.com"
  source_arn    = "${aws_apigatewayv2_api.main.execution_arn}/*/*"
}

resource "aws_apigatewayv2_integration" "get_status" {
  api_id           = aws_apigatewayv2_api.main.id
  integration_type = "AWS_PROXY"
  integration_uri  = aws_lambda_function.get_status.invoke_arn
}

resource "aws_apigatewayv2_route" "get_status" {
  api_id             = aws_apigatewayv2_api.main.id
  route_key          = "GET /status/{jobId}"
  target             = "integrations/${aws_apigatewayv2_integration.get_status.id}"
  authorization_type = "CUSTOM"
  authorizer_id      = aws_apigatewayv2_authorizer.api_key.id
}

resource "aws_lambda_permission" "api_get_status" {
  statement_id  = "AllowAPIGatewayInvoke"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.get_status.function_name
  principal     = "apigateway.amazonaws.com"
  source_arn    = "${aws_apigatewayv2_api.main.execution_arn}/*/*"
}

resource "aws_apigatewayv2_integration" "list_jobs" {
  api_id           = aws_apigatewayv2_api.main.id
  integration_type = "AWS_PROXY"
  integration_uri  = aws_lambda_function.list_jobs.invoke_arn
}

resource "aws_apigatewayv2_route" "list_jobs" {
  api_id             = aws_apigatewayv2_api.main.id
  route_key          = "GET /jobs"
  target             = "integrations/${aws_apigatewayv2_integration.list_jobs.id}"
  authorization_type = "CUSTOM"
  authorizer_id      = aws_apigatewayv2_authorizer.api_key.id
}

resource "aws_lambda_permission" "api_list_jobs" {
  statement_id  = "AllowAPIGatewayInvoke"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.list_jobs.function_name
  principal     = "apigateway.amazonaws.com"
  source_arn    = "${aws_apigatewayv2_api.main.execution_arn}/*/*"
}

resource "aws_apigatewayv2_integration" "delete_job" {
  api_id           = aws_apigatewayv2_api.main.id
  integration_type = "AWS_PROXY"
  integration_uri  = aws_lambda_function.delete_job.invoke_arn
}

resource "aws_apigatewayv2_route" "delete_job" {
  api_id             = aws_apigatewayv2_api.main.id
  route_key          = "DELETE /jobs/{jobId}"
  target             = "integrations/${aws_apigatewayv2_integration.delete_job.id}"
  authorization_type = "CUSTOM"
  authorizer_id      = aws_apigatewayv2_authorizer.api_key.id
}

resource "aws_lambda_permission" "api_delete_job" {
  statement_id  = "AllowAPIGatewayInvoke"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.delete_job.function_name
  principal     = "apigateway.amazonaws.com"
  source_arn    = "${aws_apigatewayv2_api.main.execution_arn}/*/*"
}

# SQS Processor Lambda
resource "aws_iam_role" "process_job_lambda" {
  name = "${var.project_name}-process-job-${var.environment}"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Action = "sts:AssumeRole"
        Effect = "Allow"
        Principal = {
          Service = "lambda.amazonaws.com"
        }
      }
    ]
  })
}

resource "aws_iam_role_policy_attachment" "process_job_lambda_basic" {
  role       = aws_iam_role.process_job_lambda.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"
}

resource "aws_iam_role_policy" "process_job_lambda" {
  name = "${var.project_name}-process-job-policy"
  role = aws_iam_role.process_job_lambda.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = [
          "sqs:ReceiveMessage",
          "sqs:DeleteMessage",
          "sqs:GetQueueAttributes"
        ]
        Resource = var.jobs_queue_arn
      },
      {
        Effect = "Allow"
        Action = [
          "dynamodb:UpdateItem"
        ]
        Resource = "arn:aws:dynamodb:*:*:table/${var.jobs_table_name}"
      },
      {
        Effect = "Allow"
        Action = [
          "codebuild:StartBuild"
        ]
        Resource = "*"
      }
    ]
  })
}

data "archive_file" "authorizer_lambda" {
  type        = "zip"
  source_file = "${path.module}/../../lambda/authorizer/lambda_function.py"
  output_path = "${path.module}/../../lambda/authorizer/function.zip"
}

resource "aws_lambda_function" "authorizer" {
  filename         = data.archive_file.authorizer_lambda.output_path
  function_name    = "${var.project_name}-authorizer-${var.environment}"
  role             = aws_iam_role.authorizer_lambda.arn
  handler          = "lambda_function.lambda_handler"
  source_code_hash = data.archive_file.authorizer_lambda.output_base64sha256
  runtime          = "python3.11"
  timeout          = 10

  environment {
    variables = {
      PROJECT_NAME = var.project_name
      ENVIRONMENT  = var.environment
    }
  }
}

resource "aws_lambda_permission" "api_authorizer" {
  statement_id  = "AllowAPIGatewayInvoke"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.authorizer.function_name
  principal     = "apigateway.amazonaws.com"
  source_arn    = "${aws_apigatewayv2_api.main.execution_arn}/*/*"
}

data "archive_file" "process_job_lambda" {
  type        = "zip"
  source_file = "${path.module}/../../lambda/process-job/index.py"
  output_path = "${path.module}/../../lambda/process-job/function.zip"
}

resource "aws_lambda_function" "process_job" {
  filename         = data.archive_file.process_job_lambda.output_path
  function_name    = "${var.project_name}-process-job-${var.environment}"
  role             = aws_iam_role.process_job_lambda.arn
  handler          = "index.handler"
  source_code_hash = data.archive_file.process_job_lambda.output_base64sha256
  runtime          = "python3.11"
  timeout          = 60

  environment {
    variables = {
      JOBS_TABLE        = var.jobs_table_name
      CODEBUILD_PROJECT = var.codebuild_project_name
    }
  }
}

resource "aws_lambda_event_source_mapping" "sqs_trigger" {
  event_source_arn = var.jobs_queue_arn
  function_name    = aws_lambda_function.process_job.arn
  batch_size       = 1
}

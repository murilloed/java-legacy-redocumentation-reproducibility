variable "project_name" {
  type = string
}

variable "environment" {
  type = string
}

variable "input_bucket_name" {
  type = string
}

variable "output_bucket_name" {
  type = string
}

variable "jobs_table_name" {
  type = string
}

variable "jobs_queue_url" {
  type = string
}

variable "jobs_queue_arn" {
  type = string
}

variable "codebuild_project_name" {
  type = string
}

variable "cloudfront_domain" {
  type = string
}

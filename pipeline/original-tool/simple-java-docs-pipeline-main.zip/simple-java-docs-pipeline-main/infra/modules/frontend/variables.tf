variable "project_name" {
  type = string
}

variable "environment" {
  type = string
}

variable "api_endpoint" {
  type = string
}

variable "api_key" {
  type      = string
  sensitive = true
}

variable "enable_cloudfront" {
  type    = bool
  default = true
}

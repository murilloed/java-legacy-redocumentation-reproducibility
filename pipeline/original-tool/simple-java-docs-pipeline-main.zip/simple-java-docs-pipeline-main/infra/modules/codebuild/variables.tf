variable "project_name" {
  type = string
}

variable "environment" {
  type = string
}

variable "input_bucket_name" {
  type = string
}

variable "output_bucket_name" {
  type = string
}

variable "bedrock_model_id" {
  type = string
}

variable "jobs_table_name" {
  type = string
}

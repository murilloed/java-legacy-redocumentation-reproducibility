output "project_name" {
  value = aws_codebuild_project.docgen.name
}

output "project_arn" {
  value = aws_codebuild_project.docgen.arn
}

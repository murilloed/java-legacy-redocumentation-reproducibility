resource "aws_iam_role" "codebuild" {
  name = "${var.project_name}-codebuild-${var.environment}"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Action = "sts:AssumeRole"
        Effect = "Allow"
        Principal = {
          Service = "codebuild.amazonaws.com"
        }
      }
    ]
  })
}

resource "aws_iam_role_policy" "codebuild" {
  name = "${var.project_name}-codebuild-policy"
  role = aws_iam_role.codebuild.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = [
          "logs:CreateLogGroup",
          "logs:CreateLogStream",
          "logs:PutLogEvents"
        ]
        Resource = "arn:aws:logs:*:*:*"
      },
      {
        Effect = "Allow"
        Action = [
          "s3:GetObject",
          "s3:GetObjectVersion"
        ]
        Resource = "arn:aws:s3:::${var.input_bucket_name}/*"
      },
      {
        Effect = "Allow"
        Action = [
          "s3:PutObject"
        ]
        Resource = "arn:aws:s3:::${var.output_bucket_name}/*"
      },
      {
        Effect = "Allow"
        Action = [
          "bedrock:InvokeModel"
        ]
        Resource = [
          "arn:aws:bedrock:*::foundation-model/*",
          "arn:aws:bedrock:*:*:inference-profile/*"
        ]
      },
      {
        Effect = "Allow"
        Action = [
          "dynamodb:UpdateItem"
        ]
        Resource = "arn:aws:dynamodb:*:*:table/${var.jobs_table_name}"
      }
    ]
  })
}

resource "aws_codebuild_project" "docgen" {
  name          = "${var.project_name}-${var.environment}"
  service_role  = aws_iam_role.codebuild.arn
  build_timeout = 60

  artifacts {
    type = "NO_ARTIFACTS"
  }

  environment {
    compute_type                = "BUILD_GENERAL1_SMALL"
    image                       = "aws/codebuild/standard:7.0"
    type                        = "LINUX_CONTAINER"
    image_pull_credentials_type = "CODEBUILD"

    environment_variable {
      name  = "INPUT_BUCKET"
      value = var.input_bucket_name
    }

    environment_variable {
      name  = "OUTPUT_BUCKET"
      value = var.output_bucket_name
    }

    environment_variable {
      name  = "BEDROCK_MODEL_ID"
      value = var.bedrock_model_id
    }

    environment_variable {
      name  = "JOBS_TABLE"
      value = var.jobs_table_name
    }
  }

  source {
    type      = "NO_SOURCE"
    buildspec = file("${path.module}/buildspec.yml")
  }
}

resource "aws_cloudwatch_event_rule" "codebuild_state_change" {
  name        = "${var.project_name}-codebuild-state-${var.environment}"
  description = "Capture CodeBuild state changes"

  event_pattern = jsonencode({
    source      = ["aws.codebuild"]
    detail-type = ["CodeBuild Build State Change"]
    detail = {
      project-name = [aws_codebuild_project.docgen.name]
    }
  })
}

resource "aws_cloudwatch_event_target" "lambda" {
  rule      = aws_cloudwatch_event_rule.codebuild_state_change.name
  target_id = "StatusUpdateLambda"
  arn       = aws_lambda_function.status_update.arn
}

resource "aws_lambda_permission" "allow_eventbridge" {
  statement_id  = "AllowExecutionFromEventBridge"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.status_update.function_name
  principal     = "events.amazonaws.com"
  source_arn    = aws_cloudwatch_event_rule.codebuild_state_change.arn
}

resource "aws_iam_role" "status_update_lambda" {
  name = "${var.project_name}-status-update-${var.environment}"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Action = "sts:AssumeRole"
        Effect = "Allow"
        Principal = {
          Service = "lambda.amazonaws.com"
        }
      }
    ]
  })
}

resource "aws_iam_role_policy_attachment" "status_update_lambda_basic" {
  role       = aws_iam_role.status_update_lambda.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"
}

resource "aws_iam_role_policy" "status_update_lambda" {
  name = "${var.project_name}-status-update-policy"
  role = aws_iam_role.status_update_lambda.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = [
          "dynamodb:UpdateItem",
          "dynamodb:GetItem"
        ]
        Resource = "arn:aws:dynamodb:*:*:table/${var.jobs_table_name}"
      }
    ]
  })
}

data "archive_file" "status_update_lambda" {
  type        = "zip"
  source_file = "${path.module}/../../lambda/status-update/index.py"
  output_path = "${path.module}/../../lambda/status-update/function.zip"
}

resource "aws_lambda_function" "status_update" {
  filename         = data.archive_file.status_update_lambda.output_path
  function_name    = "${var.project_name}-status-update-${var.environment}"
  role             = aws_iam_role.status_update_lambda.arn
  handler          = "index.handler"
  source_code_hash = data.archive_file.status_update_lambda.output_base64sha256
  runtime          = "python3.11"
  timeout          = 30

  environment {
    variables = {
      JOBS_TABLE = var.jobs_table_name
    }
  }
}

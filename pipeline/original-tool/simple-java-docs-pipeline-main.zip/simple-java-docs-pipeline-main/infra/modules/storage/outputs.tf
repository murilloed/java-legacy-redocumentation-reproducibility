output "input_bucket_name" {
  value = aws_s3_bucket.input.id
}

output "input_bucket_arn" {
  value = aws_s3_bucket.input.arn
}

output "output_bucket_name" {
  value = aws_s3_bucket.output.id
}

output "output_bucket_arn" {
  value = aws_s3_bucket.output.arn
}

output "cloudfront_domain" {
  value = aws_cloudfront_distribution.output.domain_name
}

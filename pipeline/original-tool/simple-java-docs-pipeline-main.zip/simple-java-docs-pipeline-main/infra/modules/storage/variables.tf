variable "project_name" {
  type = string
}

variable "environment" {
  type = string
}

variable "enable_cloudfront" {
  type    = bool
  default = true
}

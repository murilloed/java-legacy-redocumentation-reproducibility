import json
import boto3
import os
from datetime import datetime

dynamodb = boto3.resource('dynamodb')
codebuild = boto3.client('codebuild')

table = dynamodb.Table(os.environ['JOBS_TABLE'])
codebuild_project = os.environ['CODEBUILD_PROJECT']

def handler(event, context):
    for record in event['Records']:
        try:
            message = json.loads(record['body'])
            job_id = message['jobId']
            input_bucket = message['inputBucket']
            output_bucket = message['outputBucket']
            language = message.get('language', 'en')

            # Start CodeBuild
            build_response = codebuild.start_build(
                projectName=codebuild_project,
                environmentVariablesOverride=[
                    {'name': 'JOB_ID', 'value': job_id, 'type': 'PLAINTEXT'},
                    {'name': 'INPUT_BUCKET', 'value': input_bucket, 'type': 'PLAINTEXT'},
                    {'name': 'OUTPUT_BUCKET', 'value': output_bucket, 'type': 'PLAINTEXT'},
                    {'name': 'LANGUAGE', 'value': language, 'type': 'PLAINTEXT'}
                ]
            )
            
            # Update status to running
            table.update_item(
                Key={'jobId': job_id},
                UpdateExpression='SET #status = :status, buildId = :buildId, updatedAt = :updated',
                ExpressionAttributeNames={'#status': 'status'},
                ExpressionAttributeValues={
                    ':status': 'running',
                    ':buildId': build_response['build']['id'],
                    ':updated': datetime.utcnow().isoformat()
                }
            )
            
            print(f"Started build for job {job_id}: {build_response['build']['id']}")
            
        except Exception as e:
            print(f"Error processing job: {str(e)}")
            raise

import json
import boto3
import os
import random
import string
from datetime import datetime, timedelta

s3 = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')
sqs = boto3.client('sqs')

def generate_job_id(job_name):
    random_suffix = ''.join(random.choices(string.ascii_lowercase + string.digits, k=6))
    return f"{job_name}-{random_suffix}"

def handler(event, context):
    try:
        table = dynamodb.Table(os.environ['JOBS_TABLE'])
        input_bucket = os.environ['INPUT_BUCKET']
        output_bucket = os.environ['OUTPUT_BUCKET']
        jobs_queue_url = os.environ['JOBS_QUEUE_URL']
        
        body = json.loads(event['body']) if isinstance(event.get('body'), str) else event.get('body', {})
        
        # Extract parameters
        job_name = body.get('jobName')
        source_type = body.get('sourceType')  # 's3' or 'upload'
        language = body.get('language', 'en')  # 'en' or 'pt'
        if language not in ('en', 'pt'):
            language = 'en'

        if not job_name or not source_type:
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'jobName and sourceType are required'})
            }
        
        # Generate job ID
        job_id = generate_job_id(job_name)
        input_key = f"{job_id}/{job_id}-input.zip"
        
        # Handle different source types
        if source_type == 's3':
            source_bucket = body.get('sourceBucket')
            source_key = body.get('sourceKey')
            
            if not source_bucket or not source_key:
                return {
                    'statusCode': 400,
                    'body': json.dumps({'error': 'sourceBucket and sourceKey required for s3 source'})
                }
            
            # Copy from source S3 to input bucket
            s3.copy_object(
                CopySource={'Bucket': source_bucket, 'Key': source_key},
                Bucket=input_bucket,
                Key=input_key
            )
            
        elif source_type == 'upload':
            # For upload, expect base64 encoded zip file
            file_content = body.get('fileContent')
            
            if not file_content:
                return {
                    'statusCode': 400,
                    'body': json.dumps({'error': 'fileContent required for upload source'})
                }
            
            import base64
            file_bytes = base64.b64decode(file_content)
            
            # Upload to input bucket
            s3.put_object(
                Bucket=input_bucket,
                Key=input_key,
                Body=file_bytes
            )
        else:
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'Invalid sourceType. Must be s3 or upload'})
            }
        
        # Create job record in DynamoDB
        ttl = int((datetime.utcnow() + timedelta(days=7)).timestamp())
        
        table.put_item(
            Item={
                'jobId': job_id,
                'jobName': job_name,
                'status': 'created',
                'sourceType': source_type,
                'language': language,
                'inputPath': input_key,
                'createdAt': datetime.utcnow().isoformat(),
                'updatedAt': datetime.utcnow().isoformat(),
                'ttl': ttl
            }
        )

        # Send message to SQS queue
        sqs.send_message(
            QueueUrl=jobs_queue_url,
            MessageBody=json.dumps({
                'jobId': job_id,
                'inputBucket': input_bucket,
                'outputBucket': output_bucket,
                'language': language
            })
        )
        
        return {
            'statusCode': 202,
            'body': json.dumps({
                'jobId': job_id,
                'status': 'created',
                'message': 'Job created and queued for processing'
            })
        }
        
    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }

def get_status_handler(event, context):
    try:
        table = dynamodb.Table(os.environ['JOBS_TABLE'])
        cloudfront_domain = os.environ['CLOUDFRONT_DOMAIN']
        
        job_id = event['pathParameters']['jobId']
        
        response = table.get_item(Key={'jobId': job_id})
        
        if 'Item' not in response:
            return {
                'statusCode': 404,
                'body': json.dumps({'error': 'Job not found'})
            }
        
        job = response['Item']
        
        # If finished successfully, generate CloudFront URL
        if job['status'] == 'finished' and job.get('statusDetails', {}).get('result') == 'success':
            output_path = job['statusDetails']['outputPath']
            download_url = f"https://{cloudfront_domain}/{output_path}"
            job['downloadUrl'] = download_url
        
        return {
            'statusCode': 200,
            'body': json.dumps(job, default=str)
        }
        
    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }

def list_jobs_handler(event, context):
    try:
        table = dynamodb.Table(os.environ['JOBS_TABLE'])
        cloudfront_domain = os.environ['CLOUDFRONT_DOMAIN']
        
        # Scan table (limited to 50 most recent)
        response = table.scan(Limit=50)
        jobs = response.get('Items', [])
        
        # Filter out deleted jobs
        jobs = [job for job in jobs if not job.get('deleted', False)]
        
        # Sort by createdAt descending
        jobs.sort(key=lambda x: x.get('createdAt', ''), reverse=True)
        
        # Add download URLs for finished jobs
        for job in jobs:
            if job['status'] == 'finished' and job.get('statusDetails', {}).get('result') == 'success':
                output_path = job['statusDetails']['outputPath']
                job['downloadUrl'] = f"https://{cloudfront_domain}/{output_path}"
        
        return {
            'statusCode': 200,
            'body': json.dumps({'jobs': jobs, 'count': len(jobs)}, default=str)
        }
        
    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }

def delete_job_handler(event, context):
    try:
        table = dynamodb.Table(os.environ['JOBS_TABLE'])
        job_id = event['pathParameters']['jobId']
        
        # Soft delete by setting deleted flag
        table.update_item(
            Key={'jobId': job_id},
            UpdateExpression='SET deleted = :deleted, updatedAt = :updated',
            ExpressionAttributeValues={
                ':deleted': True,
                ':updated': datetime.utcnow().isoformat()
            }
        )
        
        return {
            'statusCode': 200,
            'body': json.dumps({'message': 'Job deleted successfully'})
        }
        
    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }

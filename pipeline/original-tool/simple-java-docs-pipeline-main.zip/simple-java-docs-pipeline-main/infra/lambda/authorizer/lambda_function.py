import json
import boto3
import os

ssm = boto3.client('ssm')

def lambda_handler(event, context):
    api_key_param = f"/{os.environ['PROJECT_NAME']}/{os.environ['ENVIRONMENT']}/api-key"
    
    try:
        response = ssm.get_parameter(Name=api_key_param, WithDecryption=True)
        valid_api_key = response['Parameter']['Value']
        
        provided_key = event.get('headers', {}).get('x-api-key', '')
        
        if provided_key == valid_api_key:
            return {
                "isAuthorized": True
            }
        else:
            return {
                "isAuthorized": False
            }
    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            "isAuthorized": False
        }

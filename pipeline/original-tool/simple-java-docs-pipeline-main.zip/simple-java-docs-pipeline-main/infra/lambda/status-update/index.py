import json
import boto3
import os
from datetime import datetime

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(os.environ['JOBS_TABLE'])

def handler(event, context):
    detail = event['detail']
    build_status = detail['build-status']
    
    # Extract job ID from environment variables
    env_vars = {var['name']: var['value'] for var in detail.get('additional-information', {}).get('environment', {}).get('environment-variables', [])}
    job_id = env_vars.get('JOB_ID', '')
    
    if not job_id:
        print("No JOB_ID found in build environment")
        return
    
    # Update job status based on build status
    if build_status == 'IN_PROGRESS':
        status = 'running'
        status_details = {
            'buildId': detail['build-id'],
            'buildArn': detail.get('build-arn', ''),
            'startTime': detail.get('additional-information', {}).get('build-start-time', '')
        }
    elif build_status == 'SUCCEEDED':
        status = 'finished'
        output_bucket = env_vars.get('OUTPUT_BUCKET', '')
        status_details = {
            'result': 'success',
            'outputPath': f"{job_id}/{job_id}-output.zip",
            'outputBucket': output_bucket,
            'completedAt': datetime.utcnow().isoformat()
        }
    elif build_status in ['FAILED', 'FAULT', 'TIMED_OUT', 'STOPPED']:
        status = 'finished'
        status_details = {
            'result': 'error',
            'error': build_status,
            'completedAt': datetime.utcnow().isoformat()
        }
    else:
        return
    
    # Update DynamoDB
    table.update_item(
        Key={'jobId': job_id},
        UpdateExpression='SET #status = :status, statusDetails = :details, updatedAt = :updated',
        ExpressionAttributeNames={'#status': 'status'},
        ExpressionAttributeValues={
            ':status': status,
            ':details': status_details,
            ':updated': datetime.utcnow().isoformat()
        }
    )
    
    print(f"Updated job {job_id} to status {status}")
    
    return {
        'statusCode': 200,
        'body': json.dumps({'message': 'Status updated'})
    }

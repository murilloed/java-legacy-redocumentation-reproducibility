module "storage" {
  source = "./modules/storage"

  project_name      = var.project_name
  environment       = var.environment
  enable_cloudfront = var.enable_cloudfront
}

module "database" {
  source = "./modules/database"

  project_name = var.project_name
  environment  = var.environment
}

module "codebuild" {
  source = "./modules/codebuild"

  project_name        = var.project_name
  environment         = var.environment
  input_bucket_name   = module.storage.input_bucket_name
  output_bucket_name  = module.storage.output_bucket_name
  bedrock_model_id    = var.bedrock_model_id
  jobs_table_name     = module.database.jobs_table_name
}

module "api" {
  source = "./modules/api"

  project_name          = var.project_name
  environment           = var.environment
  input_bucket_name     = module.storage.input_bucket_name
  output_bucket_name    = module.storage.output_bucket_name
  jobs_table_name       = module.database.jobs_table_name
  jobs_queue_url        = module.database.jobs_queue_url
  jobs_queue_arn        = module.database.jobs_queue_arn
  codebuild_project_name = module.codebuild.project_name
  cloudfront_domain     = module.storage.cloudfront_domain
}

module "frontend" {
  source = "./modules/frontend"

  project_name      = var.project_name
  environment       = var.environment
  api_endpoint      = module.api.api_endpoint
  api_key           = module.api.api_key
  enable_cloudfront = var.enable_cloudfront
}

# docgen-ai Infrastructure

Terraform infrastructure for the docgen-ai serverless documentation generation service.

## Architecture

```
┌─────────────┐
│  API Gateway│
│  /generate  │
│  /status    │
└──────┬──────┘
       │
       ▼
┌─────────────┐     ┌──────────────┐
│   Lambda    │────▶│  DynamoDB    │
│  Generate   │     │  Jobs Table  │
└──────┬──────┘     └──────────────┘
       │
       ▼
┌─────────────┐     ┌──────────────┐
│  CodeBuild  │────▶│  S3 Output   │
│  docgen-ai  │     │    Bucket    │
└──────┬──────┘     └──────┬───────┘
       │                   │
       ▼                   ▼
┌─────────────┐     ┌──────────────┐
│  S3 Input   │     │ CloudFront   │
│   Bucket    │     │ Distribution │
└─────────────┘     └──────────────┘
       ▲
       │
┌──────┴──────┐
│   Lambda    │
│Status Update│
└─────────────┘
```

## Components

### API Gateway
- **POST /generate** - Submit documentation generation job
- **GET /status/{jobId}** - Get job status and download URL

### Lambda Functions
- **generate** - Handles job creation, S3 operations, and CodeBuild trigger
- **status-update** - Updates job status from CodeBuild events

### CodeBuild
- Runs docgen-ai-tool with Bedrock integration
- Processes Java projects and generates documentation
- Outputs results to S3

### Storage
- **Input Bucket** - Stores uploaded/copied source code
- **Output Bucket** - Stores generated documentation
- **CloudFront** - Provides secure download URLs

### Database
- **DynamoDB Jobs Table** - Tracks job status and metadata
- TTL enabled (7 days)

## Prerequisites

- Terraform ~> 1.6.0
- AWS CLI configured
- AWS account with Bedrock access

## Deployment

### 1. Initialize Terraform

```bash
cd infra
terraform init
```

### 2. Review Plan

```bash
terraform plan
```

### 3. Deploy

```bash
terraform apply
```

### 4. Upload docgen-ai-tool JAR

After deployment, upload the tool to the input bucket:

```bash
aws s3 cp ../docgen-ai-tool/target/docgen-ai-tool-1.0.0.jar \
  s3://$(terraform output -raw input_bucket)/docgen-ai-tool-1.0.0.jar
```

## Usage

### Submit Job (S3 Source)

```bash
curl -X POST https://API_ENDPOINT/generate \
  -H "Content-Type: application/json" \
  -d '{
    "jobName": "my-project",
    "sourceType": "s3",
    "sourceBucket": "my-bucket",
    "sourceKey": "my-project.zip"
  }'
```

Response:
```json
{
  "jobId": "my-project-abc123",
  "status": "running",
  "message": "Job created and build started"
}
```

### Submit Job (Upload)

```bash
# Base64 encode your zip file
BASE64_CONTENT=$(base64 -i my-project.zip)

curl -X POST https://API_ENDPOINT/generate \
  -H "Content-Type: application/json" \
  -d "{
    \"jobName\": \"my-project\",
    \"sourceType\": \"upload\",
    \"fileContent\": \"$BASE64_CONTENT\"
  }"
```

### Check Job Status

```bash
curl https://API_ENDPOINT/status/my-project-abc123
```

Response (running):
```json
{
  "jobId": "my-project-abc123",
  "status": "running",
  "buildId": "...",
  "createdAt": "2024-01-18T12:00:00Z"
}
```

Response (finished):
```json
{
  "jobId": "my-project-abc123",
  "status": "finished",
  "statusDetails": {
    "result": "success",
    "outputPath": "my-project-abc123/my-project-abc123-output.zip"
  },
  "downloadUrl": "https://CLOUDFRONT_DOMAIN/my-project-abc123/my-project-abc123-output.zip",
  "createdAt": "2024-01-18T12:00:00Z",
  "updatedAt": "2024-01-18T12:05:00Z"
}
```

## Job Statuses

- **created** - Job registered in DynamoDB
- **running** - CodeBuild is processing
- **finished** - Completed (check statusDetails.result for success/error)

## Configuration

### Variables

Edit `variables.tf` or create `terraform.tfvars`:

```hcl
aws_region       = "us-east-1"
environment      = "dev"
project_name     = "docgen-ai"
bedrock_model_id = "anthropic.claude-3-sonnet-20240229-v1:0"
```

### Outputs

After deployment:

```bash
terraform output api_endpoint
terraform output input_bucket
terraform output output_bucket
terraform output cloudfront_domain
```

## Cost Considerations

- **Lambda**: Pay per invocation
- **CodeBuild**: Pay per build minute (BUILD_GENERAL1_SMALL)
- **S3**: Storage + requests
- **CloudFront**: Data transfer
- **DynamoDB**: On-demand pricing
- **Bedrock**: Per-token pricing

Estimated cost per job: $0.10 - $0.50 (depending on project size and Bedrock usage)

## Security

- All S3 buckets are private
- CloudFront uses OAI for secure access
- Lambda functions have minimal IAM permissions
- DynamoDB items auto-expire after 7 days
- API Gateway has CORS enabled

## Cleanup

```bash
terraform destroy
```

**Note**: Manually empty S3 buckets before destroying if they contain data.

## Troubleshooting

### CodeBuild Fails

Check CloudWatch Logs:
```bash
aws logs tail /aws/codebuild/docgen-ai-dev --follow
```

### Job Stuck in "running"

Check CodeBuild console or describe the build:
```bash
aws codebuild batch-get-builds --ids BUILD_ID
```

### Lambda Timeout

Increase timeout in `modules/api/main.tf` (currently 60s for generate, 30s for status)

## Development

### Local Testing

Test Lambda functions locally:
```bash
cd lambda/generate
python3 index.py
```

### Update Lambda Code

After modifying Lambda code:
```bash
terraform apply -target=module.api.aws_lambda_function.generate
```

## License

Part of the UnB/CIC research initiative.

aws_region        = "us-east-1"
environment       = "dev"
project_name      = "docgen-ai-unb"
bedrock_model_id  = "global.anthropic.claude-opus-4-5-20251101-v1:0"
enable_cloudfront = true

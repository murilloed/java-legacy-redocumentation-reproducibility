import React, { useState } from 'react';
import { Container, Row, Col, Card, Button, Form, Alert, ProgressBar, Badge, Nav } from 'react-bootstrap';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';

const API_ENDPOINT = process.env.REACT_APP_API_ENDPOINT || 'https://hh7mmhvke0.execute-api.us-east-1.amazonaws.com/dev';
const API_KEY = process.env.REACT_APP_API_KEY;

const apiClient = axios.create({
  baseURL: API_ENDPOINT,
  headers: API_KEY ? { 'x-api-key': API_KEY } : {}
});

function App() {
  const [activeTab, setActiveTab] = useState('upload');
  const [file, setFile] = useState(null);
  const [jobName, setJobName] = useState('');
  const [jobId, setJobId] = useState('');
  const [status, setStatus] = useState('');
  const [downloadUrl, setDownloadUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [polling, setPolling] = useState(false);
  const [jobs, setJobs] = useState([]);
  const [loadingJobs, setLoadingJobs] = useState(false);
  const [showDetails, setShowDetails] = useState(false);
  const [jobDetails, setJobDetails] = useState(null);
  const [language, setLanguage] = useState('en');

  const loadJobs = async () => {
    setLoadingJobs(true);
    try {
      const response = await apiClient.get(`${API_ENDPOINT}/jobs`);
      setJobs(response.data.jobs || []);
    } catch (err) {
      console.error('Failed to load jobs:', err);
    } finally {
      setLoadingJobs(false);
    }
  };

  React.useEffect(() => {
    if (activeTab === 'jobs') {
      loadJobs();
    }
  }, [activeTab]);

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
    if (!jobName && e.target.files[0]) {
      setJobName(e.target.files[0].name.replace('.zip', ''));
    }
  };

  const toBase64 = (file) => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result.split(',')[1]);
      reader.onerror = error => reject(error);
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    setStatus('');
    setDownloadUrl('');

    try {
      const base64Content = await toBase64(file);

      const response = await apiClient.post(`${API_ENDPOINT}/generate`, {
        jobName: jobName || 'my-project',
        sourceType: 'upload',
        fileContent: base64Content,
        language: language
      });

      const newJob = {
        jobId: response.data.jobId,
        jobName: jobName,
        status: response.data.status,
        createdAt: new Date().toISOString()
      };

      setJobId(newJob.jobId);
      setStatus(newJob.status);
      setPolling(true);
      pollStatus(newJob.jobId);
    } catch (err) {
      setError(err.response?.data?.error || err.message);
    } finally {
      setLoading(false);
    }
  };

  const pollStatus = async (id) => {
    const maxAttempts = 60;
    let attempts = 0;

    const poll = async () => {
      try {
        const response = await apiClient.get(`${API_ENDPOINT}/status/${id}`);
        setStatus(response.data.status);
        setJobDetails(response.data);

        if (response.data.status === 'finished') {
          setPolling(false);
          if (response.data.downloadUrl) {
            setDownloadUrl(response.data.downloadUrl);
          } else if (response.data.statusDetails?.result === 'error') {
            setError('Job failed. Check CodeBuild logs for details.');
          }
        } else if (attempts < maxAttempts) {
          attempts++;
          setTimeout(poll, 5000);
        } else {
          setPolling(false);
          setError('Polling timeout. Job may still be processing.');
        }
      } catch (err) {
        setPolling(false);
        setError(err.response?.data?.error || err.message);
      }
    };

    poll();
  };

  const getStatusBadge = (jobStatus) => {
    switch (jobStatus) {
      case 'created': return <Badge bg="info">Queued</Badge>;
      case 'running': return <Badge bg="warning">Processing</Badge>;
      case 'finished': return <Badge bg="success">Completed</Badge>;
      default: return <Badge bg="secondary">{jobStatus}</Badge>;
    }
  };

  const watchJob = async (job) => {
    setJobId(job.jobId);
    setStatus(job.status);
    setJobName(job.jobName);
    setDownloadUrl(job.downloadUrl || '');
    setActiveTab('upload');

    // Fetch full job details
    try {
      const response = await apiClient.get(`${API_ENDPOINT}/status/${job.jobId}`);
      setJobDetails(response.data);
    } catch (err) {
      console.error('Failed to fetch job details:', err);
    }

    if (job.status !== 'finished') {
      setPolling(true);
      pollStatus(job.jobId);
    }
  };

  const deleteJob = async (jobId) => {
    if (!window.confirm('Are you sure you want to delete this job?')) {
      return;
    }

    try {
      await apiClient.delete(`${API_ENDPOINT}/jobs/${jobId}`);
      loadJobs();
    } catch (err) {
      setError(err.response?.data?.error || err.message);
    }
  };

  return (
    <div className="bg-light min-vh-100 py-5">
      <Container>
        <Row className="justify-content-center">
          <Col md={10}>
            <Card className="shadow-lg">
              <Card.Header className="bg-primary text-white">
                <h3 className="mb-0">
                  <i className="bi bi-file-earmark-code"></i> Java Docs AI Generator
                </h3>
                <small>Powered by Amazon Bedrock</small>
              </Card.Header>

              <Nav variant="tabs" className="mt-0">
                <Nav.Item>
                  <Nav.Link active={activeTab === 'upload'} onClick={() => setActiveTab('upload')}>
                    <i className="bi bi-upload"></i> Upload
                  </Nav.Link>
                </Nav.Item>
                <Nav.Item>
                  <Nav.Link active={activeTab === 'jobs'} onClick={() => setActiveTab('jobs')}>
                    <i className="bi bi-list-task"></i> All Jobs
                  </Nav.Link>
                </Nav.Item>
              </Nav>

              <Card.Body className="p-4">
                {activeTab === 'upload' ? (
                  <>
                    {error && <Alert variant="danger" dismissible onClose={() => setError('')}>{error}</Alert>}

                    <Form onSubmit={handleSubmit}>
                      <Form.Group className="mb-3">
                        <Form.Label>Project Name</Form.Label>
                        <Form.Control
                          type="text"
                          placeholder="my-java-project"
                          value={jobName}
                          onChange={(e) => setJobName(e.target.value)}
                          required
                        />
                      </Form.Group>

                      <Form.Group className="mb-3">
                        <Form.Label>Upload ZIP File</Form.Label>
                        <Form.Control
                          type="file"
                          accept=".zip"
                          onChange={handleFileChange}
                          required
                        />
                        <Form.Text className="text-muted">
                          Upload a ZIP file containing your Java project source code
                        </Form.Text>
                      </Form.Group>

                      <Form.Group className="mb-3">
                        <Form.Label>Documentation Language</Form.Label>
                        <Form.Select value={language} onChange={(e) => setLanguage(e.target.value)}>
                          <option value="en">English</option>
                          <option value="pt">Portuguese (pt-BR)</option>
                        </Form.Select>
                      </Form.Group>

                      <Button
                        variant="primary"
                        type="submit"
                        disabled={loading || polling}
                        className="w-100"
                      >
                        {loading ? 'Uploading...' : polling ? 'Processing...' : 'Generate Documentation'}
                      </Button>
                    </Form>

                    {jobId && (
                      <Card className="mt-4 border-primary">
                        <Card.Body>
                          <h5>Job Status {getStatusBadge(status)}</h5>
                          <p className="mb-2"><strong>Job ID:</strong> <code>{jobId}</code></p>

                          {polling && (
                            <div className="mt-3">
                              <ProgressBar animated now={100} label="Processing..." />
                              <small className="text-muted d-block mt-2">
                                This may take 1-2 minutes. Please wait...
                              </small>
                            </div>
                          )}

                          {jobDetails && (
                            <div className="mt-3">
                              <Button
                                variant="link"
                                size="sm"
                                onClick={() => setShowDetails(!showDetails)}
                                className="p-0"
                              >
                                <i className={`bi bi-chevron-${showDetails ? 'up' : 'down'}`}></i> View Details
                              </Button>
                              
                              {showDetails && (
                                <Card className="mt-2 bg-light">
                                  <Card.Body className="p-3">
                                    <small>
                                      <div><strong>Job ID:</strong> <code>{jobDetails.jobId}</code></div>
                                      <div><strong>Job Name:</strong> {jobDetails.jobName}</div>
                                      <div><strong>Status:</strong> {jobDetails.status}</div>
                                      <div><strong>Created:</strong> {new Date(jobDetails.createdAt).toLocaleString()}</div>
                                      {jobDetails.updatedAt && (
                                        <div><strong>Updated:</strong> {new Date(jobDetails.updatedAt).toLocaleString()}</div>
                                      )}
                                      {jobDetails.buildId && (
                                        <div><strong>Build ID:</strong> <code className="small">{jobDetails.buildId}</code></div>
                                      )}
                                      {jobDetails.inputPath && (
                                        <div><strong>Input:</strong> <code className="small">{jobDetails.inputPath}</code></div>
                                      )}
                                    </small>
                                  </Card.Body>
                                </Card>
                              )}
                            </div>
                          )}

                          {downloadUrl && (
                            <div className="mt-3">
                              <Alert variant="success">
                                <Alert.Heading>Documentation Ready!</Alert.Heading>
                                <p>Your AI-generated documentation is ready for download.</p>
                                <hr />
                                <Button
                                  variant="success"
                                  href={downloadUrl}
                                  target="_blank"
                                  className="w-100"
                                >
                                  <i className="bi bi-download"></i> Download Documentation
                                </Button>
                              </Alert>
                            </div>
                          )}
                        </Card.Body>
                      </Card>
                    )}
                  </>
                ) : (
                  <div>
                    <div className="d-flex justify-content-between align-items-center mb-3">
                      <h5 className="mb-0">All Jobs</h5>
                      <Button variant="outline-primary" size="sm" onClick={loadJobs} disabled={loadingJobs}>
                        <i className="bi bi-arrow-clockwise"></i> {loadingJobs ? 'Loading...' : 'Refresh'}
                      </Button>
                    </div>
                    {jobs.length === 0 ? (
                      <Alert variant="info">
                        {loadingJobs ? 'Loading jobs...' : 'No jobs found.'}
                      </Alert>
                    ) : (
                      <div className="list-group">
                        {jobs.map((job) => (
                          <div key={job.jobId} className="list-group-item">
                            <div className="d-flex justify-content-between align-items-center">
                              <div>
                                <h6 className="mb-1">{job.jobName}</h6>
                                <small className="text-muted">
                                  <code>{job.jobId}</code>
                                </small>
                                <div className="mt-1">
                                  {getStatusBadge(job.status)}
                                  <small className="text-muted ms-2">
                                    {new Date(job.createdAt).toLocaleString()}
                                  </small>
                                </div>
                              </div>
                              <div>
                                {job.status === 'finished' && job.downloadUrl ? (
                                  <>
                                    <Button
                                      variant="info"
                                      size="sm"
                                      onClick={() => watchJob(job)}
                                      className="me-2"
                                    >
                                      <i className="bi bi-info-circle"></i> Details
                                    </Button>
                                    <Button
                                      variant="success"
                                      size="sm"
                                      href={job.downloadUrl}
                                      target="_blank"
                                      className="me-2"
                                    >
                                      <i className="bi bi-download"></i> Download
                                    </Button>
                                    <Button
                                      variant="outline-danger"
                                      size="sm"
                                      onClick={() => deleteJob(job.jobId)}
                                    >
                                      <i className="bi bi-trash"></i>
                                    </Button>
                                  </>
                                ) : (
                                  <>
                                    <Button
                                      variant="primary"
                                      size="sm"
                                      onClick={() => watchJob(job)}
                                      className="me-2"
                                    >
                                      <i className="bi bi-eye"></i> Watch
                                    </Button>
                                    <Button
                                      variant="outline-danger"
                                      size="sm"
                                      onClick={() => deleteJob(job.jobId)}
                                    >
                                      <i className="bi bi-trash"></i>
                                    </Button>
                                  </>
                                )}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </Card.Body>
              <Card.Footer className="text-muted text-center">
                <small>UnB/CIC Research Initiative</small>
              </Card.Footer>
            </Card>
          </Col>
        </Row>
      </Container>
    </div>
  );
}

export default App;

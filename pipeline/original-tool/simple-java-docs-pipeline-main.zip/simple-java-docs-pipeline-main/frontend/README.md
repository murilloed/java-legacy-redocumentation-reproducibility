# Java Docs AI Generator - Frontend

Beautiful React frontend for the AI-powered Java documentation generator.

## Features

- 📤 **Drag & Drop Upload**: Upload ZIP files containing Java projects
- 🤖 **AI-Powered**: Uses Amazon Bedrock with Claude Opus 4.5
- ⏱️ **Real-time Status**: Automatic polling for job status
- 📥 **One-Click Download**: Download generated documentation
- 🎨 **Beautiful UI**: Bootstrap-based responsive design

## Deployment

The frontend is automatically deployed via Terraform to:
- **S3**: Static hosting
- **CloudFront**: Global CDN distribution

### Access

Frontend URL: **https://d3jrbvqaa34f0r.cloudfront.net**

## Local Development

```bash
cd frontend
npm install
npm start
```

The app will open at `http://localhost:3000`

### Environment Variables

Create `.env.local`:
```
REACT_APP_API_ENDPOINT=https://hh7mmhvke0.execute-api.us-east-1.amazonaws.com/dev
```

## Usage

1. Enter a project name
2. Upload a ZIP file containing your Java project
3. Click "Generate Documentation"
4. Wait for processing (1-2 minutes)
5. Download the generated documentation

## Architecture

```
User → CloudFront → S3 (React App) → API Gateway → Lambda → ...
```

The frontend communicates with the backend API via CORS-enabled endpoints.

## Technologies

- **React 18**: Modern React with Hooks
- **Bootstrap 5**: Responsive UI framework
- **React-Bootstrap**: Bootstrap components for React
- **Axios**: HTTP client for API calls
- **CloudFront**: Global content delivery

## Build

```bash
npm run build
```

Builds the app for production to the `build` folder.

## Deploy

Deployment is automated via Terraform:

```bash
cd ../infra
terraform apply
```

This will:
1. Build the React app with the correct API endpoint
2. Upload to S3
3. Invalidate CloudFront cache

#!/usr/bin/env sh

java -jar target/docgen-ai-tool-1.0.0.jar run \
    --input /Users/rbonifacio/temp/sarsb/original \
    --output /Users/rbonifacio/temp/sarsb/destination \
    --useAnthropicApi \
    --useStructuralFilter \
    --useMetricsPrioritization \
    --docs javadoc \
    --metrics

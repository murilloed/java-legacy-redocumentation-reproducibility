# docgen-ai-tool

AI-powered documentation generator for Java projects using Amazon Bedrock.

## Overview

`docgen-ai-tool` automatically generates high-quality Javadocs and project documentation for Java codebases using Amazon Bedrock's AI models. It scans your Java project, identifies missing documentation, and generates contextually accurate Javadocs and Markdown documentation.

## Execution Flow

### Tool Execution Flow

```
1. Project Scanning (ManifestGenerator)
   ├─ Walks through Java source files
   ├─ Uses JavaParser to parse each .java file
   ├─ Extracts class/method/constructor metadata
   └─ Generates manifest.json with project structure

2. Javadoc Generation (JavadocInjector)
   ├─ Reads manifest.json
   ├─ For each class/method without Javadoc:
   │  ├─ Calls Amazon Bedrock (BedrockJavadocClient)
   │  │  ├─ Sends code context + metadata
   │  │  ├─ Retry logic: 3 attempts with exponential backoff (1s, 2s, 3s)
   │  │  └─ Returns AI-generated Javadoc
   │  ├─ Validates generated Javadoc (parameters, return types, exceptions)
   │  ├─ Injects using JavaParser's LexicalPreservingPrinter
   │  └─ Falls back to deterministic placeholder on failure
   ├─ Preserves original code formatting
   └─ Generates javadoc_report.json

3. Documentation Generation (DocsGenerator)
   ├─ Reads manifest.json + javadoc_report.json
   ├─ Calls Amazon Bedrock (BedrockDocsClient)
   │  ├─ Sends project context + structure
   │  ├─ Retry logic: 3 attempts with exponential backoff
   │  └─ Returns AI-generated documentation
   ├─ Generates README.md (overview, build instructions, components)
   ├─ Generates ARCHITECTURE.md (system design, data flow)
   ├─ Generates API.md (endpoints, interfaces)
   └─ Generates docs_generation_report.json

4. Output Structure
   ├─ code/ (source with injected Javadocs)
   ├─ analysis/ (JSON reports)
   │  ├─ manifest.json
   │  ├─ javadoc_report.json
   │  └─ docs_generation_report.json
   └─ docs/ (AI-generated documentation)
      ├─ README.md
      ├─ ARCHITECTURE.md
      └─ API.md
```

### Complete Pipeline Flow

```
1. Frontend (React)
   ├─ User uploads ZIP file
   ├─ Converts to base64
   └─ POST /generate with x-api-key header

2. API Gateway
   ├─ Validates x-api-key (Lambda Authorizer)
   ├─ Routes to Generate Lambda
   └─ Returns 202 Accepted

3. Generate Lambda
   ├─ Uploads ZIP to S3 input bucket
   ├─ Creates DynamoDB record (status: "created")
   ├─ Publishes message to SQS queue
   └─ Returns jobId

4. SQS Queue
   ├─ Holds message (15min visibility, 24h retention)
   └─ Triggers Process Job Lambda

5. Process Job Lambda
   ├─ Consumes SQS message
   ├─ Updates DynamoDB (status: "running")
   └─ Triggers CodeBuild with job parameters

6. CodeBuild
   ├─ Downloads docgen-ai-tool JAR from S3
   ├─ Downloads input ZIP from S3
   ├─ Extracts ZIP
   ├─ Runs: java -jar docgen-ai-tool.jar run --input ... --output ...
   │  ├─ Calls Amazon Bedrock for Javadocs
   │  ├─ Calls Amazon Bedrock for documentation
   │  └─ Generates output/ directory
   ├─ Zips output directory
   └─ Uploads to S3 output bucket

7. EventBridge
   ├─ Captures CodeBuild completion event
   └─ Triggers Status Update Lambda

8. Status Update Lambda
   ├─ Updates DynamoDB (status: "finished")
   └─ Sets downloadUrl (CloudFront URL)

9. Frontend Polling
   ├─ GET /status/{jobId} every 5 seconds
   ├─ Displays status updates
   └─ Shows download button when finished

10. Download
    ├─ User clicks download
    ├─ CloudFront serves from S3 output bucket
    └─ User receives generated documentation
```

## Features

- **AI-Generated Javadocs**: Uses Amazon Bedrock to generate contextual, accurate Javadocs for classes, methods, and constructors
- **Project Documentation**: Generates README, ARCHITECTURE, and API documentation
- **Validation & Fallback**: Validates AI-generated content and falls back to deterministic placeholders on failure
- **Retry Logic**: 3 attempts with exponential backoff (1s, 2s, 3s delays) for Bedrock calls
- **Safe & Deterministic**: Preserves code formatting using JavaParser's LexicalPreservingPrinter
- **Cost Controls**: Configurable limits on Bedrock API calls
- **Comprehensive Reporting**: Detailed JSON reports of all operations

## Requirements

- Java 17+
- Maven 3.6+
- AWS credentials configured (for Bedrock integration)
- Amazon Bedrock model access enabled

## Build

```bash
mvn clean package
```

This creates `target/docgen-ai-tool-1.0.0.jar`

## Usage

### Basic Usage (Deterministic Placeholders)

```bash
java -jar target/docgen-ai-tool-1.0.0.jar run \
  --input /path/to/java-project \
  --output /path/to/output
```

### With AI-Generated Javadocs

```bash
java -jar target/docgen-ai-tool-1.0.0.jar run \
  --input /path/to/java-project \
  --output /path/to/output \
  --useBedrock \
  --bedrockRegion us-east-1 \
  --bedrockModelId anthropic.claude-3-sonnet-20240229-v1:0
```

### With AI-Generated Documentation

```bash
java -jar target/docgen-ai-tool-1.0.0.jar run \
  --input /path/to/java-project \
  --output /path/to/output \
  --useBedrock \
  --useBedrockDocs \
  --bedrockRegion us-east-1 \
  --bedrockModelId anthropic.claude-3-sonnet-20240229-v1:0
```

## CLI Options

### Required
- `--input <path>` - Path to the Java project to process
- `--output <path>` - Path where output will be written

### Optional
- `--include <path>` - Subdirectory to scan (default: `src/main/java`)
- `--maxTargets <n>` - Maximum targets to process (default: 200)
- `--dryRun` - Generate manifest and docs without modifying source files

### Bedrock Javadoc Options
- `--useBedrock` - Enable AI-generated Javadocs
- `--bedrockRegion <region>` - AWS region for Bedrock (required with --useBedrock)
- `--bedrockModelId <modelId>` - Bedrock model ID (required with --useBedrock)
- `--maxBedrockCalls <n>` - Maximum Bedrock API calls (default: 200)
- `--bedrockTimeoutSeconds <n>` - Timeout for Bedrock calls (default: 30)

### Bedrock Documentation Options
- `--useBedrockDocs` - Enable AI-generated project documentation
- `--docsBedrockRegion <region>` - AWS region for docs (defaults to --bedrockRegion)
- `--docsBedrockModelId <modelId>` - Model ID for docs (defaults to --bedrockModelId)
- `--maxDocsBedrockCalls <n>` - Maximum docs Bedrock calls (default: 20)
- `--docsBedrockTimeoutSeconds <n>` - Timeout for docs calls (default: 30)

## Output Structure

```
output/
├── code/                          # Modified source with Javadocs
├── analysis/
│   ├── manifest.json             # Inventory of all public classes/methods
│   ├── javadoc_report.json       # Javadoc generation statistics
│   └── docs_generation_report.json  # Documentation generation statistics
└── docs/
    ├── README.md                 # Project overview and setup
    ├── ARCHITECTURE.md           # Architecture and components
    └── API.md                    # API documentation
```

## Supported Models

- **Anthropic Claude**: `anthropic.claude-3-sonnet-20240229-v1:0`, `anthropic.claude-3-5-sonnet-20240620-v1:0`, `anthropic.claude-3-haiku-20240307-v1:0`
- **Amazon Titan**: `amazon.titan-text-express-v1`

## AWS Credentials

The tool uses AWS SDK default credential chain:
- Environment variables (`AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`)
- AWS credentials file (`~/.aws/credentials`)
- IAM role (when running on EC2/ECS/Lambda)

### Required IAM Permissions

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": "bedrock:InvokeModel",
      "Resource": "arn:aws:bedrock:*::foundation-model/*"
    }
  ]
}
```

## Example

Process the sample `users-api` project:

```bash
java -jar target/docgen-ai-tool-1.0.0.jar run \
  --input ../users-api \
  --output ./output \
  --useBedrock \
  --useBedrockDocs \
  --bedrockRegion us-east-1 \
  --bedrockModelId anthropic.claude-3-sonnet-20240229-v1:0 \
  --maxBedrockCalls 50
```

## Validation

The tool validates all AI-generated content:

### Javadoc Validation
- Must be valid `/** ... */` format
- No Markdown fences
- `@param` tags must match method parameters
- `@return` only for non-void methods
- `@throws` only for declared exceptions
- Maximum 40 lines

### Documentation Validation
- Must contain all required headings
- Maximum 800 lines per file
- Must be valid Markdown

## License

This project is part of the UnB/CIC research initiative.

## Authors

- Universidade de Brasília (UnB)
- Centro de Informática (CIC)

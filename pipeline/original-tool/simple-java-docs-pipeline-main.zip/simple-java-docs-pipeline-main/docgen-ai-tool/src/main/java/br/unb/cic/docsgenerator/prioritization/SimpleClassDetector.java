package br.unb.cic.docsgenerator.prioritization;

import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;

import java.util.Set;

public class SimpleClassDetector {

    // Annotations that strongly signal a data/DTO class
    private static final Set<String> DATA_CLASS_ANNOTATIONS = Set.of(
        "Data", "Value", "Getter", "Setter", "Builder", "SuperBuilder",
        "AllArgsConstructor", "NoArgsConstructor", "RequiredArgsConstructor",
        "Entity", "Embeddable", "MappedSuperclass", "Table",
        "JsonProperty", "JsonInclude", "JsonIgnoreProperties"
    );

    // Public methods that are purely boilerplate
    private static final Set<String> BOILERPLATE_METHOD_NAMES = Set.of(
        "equals", "hashCode", "toString", "canEqual"
    );

    public static boolean isSimple(ClassOrInterfaceDeclaration cls) {
        boolean hasDataAnnotation = cls.getAnnotations().stream()
                .anyMatch(a -> DATA_CLASS_ANNOTATIONS.contains(a.getNameAsString()));
        if (hasDataAnnotation) return true;

        // A class with no public methods at all (pure field container) is simple
        var publicMethods = cls.getMethods().stream()
                .filter(MethodDeclaration::isPublic)
                .toList();
        if (publicMethods.isEmpty()) return true;

        return publicMethods.stream().allMatch(SimpleClassDetector::isAccessorOrBoilerplate);
    }

    private static boolean isAccessorOrBoilerplate(MethodDeclaration method) {
        String name = method.getNameAsString();
        int paramCount = method.getParameters().size();
        String returnType = method.getTypeAsString();

        if (BOILERPLATE_METHOD_NAMES.contains(name)) return true;
        // getter: getFoo() or isFoo()
        if (name.startsWith("get") && name.length() > 3 && paramCount == 0 && !"void".equals(returnType)) return true;
        if (name.startsWith("is") && name.length() > 2 && paramCount == 0
                && ("boolean".equals(returnType) || "Boolean".equals(returnType))) return true;
        // setter: setFoo(value)
        if (name.startsWith("set") && name.length() > 3 && paramCount == 1 && "void".equals(returnType)) return true;
        // builder-style wither: withFoo(value)
        if (name.startsWith("with") && name.length() > 4 && paramCount == 1) return true;

        return false;
    }
}

package br.unb.cic.docsgenerator.docs;

import br.unb.cic.docsgenerator.ai.DocsClient;
import br.unb.cic.docsgenerator.bedrock.DocsContext;
import br.unb.cic.docsgenerator.bedrock.DocsValidator;
import br.unb.cic.docsgenerator.manifest.Manifest;
import br.unb.cic.docsgenerator.manifest.ManifestEntry;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.Locale;
import java.util.stream.Collectors;

public class DocsGenerator {
    private final Manifest manifest;
    private final Path codeRoot;
    private final Path inputRoot;
    private final DocsClient docsClient;
    private final String language;
    private final Set<String> enabledDocs;

    public DocsGenerator(Manifest manifest, Path codeRoot, Path inputRoot, DocsClient docsClient,
                         String language, Set<String> enabledDocs) {
        this.manifest = manifest;
        this.codeRoot = codeRoot;
        this.inputRoot = inputRoot;
        this.docsClient = docsClient;
        this.language = language;
        this.enabledDocs = enabledDocs;
    }

    private boolean isEnabled(String docType) {
        return enabledDocs.isEmpty() || enabledDocs.contains(docType.toLowerCase(Locale.ROOT));
    }

    public void generate(Path docsDir, Path analysisDir) throws IOException {
        if (docsClient != null) {
            generateWithAI(docsDir, analysisDir);
        } else {
            generatePlaceholder(docsDir);
        }
    }

    private void generateWithAI(Path docsDir, Path analysisDir) throws IOException {
        System.out.println("Generating documentation with AI (language=" + language + ")...");

        List<Map<String, String>> failures = new ArrayList<>();
        int succeeded = 0;

        record DocTask(String type, Path output) {}
        List<DocTask> tasks = List.of(
                new DocTask("README",       docsDir.resolve("README.md")),
                new DocTask("ARCHITECTURE", docsDir.resolve("ARCHITECTURE.md")),
                new DocTask("API",          docsDir.resolve("API.md"))
        ).stream().filter(t -> isEnabled(t.type())).toList();

        DocsContext context = buildDocsContext();

        for (DocTask task : tasks) {
            if (generateDoc(context, task.output(), task.type(), failures)) {
                succeeded++;
            }
        }

        // Per-controller manual test generation
        int manualTestsSucceeded = 0;
        int manualTestsFailed = 0;
        if (isEnabled("manual-tests") && !context.getControllerContexts().isEmpty()) {
            Path manualTestsDir = docsDir.resolve("manual-tests");
            Files.createDirectories(manualTestsDir);
            StringBuilder index = new StringBuilder();
            index.append("# Manual Test Cases\n\n");
            index.append("Test cases are organized per controller:\n\n");

            for (DocsContext.ControllerContext ctrl : context.getControllerContexts()) {
                String fileName = ctrl.getControllerName() + ".md";
                Path output = manualTestsDir.resolve(fileName);
                System.out.println("  Generating manual tests for " + ctrl.getControllerName() + "...");
                if (generateManualTestsForController(ctrl, output, failures)) {
                    manualTestsSucceeded++;
                    index.append("- [").append(ctrl.getControllerName()).append("](manual-tests/")
                         .append(fileName).append(")\n");
                } else {
                    manualTestsFailed++;
                    index.append("- ").append(ctrl.getControllerName()).append(" _(generation failed)_\n");
                }
            }
            Files.writeString(docsDir.resolve("MANUAL_TESTS.md"), index.toString());
            System.out.println("Manual tests: " + manualTestsSucceeded + " succeeded, "
                    + manualTestsFailed + " failed across "
                    + context.getControllerContexts().size() + " controllers");
        }

        int failed = tasks.size() - succeeded;

        Map<String, Object> report = new HashMap<>();
        report.put("language", language);
        report.put("attemptedDocs", tasks.size());
        report.put("succeededDocs", succeeded);
        report.put("failedDocs", failed);
        report.put("manualTestsControllers", context.getControllerContexts().size());
        report.put("manualTestsSucceeded", manualTestsSucceeded);
        report.put("manualTestsFailed", manualTestsFailed);
        report.put("failures", failures);

        ObjectMapper mapper = new ObjectMapper();
        mapper.enable(SerializationFeature.INDENT_OUTPUT);
        mapper.writeValue(analysisDir.resolve("docs_generation_report.json").toFile(), report);

        if (failed == 0) {
            System.out.println("Docs generation: all " + succeeded + " documents succeeded");
        } else {
            System.err.println("Docs generation: " + succeeded + " succeeded, " + failed + " failed (placeholder written for failures)");
            for (Map<String, String> f : failures) {
                System.err.println("  [" + f.get("doc") + "] " + f.get("reason") + ": " + f.get("detail"));
            }
            System.err.println("  Full report: " + analysisDir.resolve("docs_generation_report.json"));
        }
    }

    private boolean generateDoc(DocsContext context, Path output, String docType, List<Map<String, String>> failures) {
        String content;
        try {
            content = switch (docType) {
                case "README"        -> docsClient.generateReadme(context);
                case "ARCHITECTURE"  -> docsClient.generateArchitecture(context);
                case "API"           -> docsClient.generateApi(context);
                default              -> throw new IllegalArgumentException("Unknown doc type: " + docType);
            };
        } catch (Exception e) {
            recordFailure(failures, docType, "AI call failed", e.getMessage());
            writePlaceholderSilently(output, docType);
            return false;
        }

        DocsValidator.ValidationResult validation = validate(content, docType);

        if (!validation.isValid()) {
            // AI skipped required sections — append stubs and re-validate once
            List<String> missing = DocsValidator.findMissingHeadings(content, docType, language);
            if (!missing.isEmpty()) {
                StringBuilder fixed = new StringBuilder(content);
                for (String heading : missing) {
                    fixed.append("\n\n").append(heading).append("\n\n")
                         .append(stubBody(heading, language));
                }
                String fixedContent = fixed.toString();
                DocsValidator.ValidationResult recheck = validate(fixedContent, docType);
                if (recheck.isValid()) {
                    System.err.println("Warning: [" + docType + "] AI omitted "
                            + missing.size() + " section(s); stubs were appended: "
                            + String.join(", ", missing));
                    content = fixedContent;
                    validation = recheck;
                }
            }
        }

        if (!validation.isValid()) {
            recordFailure(failures, docType, "Validation failed", validation.getErrorMessage());
            writePlaceholderSilently(output, docType);
            return false;
        }

        try {
            Files.writeString(output, content);
            return true;
        } catch (IOException e) {
            recordFailure(failures, docType, "Write failed", e.getMessage());
            return false;
        }
    }

    private boolean generateManualTestsForController(DocsContext.ControllerContext ctrl,
                                                     Path output,
                                                     List<Map<String, String>> failures) {
        String content;
        try {
            content = docsClient.generateManualTestsForController(ctrl, language);
        } catch (Exception e) {
            recordFailure(failures, "MANUAL_TESTS/" + ctrl.getControllerName(), "AI call failed", e.getMessage());
            return false;
        }

        DocsValidator.ValidationResult validation = DocsValidator.validateManualTests(content, language);
        if (!validation.isValid()) {
            List<String> missing = DocsValidator.findMissingHeadings(content, "MANUAL_TESTS", language);
            if (!missing.isEmpty()) {
                StringBuilder fixed = new StringBuilder(content);
                for (String heading : missing) {
                    fixed.append("\n\n").append(heading).append("\n\n").append(stubBody(heading, language));
                }
                DocsValidator.ValidationResult recheck = DocsValidator.validateManualTests(fixed.toString(), language);
                if (recheck.isValid()) {
                    content = fixed.toString();
                    validation = recheck;
                }
            }
        }

        if (!validation.isValid()) {
            recordFailure(failures, "MANUAL_TESTS/" + ctrl.getControllerName(),
                    "Validation failed", validation.getErrorMessage());
            return false;
        }

        try {
            Files.writeString(output, content);
            return true;
        } catch (IOException e) {
            recordFailure(failures, "MANUAL_TESTS/" + ctrl.getControllerName(), "Write failed", e.getMessage());
            return false;
        }
    }

    private DocsValidator.ValidationResult validate(String content, String docType) {
        return switch (docType) {
            case "README"        -> DocsValidator.validateReadme(content, language);
            case "ARCHITECTURE"  -> DocsValidator.validateArchitecture(content, language);
            case "API"           -> DocsValidator.validateApi(content, language);
            default              -> DocsValidator.ValidationResult.success();
        };
    }

    private String stubBody(String heading, String lang) {
        String text = heading.replaceFirst("^#+\\s*", "").toLowerCase(Locale.ROOT);
        boolean pt = "pt".equals(lang);

        if (text.contains("data contracts") || text.contains("contratos de dados")) {
            return pt
                ? "Os payloads da API seguem as convenções REST padrão com codificação JSON. "
                    + "Consulte o código-fonte e a documentação dos endpoints individuais para definições detalhadas de schema.\n"
                : "API payloads follow standard REST conventions with JSON encoding. "
                    + "Refer to the source code and individual endpoint documentation for detailed schema definitions.\n";
        }
        if (text.contains("error handling") || text.contains("tratamento de erros")) {
            return pt
                ? "A API retorna códigos de status HTTP padrão:\n\n"
                    + "- `400 Bad Request` — entrada inválida\n"
                    + "- `401 Unauthorized` — autenticação necessária\n"
                    + "- `403 Forbidden` — permissão insuficiente\n"
                    + "- `404 Not Found` — recurso não encontrado\n"
                    + "- `500 Internal Server Error` — falha inesperada no servidor\n"
                : "The API returns standard HTTP status codes:\n\n"
                    + "- `400 Bad Request` — invalid input\n"
                    + "- `401 Unauthorized` — authentication required\n"
                    + "- `403 Forbidden` — insufficient permissions\n"
                    + "- `404 Not Found` — resource not found\n"
                    + "- `500 Internal Server Error` — unexpected server-side failure\n";
        }
        if (text.contains("manual test") || text.contains("casos de teste")) {
            return pt
                ? "| Passo | Ação | Verificação |\n|-------|------|-------------|\n"
                    + "| 1 | Enviar requisição válida | Resposta `200 OK` |\n"
                : "| Step | Action | Verification |\n|------|--------|---------------|\n"
                    + "| 1 | Send valid request | Response `200 OK` |\n";
        }
        return pt ? "_Consulte o código-fonte para mais detalhes._\n"
                  : "_Refer to the source code for details._\n";
    }

    private void recordFailure(List<Map<String, String>> failures, String doc, String reason, String detail) {
        Map<String, String> f = new HashMap<>();
        f.put("doc", doc);
        f.put("reason", reason);
        f.put("detail", detail != null ? detail : "(no detail)");
        failures.add(f);
    }

    private void writePlaceholderSilently(Path output, String docType) {
        try {
            generatePlaceholderDoc(output, docType);
        } catch (IOException e) {
            System.err.println("Failed to write placeholder for " + docType + ": " + e.getMessage());
        }
    }

    private DocsContext buildDocsContext() throws IOException {
        DocsContext context = new DocsContext();

        String projectName = inputRoot.getFileName().toString();
        context.setProjectName(projectName);

        Set<String> packages = manifest.getEntries().stream()
                .map(ManifestEntry::getFqcn)
                .map(this::extractPackage)
                .filter(pkg -> !pkg.equals("(default)"))
                .map(this::getTopLevelPackage)
                .collect(Collectors.toSet());
        context.setTopLevelPackages(new ArrayList<>(packages));

        List<DocsContext.PublicType> publicTypes = manifest.getEntries().stream()
                .filter(e -> "CLASS".equals(e.getKind()) || "INTERFACE".equals(e.getKind()) || "ENUM".equals(e.getKind()))
                .map(e -> new DocsContext.PublicType(e.getFqcn(), e.getKind(), e.getFilePath()))
                .collect(Collectors.toList());
        context.setPublicTypes(publicTypes);

        List<DocsContext.HttpEndpoint> endpoints = new ArrayList<>();
        Map<String, ManifestEntry> controllers = manifest.getEntries().stream()
                .filter(e -> "CLASS".equals(e.getKind()))
                .filter(e -> e.getAnnotations().stream().anyMatch(a -> a.equals("RestController") || a.equals("Controller")))
                .collect(Collectors.toMap(ManifestEntry::getFqcn, e -> e));

        manifest.getEntries().stream()
                .filter(e -> "METHOD".equals(e.getKind()))
                .filter(e -> controllers.containsKey(e.getFqcn()))
                .forEach(method -> {
                    String httpMethod = detectHttpMethod(method.getAnnotations());
                    String path = extractPath(controllers.get(method.getFqcn()), method);
                    String controller = extractClassName(method.getFqcn());
                    String methodName = extractMethodName(method.getMemberSignature());
                    String signature = method.getMemberSignature();
                    endpoints.add(new DocsContext.HttpEndpoint(httpMethod, path, controller, methodName, signature));
                });

        // Build per-controller contexts with source code for manual test generation
        Map<String, List<DocsContext.HttpEndpoint>> endpointsByController = endpoints.stream()
                .collect(Collectors.groupingBy(DocsContext.HttpEndpoint::getController));

        List<DocsContext.ControllerContext> controllerContexts = new ArrayList<>();
        for (Map.Entry<String, ManifestEntry> entry : controllers.entrySet()) {
            String controllerName = extractClassName(entry.getKey());
            String filePath = entry.getValue().getFilePath();
            String sourceCode = readSourceSafely(inputRoot.resolve(filePath));
            List<DocsContext.HttpEndpoint> controllerEndpoints =
                    endpointsByController.getOrDefault(controllerName, List.of());
            controllerContexts.add(new DocsContext.ControllerContext(
                    controllerName, filePath, sourceCode, controllerEndpoints));
        }
        context.setControllerContexts(controllerContexts);
        context.setHttpEndpoints(endpoints);

        List<String> services = manifest.getEntries().stream()
                .filter(e -> "CLASS".equals(e.getKind()))
                .filter(e -> e.getAnnotations().contains("Service") || e.getFqcn().endsWith("Service"))
                .map(e -> extractClassName(e.getFqcn()))
                .collect(Collectors.toList());
        context.setServices(services);

        List<String> repositories = manifest.getEntries().stream()
                .filter(e -> "CLASS".equals(e.getKind()))
                .filter(e -> e.getAnnotations().contains("Repository") || e.getFqcn().endsWith("Repository"))
                .map(e -> extractClassName(e.getFqcn()))
                .collect(Collectors.toList());
        context.setRepositories(repositories);

        Set<String> files = manifest.getEntries().stream()
                .map(ManifestEntry::getFilePath)
                .collect(Collectors.toSet());
        context.setFileCount(files.size());

        context.setPublicTypeCount((int) manifest.getEntries().stream()
                .filter(e -> "CLASS".equals(e.getKind()) || "INTERFACE".equals(e.getKind()) || "ENUM".equals(e.getKind()))
                .count());

        context.setPublicMethodCount((int) manifest.getEntries().stream()
                .filter(e -> "METHOD".equals(e.getKind()))
                .count());

        context.setHasPomXml(Files.exists(inputRoot.resolve("pom.xml")));

        manifest.getEntries().stream()
                .filter(e -> "CLASS".equals(e.getKind()))
                .filter(e -> e.getAnnotations().contains("SpringBootApplication"))
                .findFirst()
                .ifPresent(e -> context.setMainClass(e.getFqcn()));

        return context;
    }

    private String readSourceSafely(Path file) {
        try {
            return Files.exists(file) ? Files.readString(file) : "";
        } catch (IOException e) {
            return "";
        }
    }

    private void generatePlaceholder(Path docsDir) throws IOException {
        if (isEnabled("readme"))        generatePlaceholderDoc(docsDir.resolve("README.generated.md"), "README");
        if (isEnabled("architecture"))  generatePlaceholderDoc(docsDir.resolve("ARCHITECTURE.generated.md"), "ARCHITECTURE");
        if (isEnabled("api"))           generatePlaceholderDoc(docsDir.resolve("API.generated.md"), "API");
        if (isEnabled("manual-tests"))  generateManualTestsPlaceholder(docsDir.resolve("MANUAL_TESTS.md"));
    }

    private void generatePlaceholderDoc(Path output, String docType) throws IOException {
        switch (docType) {
            case "README"       -> generateReadmePlaceholder(output);
            case "ARCHITECTURE" -> generateArchitecturePlaceholder(output);
            case "API"          -> generateApiPlaceholder(output);
        }
    }

    private void generateReadmePlaceholder(Path output) throws IOException {
        StringBuilder sb = new StringBuilder();
        sb.append("# Project Documentation\n\n");
        sb.append("This documentation was automatically generated.\n\n");
        sb.append("## Overview\n\n");
        sb.append("Total classes: ").append(countByKind("CLASS")).append("\n");
        sb.append("Total methods: ").append(countByKind("METHOD")).append("\n");
        sb.append("Total constructors: ").append(countByKind("CONSTRUCTOR")).append("\n");
        sb.append("Total enums: ").append(countByKind("ENUM")).append("\n\n");
        sb.append("## Files\n\n");

        manifest.getEntries().stream()
                .map(ManifestEntry::getFilePath)
                .distinct()
                .sorted()
                .forEach(file -> sb.append("- ").append(file).append("\n"));

        Files.writeString(output, sb.toString());
    }

    private void generateArchitecturePlaceholder(Path output) throws IOException {
        StringBuilder sb = new StringBuilder();
        sb.append("# Architecture\n\n");

        Map<String, List<ManifestEntry>> byPackage = manifest.getEntries().stream()
                .filter(e -> "CLASS".equals(e.getKind()) || "ENUM".equals(e.getKind()))
                .collect(Collectors.groupingBy(e -> extractPackage(e.getFqcn())));

        sb.append("## Packages\n\n");
        byPackage.keySet().stream().sorted().forEach(pkg -> {
            sb.append("### ").append(pkg).append("\n\n");
            byPackage.get(pkg).forEach(entry -> {
                sb.append("- **").append(extractClassName(entry.getFqcn())).append("** (").append(entry.getKind()).append(")\n");
            });
            sb.append("\n");
        });

        Files.writeString(output, sb.toString());
    }

    private void generateApiPlaceholder(Path output) throws IOException {
        StringBuilder sb = new StringBuilder();
        sb.append("# API Documentation\n\n");

        boolean hasSpring = detectSpring();

        if (hasSpring) {
            sb.append("## REST Endpoints\n\n");
            generateSpringEndpoints(sb);
        } else {
            sb.append("## Public Interfaces\n\n");
            generatePublicInterfaces(sb);
        }

        Files.writeString(output, sb.toString());
    }

    private void generateManualTestsPlaceholder(Path output) throws IOException {
        StringBuilder sb = new StringBuilder();
        sb.append("# Manual Test Cases\n\n");
        sb.append("_AI-generated test cases are not available. Generate with `--useAnthropicApi` or `--useBedrock`._\n\n");

        manifest.getEntries().stream()
                .filter(e -> "CLASS".equals(e.getKind()))
                .filter(e -> e.getAnnotations().stream().anyMatch(a -> a.equals("RestController") || a.equals("Controller")))
                .forEach(controller -> {
                    sb.append("## ").append(extractClassName(controller.getFqcn())).append("\n\n");
                    sb.append("**Purpose:** _To be described._\n\n");
                    sb.append("| Step | Action | Verification |\n");
                    sb.append("|------|--------|---------------|\n");
                    sb.append("| 1 | _Define action_ | _Define expected result_ |\n\n");
                });
        Files.writeString(output, sb.toString());
    }

    private boolean detectSpring() {
        return manifest.getEntries().stream()
                .anyMatch(e -> e.getAnnotations().stream()
                        .anyMatch(a -> a.equals("RestController") || a.equals("Controller")));
    }

    private void generateSpringEndpoints(StringBuilder sb) {
        Map<String, List<ManifestEntry>> controllers = manifest.getEntries().stream()
                .filter(e -> "CLASS".equals(e.getKind()))
                .filter(e -> e.getAnnotations().stream().anyMatch(a -> a.equals("RestController") || a.equals("Controller")))
                .collect(Collectors.toMap(ManifestEntry::getFqcn, e -> new ArrayList<>()));

        manifest.getEntries().stream()
                .filter(e -> "METHOD".equals(e.getKind()))
                .forEach(method -> {
                    String classFqcn = method.getFqcn();
                    if (controllers.containsKey(classFqcn)) {
                        controllers.get(classFqcn).add(method);
                    }
                });

        controllers.forEach((fqcn, methods) -> {
            sb.append("### ").append(extractClassName(fqcn)).append("\n\n");

            ManifestEntry classEntry = manifest.getEntries().stream()
                    .filter(e -> e.getFqcn().equals(fqcn) && "CLASS".equals(e.getKind()))
                    .findFirst()
                    .orElse(null);

            String classPath = classEntry != null ? extractPath(classEntry, null) : "";

            methods.forEach(method -> {
                String httpMethod = detectHttpMethod(method.getAnnotations());
                String methodPath = extractPath(null, method);
                String fullPath = classPath + methodPath;

                sb.append("- **").append(httpMethod).append("** `").append(fullPath).append("`\n");
                sb.append("  - Method: `").append(extractMethodName(method.getMemberSignature())).append("`\n");
            });
            sb.append("\n");
        });
    }

    private String extractPath(ManifestEntry classEntry, ManifestEntry methodEntry) {
        if (methodEntry != null) {
            for (String ann : methodEntry.getAnnotations()) {
                if (ann.equals("GetMapping")) return "";
                if (ann.equals("PostMapping")) return "";
                if (ann.equals("PutMapping")) return "/{id}";
                if (ann.equals("DeleteMapping")) return "/{id}";
                if (ann.equals("PatchMapping")) return "/{id}";
            }
        }
        if (classEntry != null) {
            if (classEntry.getAnnotations().contains("RequestMapping")) {
                return "/api/users";
            }
        }
        return "";
    }

    private void generatePublicInterfaces(StringBuilder sb) {
        Map<String, List<ManifestEntry>> byPackage = manifest.getEntries().stream()
                .filter(e -> "CLASS".equals(e.getKind()))
                .collect(Collectors.groupingBy(e -> extractPackage(e.getFqcn())));

        byPackage.keySet().stream().sorted().forEach(pkg -> {
            sb.append("### ").append(pkg).append("\n\n");
            byPackage.get(pkg).forEach(classEntry -> {
                sb.append("#### ").append(extractClassName(classEntry.getFqcn())).append("\n\n");

                List<ManifestEntry> methods = manifest.getEntries().stream()
                        .filter(e -> "METHOD".equals(e.getKind()))
                        .filter(e -> e.getFqcn().equals(classEntry.getFqcn()))
                        .toList();

                methods.forEach(method -> {
                    sb.append("- `").append(method.getMemberSignature()).append("`\n");
                });
                sb.append("\n");
            });
        });
    }

    private String detectHttpMethod(List<String> annotations) {
        if (annotations.contains("GetMapping")) return "GET";
        if (annotations.contains("PostMapping")) return "POST";
        if (annotations.contains("PutMapping")) return "PUT";
        if (annotations.contains("DeleteMapping")) return "DELETE";
        if (annotations.contains("PatchMapping")) return "PATCH";
        if (annotations.contains("RequestMapping")) return "REQUEST";
        return "UNKNOWN";
    }

    private String getTopLevelPackage(String pkg) {
        int firstDot = pkg.indexOf('.');
        if (firstDot > 0) {
            int secondDot = pkg.indexOf('.', firstDot + 1);
            if (secondDot > 0) {
                return pkg.substring(0, secondDot);
            }
        }
        return pkg;
    }

    private String extractMethodName(String signature) {
        if (signature == null) return "";
        int start = signature.indexOf(' ') + 1;
        int end = signature.indexOf('(');
        return signature.substring(start, end);
    }

    private String extractPackage(String fqcn) {
        int lastDot = fqcn.lastIndexOf('.');
        return lastDot > 0 ? fqcn.substring(0, lastDot) : "(default)";
    }

    private String extractClassName(String fqcn) {
        int lastDot = fqcn.lastIndexOf('.');
        return lastDot > 0 ? fqcn.substring(lastDot + 1) : fqcn;
    }

    private long countByKind(String kind) {
        return manifest.getEntries().stream()
                .filter(e -> kind.equals(e.getKind()))
                .count();
    }
}

package br.unb.cic.docsgenerator.manifest;

import java.util.ArrayList;
import java.util.List;

public class Manifest {
    private List<ManifestEntry> entries = new ArrayList<>();

    public void addEntry(ManifestEntry entry) {
        entries.add(entry);
    }

    public List<ManifestEntry> getEntries() {
        return entries;
    }

    public void setEntries(List<ManifestEntry> entries) {
        this.entries = entries;
    }
}

package br.unb.cic.docsgenerator.anthropic;

import br.unb.cic.docsgenerator.ai.PrioritizationClient;
import br.unb.cic.docsgenerator.manifest.ManifestEntry;
import com.anthropic.client.AnthropicClient;
import com.anthropic.client.okhttp.AnthropicOkHttpClient;
import com.anthropic.models.messages.MessageCreateParams;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.*;
import java.util.stream.Collectors;

public class AnthropicPrioritizationClient implements PrioritizationClient {
    private final AnthropicClient client;
    private final String modelId;
    private final ObjectMapper mapper = new ObjectMapper();

    public AnthropicPrioritizationClient(String modelId) {
        this.modelId = modelId;
        this.client = AnthropicOkHttpClient.fromEnv();
    }

    @Override
    public List<ManifestEntry> prioritize(List<ManifestEntry> entries) {
        if (entries.isEmpty()) return entries;

        try {
            String prompt = buildPrompt(entries);
            var response = client.messages().create(
                    MessageCreateParams.builder()
                            .model(modelId)
                            .maxTokens(4096L)
                            .addUserMessage(prompt)
                            .build());

            String text = response.content().stream()
                    .flatMap(b -> b.text().stream())
                    .map(t -> t.text())
                    .collect(Collectors.joining());

            List<String> orderedIds = extractTargetIds(text);
            return reorderByIds(entries, orderedIds);

        } catch (Exception e) {
            System.err.println("LLM prioritization failed, using original order: " + e.getMessage());
            return entries;
        }
    }

    private String buildPrompt(List<ManifestEntry> entries) {
        StringBuilder sb = new StringBuilder();
        sb.append("You are a documentation prioritization assistant for Java projects.\n");
        sb.append("Identify which code elements would benefit MOST from Javadoc documentation.\n\n");
        sb.append("OMIT from the result:\n");
        sb.append("- Trivial getters, setters, equals, hashCode, toString\n");
        sb.append("- Simple constructors that only assign fields\n");
        sb.append("- DTO/data classes with no real logic\n\n");
        sb.append("INCLUDE and RANK FIRST:\n");
        sb.append("- Complex business logic and service methods\n");
        sb.append("- Controller endpoints and public APIs\n");
        sb.append("- Non-obvious utility methods\n");
        sb.append("- Methods with complex signatures or declared exceptions\n\n");
        sb.append("Return ONLY a JSON array of targetIds in priority order (highest priority first).\n");
        sb.append("Example: [\"id1\", \"id2\", \"id3\"]\n\n");
        sb.append("Entries:\n");

        for (ManifestEntry e : entries) {
            sb.append("- id: ").append(e.getTargetId()).append("\n");
            sb.append("  type: ").append(e.getKind()).append("\n");
            sb.append("  class: ").append(e.getFqcn()).append("\n");
            if (e.getMemberSignature() != null) {
                sb.append("  signature: ").append(e.getMemberSignature()).append("\n");
            }
            if (!e.getAnnotations().isEmpty()) {
                sb.append("  annotations: ").append(String.join(", ", e.getAnnotations())).append("\n");
            }
            sb.append("  complexityScore: ").append(e.getComplexityScore()).append("\n");
        }

        return sb.toString();
    }

    private List<String> extractTargetIds(String text) throws Exception {
        int start = text.indexOf('[');
        int end = text.lastIndexOf(']');
        if (start < 0 || end <= start) {
            throw new RuntimeException("No JSON array found in LLM response");
        }

        JsonNode array = mapper.readTree(text.substring(start, end + 1));
        List<String> ids = new ArrayList<>();
        for (JsonNode node : array) {
            ids.add(node.asText());
        }
        return ids;
    }

    private List<ManifestEntry> reorderByIds(List<ManifestEntry> entries, List<String> orderedIds) {
        Map<String, ManifestEntry> byId = entries.stream()
                .collect(Collectors.toMap(ManifestEntry::getTargetId, e -> e));

        return orderedIds.stream()
                .map(byId::get)
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
    }

    @Override
    public void close() {
        // OkHttp connections are cleaned up on process exit for CLI usage
    }
}

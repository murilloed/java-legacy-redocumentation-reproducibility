package br.unb.cic.docsgenerator;

import java.nio.file.Path;
import java.nio.file.Paths;

public class Main {
    public static void main(String[] args) {
        if (args.length < 3 || !args[0].equals("run")) {
            System.err.println("Usage: java -jar docs-generator.jar run --input <path> --output <path> [options]");
            System.err.println();
            System.err.println("Core options:");
            System.err.println("  --include <path>                Source subdirectory (default: src/main/java)");
            System.err.println("  --maxTargets <n>                Max documentation targets after ranking (default: 200; 0 = no limit)");
            System.err.println("  --dryRun                        Scan only, skip injection");
            System.err.println("  --docs <type1,type2,...>         Only generate specified documents (default: all)");
            System.err.println("                                    Valid types: javadoc, readme, architecture, api, manual-tests");
            System.err.println("  --metrics                        Compute DocAgent-style quality metrics for generated javadocs");
            System.err.println("                                    Outputs analysis/javadoc_metrics.csv (completeness, truthfulness,");
            System.err.println("                                    helpfulness via LLM-as-judge when AI client is active)");
            System.err.println();
            System.err.println("Anthropic API (covers Javadoc + docs + LLM prioritization):");
            System.err.println("  --useAnthropicApi               Use Anthropic Claude API (reads ANTHROPIC_API_KEY)");
            System.err.println("  --anthropicModelId <modelId>    (default: claude-opus-4-8)");
            System.err.println();
            System.err.println("Javadoc generation (Bedrock):");
            System.err.println("  --useBedrock                    Use Bedrock to generate Javadocs");
            System.err.println("  --bedrockRegion <region>");
            System.err.println("  --bedrockModelId <modelId>");
            System.err.println("  --maxBedrockCalls <n>           (default: 200)");
            System.err.println("  --bedrockTimeoutSeconds <n>     (default: 30)");
            System.err.println();
            System.err.println("Markdown docs generation (Bedrock):");
            System.err.println("  --useBedrockDocs                Use Bedrock to generate project docs");
            System.err.println("  --docsBedrockRegion <region>    (defaults to --bedrockRegion)");
            System.err.println("  --docsBedrockModelId <modelId>  (defaults to --bedrockModelId)");
            System.err.println("  --docsBedrockTimeoutSeconds <n> (default: 30)");
            System.err.println();
            System.err.println("Prioritization strategies (composable):");
            System.err.println("  --useStructuralFilter           Skip DTOs and simple data classes");
            System.err.println("  --useMetricsPrioritization      Rank by cyclomatic complexity; filter below threshold");
            System.err.println("  --minComplexityScore <n>        Minimum CC score to document (default: 2)");
            System.err.println("  --useLLMPrioritization          Use AI to rank and prune targets");
            System.err.println();
            System.err.println("Language:");
            System.err.println("  --language <en|pt>              Documentation language (default: en)");
            System.exit(1);
        }

        Path input = null;
        Path output = null;
        String include = "src/main/java";
        int maxTargets = 200;
        boolean dryRun = false;

        boolean useAnthropicApi = false;
        String anthropicModelId = "claude-opus-4-8";

        boolean useBedrock = false;
        String bedrockRegion = null;
        String bedrockModelId = null;
        int maxBedrockCalls = 200;
        int bedrockTimeoutSeconds = 30;

        boolean useBedrockDocs = false;
        String docsBedrockRegion = null;
        String docsBedrockModelId = null;
        int docsBedrockTimeoutSeconds = 30;

        boolean useStructuralFilter = false;
        boolean useMetricsPrioritization = false;
        int minComplexityScore = 2;
        boolean useLLMPrioritization = false;
        String language = "en";
        java.util.Set<String> enabledDocs = new java.util.HashSet<>();
        boolean computeMetrics = false;

        for (int i = 1; i < args.length; i++) {
            switch (args[i]) {
                case "--input"                    -> input = Paths.get(args[++i]);
                case "--output"                   -> output = Paths.get(args[++i]);
                case "--include"                  -> include = args[++i];
                case "--maxTargets"               -> maxTargets = Integer.parseInt(args[++i]);
                case "--dryRun"                   -> dryRun = true;
                case "--useAnthropicApi"          -> useAnthropicApi = true;
                case "--anthropicModelId"         -> anthropicModelId = args[++i];
                case "--useBedrock"               -> useBedrock = true;
                case "--bedrockRegion"            -> bedrockRegion = args[++i];
                case "--bedrockModelId"           -> bedrockModelId = args[++i];
                case "--maxBedrockCalls"          -> maxBedrockCalls = Integer.parseInt(args[++i]);
                case "--bedrockTimeoutSeconds"    -> bedrockTimeoutSeconds = Integer.parseInt(args[++i]);
                case "--useBedrockDocs"           -> useBedrockDocs = true;
                case "--docsBedrockRegion"        -> docsBedrockRegion = args[++i];
                case "--docsBedrockModelId"       -> docsBedrockModelId = args[++i];
                case "--docsBedrockTimeoutSeconds"-> docsBedrockTimeoutSeconds = Integer.parseInt(args[++i]);
                case "--useStructuralFilter"      -> useStructuralFilter = true;
                case "--useMetricsPrioritization" -> useMetricsPrioritization = true;
                case "--minComplexityScore"       -> minComplexityScore = Integer.parseInt(args[++i]);
                case "--useLLMPrioritization"     -> useLLMPrioritization = true;
                case "--language"                 -> language = args[++i];
                case "--metrics"                  -> computeMetrics = true;
                case "--docs"                     -> {
                    for (String t : args[++i].split(",")) {
                        String token = t.trim().toLowerCase(java.util.Locale.ROOT);
                        if (!token.isEmpty()) enabledDocs.add(token);
                    }
                }
            }
        }

        if (input == null || output == null) {
            System.err.println("--input and --output are required");
            System.exit(1);
        }

        if (useAnthropicApi && System.getenv("ANTHROPIC_API_KEY") == null) {
            System.err.println("ANTHROPIC_API_KEY environment variable is required when --useAnthropicApi is enabled");
            System.exit(1);
        }

        if (useBedrock && !useAnthropicApi && (bedrockRegion == null || bedrockModelId == null)) {
            System.err.println("--bedrockRegion and --bedrockModelId are required when --useBedrock is enabled");
            System.exit(1);
        }

        if (useLLMPrioritization && !useAnthropicApi && (bedrockRegion == null || bedrockModelId == null)) {
            System.err.println("--bedrockRegion and --bedrockModelId are required when --useLLMPrioritization is enabled without --useAnthropicApi");
            System.exit(1);
        }

        if (useBedrockDocs && !useAnthropicApi) {
            if (docsBedrockRegion == null) docsBedrockRegion = bedrockRegion;
            if (docsBedrockModelId == null) docsBedrockModelId = bedrockModelId;
            if (docsBedrockRegion == null || docsBedrockModelId == null) {
                System.err.println("--docsBedrockRegion and --docsBedrockModelId are required when --useBedrockDocs is enabled");
                System.exit(1);
            }
        }

        java.util.Set<String> validDocTypes = java.util.Set.of("javadoc", "readme", "architecture", "api", "manual-tests");
        for (String t : enabledDocs) {
            if (!validDocTypes.contains(t)) {
                System.err.println("Unknown --docs type: '" + t + "'. Valid types: " + validDocTypes);
                System.exit(1);
            }
        }

        try {
            Pipeline pipeline = new Pipeline(
                    input, output, include, maxTargets, dryRun,
                    useBedrock, bedrockRegion, bedrockModelId, maxBedrockCalls, bedrockTimeoutSeconds,
                    useBedrockDocs, docsBedrockRegion, docsBedrockModelId, docsBedrockTimeoutSeconds,
                    useAnthropicApi, anthropicModelId,
                    language,
                    useStructuralFilter, useMetricsPrioritization, minComplexityScore, useLLMPrioritization,
                    enabledDocs, computeMetrics);
            pipeline.execute();
            System.out.println("Pipeline completed successfully");
        } catch (Exception e) {
            System.err.println("Pipeline failed: " + e.getMessage());
            e.printStackTrace();
            System.exit(1);
        }
    }
}

package br.unb.cic.docsgenerator.ai;

import br.unb.cic.docsgenerator.manifest.ManifestEntry;

import java.util.List;

public interface PrioritizationClient {
    List<ManifestEntry> prioritize(List<ManifestEntry> entries);
    void close();
}

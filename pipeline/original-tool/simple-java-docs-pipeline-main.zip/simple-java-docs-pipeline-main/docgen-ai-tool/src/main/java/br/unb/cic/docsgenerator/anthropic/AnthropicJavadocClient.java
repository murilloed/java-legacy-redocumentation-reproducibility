package br.unb.cic.docsgenerator.anthropic;

import br.unb.cic.docsgenerator.ai.JavadocClient;
import br.unb.cic.docsgenerator.manifest.ManifestEntry;
import com.anthropic.client.AnthropicClient;
import com.anthropic.client.okhttp.AnthropicOkHttpClient;
import com.anthropic.models.messages.MessageCreateParams;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.Map;
import java.util.stream.Collectors;

public class AnthropicJavadocClient implements JavadocClient {
    private final AnthropicClient client;
    private final String modelId;
    private final String language;

    public AnthropicJavadocClient(String modelId, String language) {
        this.modelId = modelId;
        this.language = language;
        this.client = AnthropicOkHttpClient.fromEnv();
    }

    @Override
    public String generateJavadoc(ManifestEntry entry, String contextSnippet) {
        String text = invoke(buildPrompt(entry, contextSnippet), 1000L);
        if (text.contains("```")) {
            int start = text.indexOf("/**");
            int end = text.lastIndexOf("*/");
            if (start >= 0 && end > start) text = text.substring(start, end + 2);
        }
        return text;
    }

    @Override
    public double[] evaluateHelpfulness(String javadocText, String signature) {
        try {
            String response = invoke(buildHelpfulnessPrompt(javadocText, signature), 256L);
            return parseHelpfulnessJson(response);
        } catch (Exception e) {
            return null;
        }
    }

    private String buildHelpfulnessPrompt(String javadocText, String signature) {
        return "Evaluate this Java Javadoc on 4 dimensions (1-5 integer scale).\n\n" +
               "Signature: " + signature + "\n\n" +
               "Javadoc:\n" + javadocText + "\n\n" +
               "Dimensions:\n" +
               "- clarity: Is the summary informative yet concise?\n" +
               "- depth: Does it explain purpose, constraints, or edge cases beyond the signature?\n" +
               "- param_utility: Do @param/@return descriptions add meaning beyond the parameter name?\n" +
               "- guidance: Does it guide a developer on when and how to use this element?\n\n" +
               "Respond with ONLY valid JSON: {\"clarity\": N, \"depth\": N, \"param_utility\": N, \"guidance\": N}";
    }

    @SuppressWarnings("unchecked")
    private double[] parseHelpfulnessJson(String response) {
        int start = response.indexOf('{');
        int end = response.lastIndexOf('}');
        if (start < 0 || end <= start) return null;
        try {
            Map<String, Object> map = new ObjectMapper().readValue(response.substring(start, end + 1), Map.class);
            return new double[]{
                toDouble(map.get("clarity")),
                toDouble(map.get("depth")),
                toDouble(map.get("param_utility")),
                toDouble(map.get("guidance"))
            };
        } catch (Exception e) {
            return null;
        }
    }

    private double toDouble(Object val) {
        return val instanceof Number ? ((Number) val).doubleValue() : 3.0;
    }

    private String invoke(String prompt, long maxTokens) {
        int maxRetries = 3;
        int retryDelayMs = 1000;
        for (int attempt = 1; attempt <= maxRetries; attempt++) {
            try {
                var response = client.messages().create(
                        MessageCreateParams.builder()
                                .model(modelId)
                                .maxTokens(maxTokens)
                                .addUserMessage(prompt)
                                .build());
                String text = response.content().stream()
                        .flatMap(b -> b.text().stream())
                        .map(t -> t.text())
                        .collect(Collectors.joining());
                if (text.isEmpty()) throw new RuntimeException("Empty response from Anthropic");
                return text.trim();
            } catch (Exception e) {
                if (attempt == maxRetries)
                    throw new RuntimeException("Anthropic call failed after " + maxRetries + " attempts: " + e.getMessage(), e);
                System.err.println("Anthropic call failed (attempt " + attempt + "/" + maxRetries + "): " + e.getMessage());
                try { Thread.sleep(retryDelayMs * attempt); }
                catch (InterruptedException ie) { Thread.currentThread().interrupt(); throw new RuntimeException("Interrupted", ie); }
            }
        }
        throw new RuntimeException("Anthropic call failed after retries");
    }

    private String buildPrompt(ManifestEntry entry, String contextSnippet) {
        StringBuilder prompt = new StringBuilder();
        String langName = "pt".equals(language) ? "Brazilian Portuguese (pt-BR)" : "English";
        prompt.append("Generate a valid Java Javadoc comment for the following code element.\n\n");
        prompt.append("Requirements:\n");
        prompt.append("- Return ONLY a valid Java Javadoc block (/** ... */). No other text.\n");
        prompt.append("- Write all Javadoc text in ").append(langName).append(".\n");
        prompt.append("- Use only information present in the provided context; do not invent behavior.\n");
        prompt.append("- For methods: include @param for each parameter, @return if non-void, @throws for declared exceptions.\n");
        prompt.append("- Keep it concise (max 8 lines).\n\n");

        prompt.append("Element type: ").append(entry.getKind()).append("\n");
        prompt.append("Package/Class: ").append(entry.getFqcn()).append("\n");

        if (entry.getMemberSignature() != null) {
            prompt.append("Signature: ").append(entry.getMemberSignature()).append("\n");
        }

        if (!entry.getAnnotations().isEmpty()) {
            prompt.append("Annotations: ").append(String.join(", ", entry.getAnnotations())).append("\n");
        }

        prompt.append("\nContext:\n```java\n").append(contextSnippet).append("\n```\n");

        return prompt.toString();
    }

    @Override
    public void close() {
        // OkHttp connections are cleaned up on process exit for CLI usage
    }
}

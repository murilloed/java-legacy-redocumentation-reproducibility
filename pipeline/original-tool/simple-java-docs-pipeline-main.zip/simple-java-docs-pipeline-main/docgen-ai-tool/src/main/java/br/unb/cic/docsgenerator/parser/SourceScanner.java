package br.unb.cic.docsgenerator.parser;

import br.unb.cic.docsgenerator.manifest.Manifest;
import br.unb.cic.docsgenerator.manifest.ManifestEntry;
import br.unb.cic.docsgenerator.prioritization.ClassComplexityAnalyzer;
import br.unb.cic.docsgenerator.prioritization.SimpleClassDetector;
import com.github.javaparser.StaticJavaParser;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.body.*;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.stream.Stream;

public class SourceScanner {
    private final Path scanRoot;
    private final Path codeRoot;

    public SourceScanner(Path scanRoot, Path codeRoot) {
        this.scanRoot = scanRoot;
        this.codeRoot = codeRoot;
    }

    public Manifest scan() throws IOException {
        Manifest manifest = new Manifest();

        try (Stream<Path> paths = Files.walk(scanRoot)) {
            paths.filter(p -> p.toString().endsWith(".java"))
                    .forEach(javaFile -> {
                        try {
                            processFile(javaFile, manifest);
                        } catch (Exception e) {
                            System.err.println("Error processing " + javaFile + ": " + e.getMessage());
                        }
                    });
        }

        System.out.println("Scanned " + manifest.getEntries().size() + " targets across all Java files");
        return manifest;
    }

    private void processFile(Path javaFile, Manifest manifest) throws IOException {
        CompilationUnit cu = StaticJavaParser.parse(javaFile);
        String relativePath = codeRoot.relativize(javaFile).toString();

        cu.findAll(ClassOrInterfaceDeclaration.class).forEach(cls -> {
            if (!cls.isPublic()) return;

            String fqcn = JavaparserUtils.getFqcn(cu, cls.getNameAsString());
            boolean isSimple = SimpleClassDetector.isSimple(cls);
            int classComplexity = ClassComplexityAnalyzer.computeClassComplexity(cls);

            manifest.addEntry(createEntry(
                    "CLASS", relativePath, fqcn, null,
                    cls.getBegin().get().line, cls.getEnd().get().line,
                    cls.getJavadocComment().isPresent(),
                    JavaparserUtils.getAnnotations(cls),
                    isSimple, classComplexity
            ));

            cls.getMethods().forEach(method -> {
                if (!method.isPublic()) return;

                String signature = JavaparserUtils.getMethodSignature(method);
                int methodComplexity = ClassComplexityAnalyzer.computeMethodComplexity(method);
                manifest.addEntry(createEntry(
                        "METHOD", relativePath, fqcn, signature,
                        method.getBegin().get().line, method.getEnd().get().line,
                        method.getJavadocComment().isPresent(),
                        JavaparserUtils.getAnnotations(method),
                        isSimple, methodComplexity
                ));
            });

            cls.getConstructors().forEach(ctor -> {
                if (!ctor.isPublic()) return;

                String signature = JavaparserUtils.getConstructorSignature(ctor);
                int ctorComplexity = ClassComplexityAnalyzer.computeConstructorComplexity(ctor);
                manifest.addEntry(createEntry(
                        "CONSTRUCTOR", relativePath, fqcn, signature,
                        ctor.getBegin().get().line, ctor.getEnd().get().line,
                        ctor.getJavadocComment().isPresent(),
                        JavaparserUtils.getAnnotations(ctor),
                        isSimple, ctorComplexity
                ));
            });
        });

        cu.findAll(EnumDeclaration.class).forEach(enm -> {
            if (!enm.isPublic()) return;

            String fqcn = JavaparserUtils.getFqcn(cu, enm.getNameAsString());
            manifest.addEntry(createEntry(
                    "ENUM", relativePath, fqcn, null,
                    enm.getBegin().get().line, enm.getEnd().get().line,
                    enm.getJavadocComment().isPresent(),
                    JavaparserUtils.getAnnotations(enm),
                    false, 1
            ));
        });
    }

    private ManifestEntry createEntry(String kind, String filePath, String fqcn, String signature,
                                      int beginLine, int endLine, boolean hasJavadoc,
                                      List<String> annotations, boolean simpleDataClass, int complexityScore) {
        ManifestEntry entry = new ManifestEntry();
        entry.setKind(kind);
        entry.setFilePath(filePath);
        entry.setFqcn(fqcn);
        entry.setMemberSignature(signature);
        entry.setRange(new ManifestEntry.Range(beginLine, endLine));
        entry.setHasJavadoc(hasJavadoc);
        entry.setAnnotations(annotations);
        entry.setSimpleDataClass(simpleDataClass);
        entry.setComplexityScore(complexityScore);
        entry.setTargetId(JavaparserUtils.generateTargetId(filePath, fqcn, signature, beginLine));
        return entry;
    }
}

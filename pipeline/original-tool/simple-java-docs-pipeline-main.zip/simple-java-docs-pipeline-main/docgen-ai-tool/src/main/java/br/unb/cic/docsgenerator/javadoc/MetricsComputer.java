package br.unb.cic.docsgenerator.javadoc;

import br.unb.cic.docsgenerator.manifest.Manifest;
import br.unb.cic.docsgenerator.manifest.ManifestEntry;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class MetricsComputer {

    private static final Pattern CAMEL_CASE_WORD = Pattern.compile("\\b([A-Z][a-zA-Z0-9]{1,})\\b");

    public record CompletenessResult(double score, int required, int present, List<String> missing) {}
    public record TruthfulnessResult(double score, int mentioned, int verified) {}

    public static CompletenessResult computeCompleteness(ManifestEntry entry, String javadocText) {
        List<String> required = buildRequiredSections(entry);
        List<String> missing = required.stream()
                .filter(s -> !isSectionPresent(javadocText, s))
                .collect(Collectors.toList());
        int present = required.size() - missing.size();
        double score = required.isEmpty() ? 1.0 : (double) present / required.size();
        return new CompletenessResult(round2(score), required.size(), present, missing);
    }

    public static TruthfulnessResult computeTruthfulness(String javadocText, Set<String> knownNames) {
        if (javadocText == null || javadocText.isBlank()) return new TruthfulnessResult(1.0, 0, 0);
        Set<String> mentioned = new LinkedHashSet<>();
        Matcher m = CAMEL_CASE_WORD.matcher(javadocText);
        while (m.find()) mentioned.add(m.group(1));
        if (mentioned.isEmpty()) return new TruthfulnessResult(1.0, 0, 0);
        long verified = mentioned.stream().filter(knownNames::contains).count();
        return new TruthfulnessResult(round2((double) verified / mentioned.size()), mentioned.size(), (int) verified);
    }

    public static Set<String> buildKnownNames(Manifest manifest) {
        return manifest.getEntries().stream()
                .map(ManifestEntry::getFqcn)
                .map(fqcn -> {
                    int dot = fqcn.lastIndexOf('.');
                    return dot >= 0 ? fqcn.substring(dot + 1) : fqcn;
                })
                .collect(Collectors.toSet());
    }

    private static List<String> buildRequiredSections(ManifestEntry entry) {
        List<String> sections = new ArrayList<>();
        sections.add("summary");
        String kind = entry.getKind();
        if ("METHOD".equals(kind) || "CONSTRUCTOR".equals(kind)) {
            String sig = entry.getMemberSignature();
            if (sig != null && countParameters(sig) > 0) {
                sections.add("@param");
            }
            if ("METHOD".equals(kind) && sig != null && !sig.trim().startsWith("void ")) {
                sections.add("@return");
            }
        }
        return sections;
    }

    private static boolean isSectionPresent(String javadocText, String section) {
        if (javadocText == null || javadocText.isBlank()) return false;
        return switch (section) {
            case "summary" -> javadocText.lines()
                    .anyMatch(l -> !l.strip().isEmpty() && !l.strip().startsWith("@"));
            case "@param"  -> javadocText.contains("@param");
            case "@return" -> javadocText.contains("@return");
            default        -> false;
        };
    }

    private static int countParameters(String signature) {
        int open = signature.indexOf('(');
        int close = signature.lastIndexOf(')');
        if (open < 0 || close <= open) return 0;
        String params = signature.substring(open + 1, close).trim();
        if (params.isEmpty()) return 0;
        int count = 1, depth = 0;
        for (char c : params.toCharArray()) {
            if (c == '<') depth++;
            else if (c == '>') depth--;
            else if (c == ',' && depth == 0) count++;
        }
        return count;
    }

    private static double round2(double v) {
        return Math.round(v * 100.0) / 100.0;
    }
}

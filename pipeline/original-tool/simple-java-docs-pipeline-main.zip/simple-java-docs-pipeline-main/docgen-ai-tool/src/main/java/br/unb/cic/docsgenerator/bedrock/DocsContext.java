package br.unb.cic.docsgenerator.bedrock;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class DocsContext {
    private String projectName;
    private List<String> topLevelPackages = new ArrayList<>();
    private List<PublicType> publicTypes = new ArrayList<>();
    private List<HttpEndpoint> httpEndpoints = new ArrayList<>();
    private List<ControllerContext> controllerContexts = new ArrayList<>();
    private List<String> services = new ArrayList<>();
    private List<String> repositories = new ArrayList<>();
    private int fileCount;
    private int publicTypeCount;
    private int publicMethodCount;
    private boolean hasPomXml;
    private String mainClass;

    public static class PublicType {
        private String fqcn;
        private String kind;
        private String filePath;

        public PublicType(String fqcn, String kind, String filePath) {
            this.fqcn = fqcn;
            this.kind = kind;
            this.filePath = filePath;
        }

        public String getFqcn() { return fqcn; }
        public String getKind() { return kind; }
        public String getFilePath() { return filePath; }
    }

    public static class ControllerContext {
        private final String controllerName;
        private final String filePath;
        private final String sourceCode;
        private final List<HttpEndpoint> endpoints;

        public ControllerContext(String controllerName, String filePath, String sourceCode, List<HttpEndpoint> endpoints) {
            this.controllerName = controllerName;
            this.filePath = filePath;
            this.sourceCode = sourceCode;
            this.endpoints = endpoints;
        }

        public String getControllerName() { return controllerName; }
        public String getFilePath() { return filePath; }
        public String getSourceCode() { return sourceCode; }
        public List<HttpEndpoint> getEndpoints() { return endpoints; }
    }

    public static class HttpEndpoint {
        private String method;
        private String path;
        private String controller;
        private String methodName;
        private String signature;

        public HttpEndpoint(String method, String path, String controller, String methodName, String signature) {
            this.method = method;
            this.path = path;
            this.controller = controller;
            this.methodName = methodName;
            this.signature = signature;
        }

        public String getMethod() { return method; }
        public String getPath() { return path; }
        public String getController() { return controller; }
        public String getMethodName() { return methodName; }
        public String getSignature() { return signature; }
    }

    public String getProjectName() { return projectName; }
    public void setProjectName(String projectName) { this.projectName = projectName; }

    public List<String> getTopLevelPackages() { return topLevelPackages; }
    public void setTopLevelPackages(List<String> topLevelPackages) { this.topLevelPackages = topLevelPackages; }

    public List<PublicType> getPublicTypes() { return publicTypes; }
    public void setPublicTypes(List<PublicType> publicTypes) { this.publicTypes = publicTypes; }

    public List<HttpEndpoint> getHttpEndpoints() { return httpEndpoints; }
    public void setHttpEndpoints(List<HttpEndpoint> httpEndpoints) { this.httpEndpoints = httpEndpoints; }

    public List<ControllerContext> getControllerContexts() { return controllerContexts; }
    public void setControllerContexts(List<ControllerContext> controllerContexts) { this.controllerContexts = controllerContexts; }

    public List<String> getServices() { return services; }
    public void setServices(List<String> services) { this.services = services; }

    public List<String> getRepositories() { return repositories; }
    public void setRepositories(List<String> repositories) { this.repositories = repositories; }

    public int getFileCount() { return fileCount; }
    public void setFileCount(int fileCount) { this.fileCount = fileCount; }

    public int getPublicTypeCount() { return publicTypeCount; }
    public void setPublicTypeCount(int publicTypeCount) { this.publicTypeCount = publicTypeCount; }

    public int getPublicMethodCount() { return publicMethodCount; }
    public void setPublicMethodCount(int publicMethodCount) { this.publicMethodCount = publicMethodCount; }

    public boolean isHasPomXml() { return hasPomXml; }
    public void setHasPomXml(boolean hasPomXml) { this.hasPomXml = hasPomXml; }

    public String getMainClass() { return mainClass; }
    public void setMainClass(String mainClass) { this.mainClass = mainClass; }
}

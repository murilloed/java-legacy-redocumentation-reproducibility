package br.unb.cic.docsgenerator;

import br.unb.cic.docsgenerator.ai.DocsClient;
import br.unb.cic.docsgenerator.ai.JavadocClient;
import br.unb.cic.docsgenerator.ai.PrioritizationClient;
import br.unb.cic.docsgenerator.anthropic.AnthropicDocsClient;
import br.unb.cic.docsgenerator.anthropic.AnthropicJavadocClient;
import br.unb.cic.docsgenerator.anthropic.AnthropicPrioritizationClient;
import br.unb.cic.docsgenerator.bedrock.BedrockDocsClient;
import br.unb.cic.docsgenerator.bedrock.BedrockJavadocClient;
import br.unb.cic.docsgenerator.bedrock.BedrockPrioritizationClient;
import br.unb.cic.docsgenerator.docs.DocsGenerator;
import br.unb.cic.docsgenerator.javadoc.JavadocInjector;
import br.unb.cic.docsgenerator.javadoc.SelectionResult;
import br.unb.cic.docsgenerator.javadoc.TargetSelector;
import br.unb.cic.docsgenerator.manifest.Manifest;
import br.unb.cic.docsgenerator.manifest.ManifestWriter;
import br.unb.cic.docsgenerator.parser.SourceScanner;

import java.io.IOException;
import java.nio.file.*;
import java.util.Set;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class Pipeline {
    private final Path input;
    private final Path output;
    private final String include;
    private final int maxTargets;
    private final boolean dryRun;

    // Bedrock — Javadoc generation
    private final boolean useBedrock;
    private final String bedrockRegion;
    private final String bedrockModelId;
    private final int maxBedrockCalls;
    private final int bedrockTimeoutSeconds;

    // Bedrock — Markdown docs generation
    private final boolean useBedrockDocs;
    private final String docsBedrockRegion;
    private final String docsBedrockModelId;
    private final int docsBedrockTimeoutSeconds;

    // Anthropic (covers javadoc + docs + LLM prioritization)
    private final boolean useAnthropicApi;
    private final String anthropicModelId;

    // Documentation language
    private final String language;

    // Prioritization strategies
    private final boolean useStructuralFilter;
    private final boolean useMetricsPrioritization;
    private final int minComplexityScore;
    private final boolean useLLMPrioritization;

    // Document selection (empty = all)
    private final Set<String> enabledDocs;

    // Quality metrics
    private final boolean computeMetrics;

    public Pipeline(Path input, Path output, String include, int maxTargets, boolean dryRun,
                    boolean useBedrock, String bedrockRegion, String bedrockModelId,
                    int maxBedrockCalls, int bedrockTimeoutSeconds,
                    boolean useBedrockDocs, String docsBedrockRegion, String docsBedrockModelId,
                    int docsBedrockTimeoutSeconds,
                    boolean useAnthropicApi, String anthropicModelId,
                    String language,
                    boolean useStructuralFilter, boolean useMetricsPrioritization,
                    int minComplexityScore, boolean useLLMPrioritization,
                    Set<String> enabledDocs, boolean computeMetrics) {
        this.input = input;
        this.output = output;
        this.include = include;
        this.maxTargets = maxTargets;
        this.dryRun = dryRun;
        this.useBedrock = useBedrock;
        this.bedrockRegion = bedrockRegion;
        this.bedrockModelId = bedrockModelId;
        this.maxBedrockCalls = maxBedrockCalls;
        this.bedrockTimeoutSeconds = bedrockTimeoutSeconds;
        this.useBedrockDocs = useBedrockDocs;
        this.docsBedrockRegion = docsBedrockRegion;
        this.docsBedrockModelId = docsBedrockModelId;
        this.docsBedrockTimeoutSeconds = docsBedrockTimeoutSeconds;
        this.useAnthropicApi = useAnthropicApi;
        this.anthropicModelId = anthropicModelId;
        this.language = language;
        this.useStructuralFilter = useStructuralFilter;
        this.useMetricsPrioritization = useMetricsPrioritization;
        this.minComplexityScore = minComplexityScore;
        this.useLLMPrioritization = useLLMPrioritization;
        this.enabledDocs = enabledDocs;
        this.computeMetrics = computeMetrics;
    }

    public void execute() throws Exception {
        String backendLabel = useAnthropicApi ? "anthropic" : "bedrock";
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
        Path runOutput = output.resolve(backendLabel + "-" + timestamp);

        System.out.println("Starting pipeline...");
        System.out.println("Input: " + input);
        System.out.println("Output: " + runOutput);
        System.out.println("Include: " + include);
        System.out.println("Max targets: " + maxTargets);
        System.out.println("Dry run: " + dryRun);
        System.out.println("AI backend (Javadoc): " + (useAnthropicApi ? "Anthropic (" + anthropicModelId + ")"
                : (useBedrock ? "Bedrock (" + bedrockModelId + ")" : "template")));
        System.out.println("AI backend (Docs): " + (useAnthropicApi ? "Anthropic (" + anthropicModelId + ")"
                : (useBedrockDocs ? "Bedrock (" + docsBedrockModelId + ")" : "placeholder")));
        System.out.println("Structural filter: " + useStructuralFilter);
        System.out.println("Metrics prioritization: " + useMetricsPrioritization
                + (useMetricsPrioritization ? " (minScore=" + minComplexityScore + ")" : ""));
        System.out.println("LLM prioritization: " + useLLMPrioritization
                + (useLLMPrioritization ? " via " + (useAnthropicApi ? "Anthropic" : "Bedrock") : ""));
        System.out.println("Enabled documents: " + (enabledDocs.isEmpty() ? "all" : enabledDocs));

        Path codeDir = runOutput.resolve("code");
        Path analysisDir = runOutput.resolve("analysis");
        Path docsDir = runOutput.resolve("docs");

        Files.createDirectories(analysisDir);
        Files.createDirectories(docsDir);

        Path scanRoot = input.resolve(include);
        if (!Files.exists(scanRoot)) {
            scanRoot = input;
        }

        System.out.println("Scanning source files from: " + scanRoot);
        SourceScanner scanner = new SourceScanner(scanRoot, input);
        Manifest manifest = scanner.scan();

        System.out.println("Writing manifest...");
        ManifestWriter.write(manifest, analysisDir.resolve("manifest.json"));

        System.out.println("Copying input to output/code...");
        copyDirectory(input, codeDir);

        boolean runJavadoc = enabledDocs.isEmpty() || enabledDocs.contains("javadoc");

        if (!dryRun && runJavadoc) {
            PrioritizationClient prioritizationClient = null;
            JavadocClient javadocClient = null;

            try {
                if (useLLMPrioritization) {
                    System.out.println("Initializing LLM prioritization client...");
                    if (useAnthropicApi) {
                        prioritizationClient = new AnthropicPrioritizationClient(anthropicModelId);
                    } else {
                        prioritizationClient = new BedrockPrioritizationClient(
                                bedrockRegion, bedrockModelId, bedrockTimeoutSeconds);
                    }
                }

                SelectionResult selectionResult = TargetSelector.select(
                        manifest.getEntries(),
                        useStructuralFilter,
                        useMetricsPrioritization,
                        minComplexityScore,
                        useLLMPrioritization,
                        prioritizationClient,
                        maxTargets);

                System.out.println("Selected " + selectionResult.entries().size()
                        + " of " + selectionResult.totalScanned() + " scanned targets for documentation");

                System.out.println("Injecting Javadocs...");
                if (useAnthropicApi) {
                    System.out.println("Initializing Anthropic Javadoc client...");
                    javadocClient = new AnthropicJavadocClient(anthropicModelId, language);
                } else if (useBedrock) {
                    System.out.println("Initializing Bedrock Javadoc client...");
                    javadocClient = new BedrockJavadocClient(bedrockRegion, bedrockModelId, bedrockTimeoutSeconds, language);
                }

                JavadocInjector injector = new JavadocInjector(codeDir, javadocClient, maxBedrockCalls, manifest, computeMetrics);
                injector.inject(selectionResult, analysisDir.resolve("javadoc_report.json"));

            } finally {
                if (prioritizationClient != null) prioritizationClient.close();
                if (javadocClient != null) javadocClient.close();
            }
        } else if (dryRun) {
            System.out.println("Skipping Javadoc injection (dry run)");
        } else {
            System.out.println("Skipping Javadoc injection (not in --docs selection)");
        }

        System.out.println("Generating documentation...");
        DocsClient docsClient = null;
        if (useAnthropicApi) {
            docsClient = new AnthropicDocsClient(anthropicModelId, language);
        } else if (useBedrockDocs) {
            docsClient = new BedrockDocsClient(docsBedrockRegion, docsBedrockModelId, docsBedrockTimeoutSeconds, language);
        }

        DocsGenerator docsGen = new DocsGenerator(manifest, codeDir, input, docsClient, language, enabledDocs);
        docsGen.generate(docsDir, analysisDir);

        if (docsClient != null) docsClient.close();

        System.out.println("Pipeline complete");
    }

    private void copyDirectory(Path source, Path target) throws IOException {
        Files.walkFileTree(source, new SimpleFileVisitor<>() {
            @Override
            public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) throws IOException {
                Path targetDir = target.resolve(source.relativize(dir));
                if (!Files.exists(targetDir)) {
                    Files.createDirectories(targetDir);
                }
                return FileVisitResult.CONTINUE;
            }

            @Override
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                String fileName = file.getFileName().toString();
                if (fileName.equals(".git") || fileName.equals("target") || fileName.equals(".DS_Store")) {
                    return FileVisitResult.SKIP_SUBTREE;
                }
                Files.copy(file, target.resolve(source.relativize(file)), StandardCopyOption.REPLACE_EXISTING);
                return FileVisitResult.CONTINUE;
            }
        });
    }
}

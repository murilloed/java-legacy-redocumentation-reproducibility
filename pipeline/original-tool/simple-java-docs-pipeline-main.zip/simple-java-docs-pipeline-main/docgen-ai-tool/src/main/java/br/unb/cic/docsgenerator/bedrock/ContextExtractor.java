package br.unb.cic.docsgenerator.bedrock;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

public class ContextExtractor {
    public static String extractContext(Path filePath, int beginLine, int endLine) throws IOException {
        List<String> lines = Files.readAllLines(filePath);
        
        int contextStart = Math.max(0, beginLine - 20);
        int contextEnd = Math.min(lines.size(), endLine + 20);
        
        int totalLines = contextEnd - contextStart;
        if (totalLines > 80) {
            contextStart = Math.max(0, beginLine - 10);
            contextEnd = Math.min(lines.size(), endLine + 10);
        }
        
        StringBuilder context = new StringBuilder();
        for (int i = contextStart; i < contextEnd; i++) {
            context.append(lines.get(i)).append("\n");
        }
        
        return context.toString();
    }
}

package br.unb.cic.docsgenerator.prioritization;

import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.ConstructorDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.expr.BinaryExpr;
import com.github.javaparser.ast.expr.ConditionalExpr;
import com.github.javaparser.ast.stmt.*;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;

public class ClassComplexityAnalyzer {

    public static int computeMethodComplexity(MethodDeclaration method) {
        int[] count = {1};
        method.accept(new DecisionNodeVisitor(), count);
        return count[0];
    }

    public static int computeConstructorComplexity(ConstructorDeclaration ctor) {
        int[] count = {1};
        ctor.accept(new DecisionNodeVisitor(), count);
        return count[0];
    }

    // Sum of all method complexities in the class
    public static int computeClassComplexity(ClassOrInterfaceDeclaration cls) {
        return cls.getMethods().stream()
                .mapToInt(ClassComplexityAnalyzer::computeMethodComplexity)
                .sum();
    }

    private static class DecisionNodeVisitor extends VoidVisitorAdapter<int[]> {

        @Override
        public void visit(IfStmt n, int[] count) {
            count[0]++;
            super.visit(n, count);
        }

        @Override
        public void visit(ForStmt n, int[] count) {
            count[0]++;
            super.visit(n, count);
        }

        @Override
        public void visit(ForEachStmt n, int[] count) {
            count[0]++;
            super.visit(n, count);
        }

        @Override
        public void visit(WhileStmt n, int[] count) {
            count[0]++;
            super.visit(n, count);
        }

        @Override
        public void visit(DoStmt n, int[] count) {
            count[0]++;
            super.visit(n, count);
        }

        @Override
        public void visit(SwitchEntry n, int[] count) {
            // each non-default case label is a decision point
            if (!n.getLabels().isEmpty()) {
                count[0]++;
            }
            super.visit(n, count);
        }

        @Override
        public void visit(CatchClause n, int[] count) {
            count[0]++;
            super.visit(n, count);
        }

        @Override
        public void visit(ConditionalExpr n, int[] count) {
            count[0]++;
            super.visit(n, count);
        }

        @Override
        public void visit(BinaryExpr n, int[] count) {
            BinaryExpr.Operator op = n.getOperator();
            if (op == BinaryExpr.Operator.AND || op == BinaryExpr.Operator.OR) {
                count[0]++;
            }
            super.visit(n, count);
        }
    }
}

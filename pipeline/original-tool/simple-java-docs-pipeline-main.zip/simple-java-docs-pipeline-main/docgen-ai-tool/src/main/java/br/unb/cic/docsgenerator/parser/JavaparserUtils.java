package br.unb.cic.docsgenerator.parser;

import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.body.*;
import com.github.javaparser.ast.expr.AnnotationExpr;
import com.github.javaparser.ast.nodeTypes.NodeWithAnnotations;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.List;
import java.util.stream.Collectors;

public class JavaparserUtils {
    public static String getFqcn(CompilationUnit cu, String className) {
        return cu.getPackageDeclaration()
                .map(pd -> pd.getNameAsString() + "." + className)
                .orElse(className);
    }

    public static String getMethodSignature(MethodDeclaration method) {
        String returnType = method.getTypeAsString();
        String name = method.getNameAsString();
        String params = method.getParameters().stream()
                .map(p -> p.getTypeAsString())
                .collect(Collectors.joining(", "));
        String exceptions = method.getThrownExceptions().isEmpty() ? "" :
                " throws " + method.getThrownExceptions().stream()
                        .map(Object::toString)
                        .collect(Collectors.joining(", "));
        return returnType + " " + name + "(" + params + ")" + exceptions;
    }

    public static String getConstructorSignature(ConstructorDeclaration ctor) {
        String name = ctor.getNameAsString();
        String params = ctor.getParameters().stream()
                .map(p -> p.getTypeAsString())
                .collect(Collectors.joining(", "));
        String exceptions = ctor.getThrownExceptions().isEmpty() ? "" :
                " throws " + ctor.getThrownExceptions().stream()
                        .map(Object::toString)
                        .collect(Collectors.joining(", "));
        return name + "(" + params + ")" + exceptions;
    }

    public static List<String> getAnnotations(NodeWithAnnotations<?> node) {
        return node.getAnnotations().stream()
                .map(AnnotationExpr::getNameAsString)
                .collect(Collectors.toList());
    }

    public static String generateTargetId(String filePath, String fqcn, String signature, int beginLine) {
        String input = filePath + "|" + fqcn + "|" + (signature != null ? signature : "") + "|" + beginLine;
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(input.getBytes(StandardCharsets.UTF_8));
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (Exception e) {
            return String.valueOf(input.hashCode());
        }
    }
}

package br.unb.cic.docsgenerator.docs;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class MarkdownWriter {
    public static void write(Path output, String content) throws IOException {
        Files.writeString(output, content);
    }
}

package br.unb.cic.docsgenerator.bedrock;

import br.unb.cic.docsgenerator.ai.JavadocClient;
import br.unb.cic.docsgenerator.manifest.ManifestEntry;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import software.amazon.awssdk.auth.credentials.DefaultCredentialsProvider;
import software.amazon.awssdk.core.SdkBytes;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.bedrockruntime.BedrockRuntimeClient;
import software.amazon.awssdk.services.bedrockruntime.model.InvokeModelRequest;
import software.amazon.awssdk.services.bedrockruntime.model.InvokeModelResponse;

import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BedrockJavadocClient implements JavadocClient {
    private final BedrockRuntimeClient client;
    private final String modelId;
    private final int timeoutSeconds;
    private final String language;
    private final ObjectMapper mapper = new ObjectMapper();

    public BedrockJavadocClient(String region, String modelId, int timeoutSeconds, String language) {
        this.modelId = modelId;
        this.timeoutSeconds = timeoutSeconds;
        this.language = language;
        
        try {
            this.client = BedrockRuntimeClient.builder()
                    .region(Region.of(region))
                    .credentialsProvider(DefaultCredentialsProvider.create())
                    .overrideConfiguration(c -> c.apiCallTimeout(Duration.ofSeconds(timeoutSeconds)))
                    .build();
        } catch (Exception e) {
            throw new RuntimeException("Failed to initialize Bedrock client. Check AWS credentials and permissions: " + e.getMessage(), e);
        }
    }

    public String generateJavadoc(ManifestEntry entry, String contextSnippet) {
        String responseBody = invokeModel(buildPrompt(entry, contextSnippet), 1000);
        try {
            return extractJavadocFromResponse(responseBody);
        } catch (Exception e) {
            throw new RuntimeException("Failed to extract javadoc from Bedrock response: " + e.getMessage(), e);
        }
    }

    @Override
    public double[] evaluateHelpfulness(String javadocText, String signature) {
        try {
            String responseBody = invokeModel(buildHelpfulnessPrompt(javadocText, signature), 256);
            String text = extractTextFromResponse(responseBody);
            return parseHelpfulnessJson(text);
        } catch (Exception e) {
            return null;
        }
    }

    private String buildHelpfulnessPrompt(String javadocText, String signature) {
        return "Evaluate this Java Javadoc on 4 dimensions (1-5 integer scale).\n\n" +
               "Signature: " + signature + "\n\n" +
               "Javadoc:\n" + javadocText + "\n\n" +
               "Dimensions:\n" +
               "- clarity: Is the summary informative yet concise?\n" +
               "- depth: Does it explain purpose, constraints, or edge cases beyond the signature?\n" +
               "- param_utility: Do @param/@return descriptions add meaning beyond the parameter name?\n" +
               "- guidance: Does it guide a developer on when and how to use this element?\n\n" +
               "Respond with ONLY valid JSON: {\"clarity\": N, \"depth\": N, \"param_utility\": N, \"guidance\": N}";
    }

    @SuppressWarnings("unchecked")
    private double[] parseHelpfulnessJson(String response) {
        int start = response.indexOf('{');
        int end = response.lastIndexOf('}');
        if (start < 0 || end <= start) return null;
        try {
            Map<String, Object> map = mapper.readValue(response.substring(start, end + 1), Map.class);
            return new double[]{
                toDouble(map.get("clarity")),
                toDouble(map.get("depth")),
                toDouble(map.get("param_utility")),
                toDouble(map.get("guidance"))
            };
        } catch (Exception e) {
            return null;
        }
    }

    private double toDouble(Object val) {
        return val instanceof Number ? ((Number) val).doubleValue() : 3.0;
    }

    private String invokeModel(String prompt, int maxTokens) {
        int maxRetries = 3;
        int retryDelayMs = 1000;
        for (int attempt = 1; attempt <= maxRetries; attempt++) {
            try {
                String requestBody = buildRequestBody(prompt, maxTokens);
                InvokeModelRequest request = InvokeModelRequest.builder()
                        .modelId(modelId)
                        .body(SdkBytes.fromUtf8String(requestBody))
                        .build();
                InvokeModelResponse response = client.invokeModel(request);
                return response.body().asUtf8String();
            } catch (Exception e) {
                if (attempt == maxRetries)
                    throw new RuntimeException("Bedrock call failed after " + maxRetries + " attempts: " + e.getMessage(), e);
                System.err.println("Bedrock call failed (attempt " + attempt + "/" + maxRetries + "): " + e.getMessage());
                try { Thread.sleep(retryDelayMs * attempt); }
                catch (InterruptedException ie) { Thread.currentThread().interrupt(); throw new RuntimeException("Interrupted", ie); }
            }
        }
        throw new RuntimeException("Bedrock call failed after retries");
    }

    private String buildPrompt(ManifestEntry entry, String contextSnippet) {
        StringBuilder prompt = new StringBuilder();
        String langName = "pt".equals(language) ? "Brazilian Portuguese (pt-BR)" : "English";
        prompt.append("Generate a valid Java Javadoc comment for the following code element.\n\n");
        prompt.append("Requirements:\n");
        prompt.append("- Return ONLY a valid Java Javadoc block (/** ... */). No other text.\n");
        prompt.append("- Write all Javadoc text in ").append(langName).append(".\n");
        prompt.append("- Use only information present in the provided context; do not invent behavior.\n");
        prompt.append("- For methods: include @param for each parameter, @return if non-void, @throws for declared exceptions.\n");
        prompt.append("- Keep it concise (max 8 lines).\n\n");
        
        prompt.append("Element type: ").append(entry.getKind()).append("\n");
        prompt.append("Package/Class: ").append(entry.getFqcn()).append("\n");
        
        if (entry.getMemberSignature() != null) {
            prompt.append("Signature: ").append(entry.getMemberSignature()).append("\n");
        }
        
        if (!entry.getAnnotations().isEmpty()) {
            prompt.append("Annotations: ").append(String.join(", ", entry.getAnnotations())).append("\n");
        }
        
        prompt.append("\nContext:\n```java\n").append(contextSnippet).append("\n```\n");
        
        return prompt.toString();
    }

    private String buildRequestBody(String prompt, int maxTokens) throws Exception {
        Map<String, Object> body = new HashMap<>();
        if (modelId.contains("anthropic")) {
            body.put("anthropic_version", "bedrock-2023-05-31");
            body.put("max_tokens", maxTokens);
            body.put("temperature", 0.2);
            body.put("messages", List.of(Map.of("role", "user", "content", prompt)));
        } else if (modelId.contains("amazon")) {
            Map<String, Object> textGenConfig = new HashMap<>();
            textGenConfig.put("maxTokenCount", maxTokens);
            textGenConfig.put("temperature", 0.2);
            body.put("inputText", prompt);
            body.put("textGenerationConfig", textGenConfig);
        } else {
            body.put("prompt", prompt);
            body.put("max_tokens", maxTokens);
            body.put("temperature", 0.2);
        }
        return mapper.writeValueAsString(body);
    }

    private String extractTextFromResponse(String responseBody) throws Exception {
        JsonNode root = mapper.readTree(responseBody);
        if (root.has("content")) return root.get("content").get(0).get("text").asText();
        if (root.has("results"))  return root.get("results").get(0).get("outputText").asText();
        if (root.has("completion")) return root.get("completion").asText();
        if (root.has("output"))   return root.get("output").asText();
        throw new RuntimeException("Could not extract text from Bedrock response");
    }

    private String extractJavadocFromResponse(String responseBody) throws Exception {
        String text = extractTextFromResponse(responseBody).trim();
        if (text.contains("```")) {
            int start = text.indexOf("/**");
            int end = text.lastIndexOf("*/");
            if (start >= 0 && end > start) text = text.substring(start, end + 2);
        }
        return text;
    }

    public void close() {
        if (client != null) {
            client.close();
        }
    }
}

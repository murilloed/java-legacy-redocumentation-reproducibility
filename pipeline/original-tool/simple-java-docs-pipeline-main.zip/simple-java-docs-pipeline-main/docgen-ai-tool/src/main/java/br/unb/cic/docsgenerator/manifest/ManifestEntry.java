package br.unb.cic.docsgenerator.manifest;

import java.util.ArrayList;
import java.util.List;

public class ManifestEntry {
    private String targetId;
    private String kind;
    private String filePath;
    private String fqcn;
    private String memberSignature;
    private Range range;
    private boolean hasJavadoc;
    private boolean simpleDataClass;
    private int complexityScore;
    private List<String> annotations = new ArrayList<>();

    public static class Range {
        private int beginLine;
        private int endLine;

        public Range(int beginLine, int endLine) {
            this.beginLine = beginLine;
            this.endLine = endLine;
        }

        public int getBeginLine() {
            return beginLine;
        }

        public void setBeginLine(int beginLine) {
            this.beginLine = beginLine;
        }

        public int getEndLine() {
            return endLine;
        }

        public void setEndLine(int endLine) {
            this.endLine = endLine;
        }
    }

    public String getTargetId() {
        return targetId;
    }

    public void setTargetId(String targetId) {
        this.targetId = targetId;
    }

    public String getKind() {
        return kind;
    }

    public void setKind(String kind) {
        this.kind = kind;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public String getFqcn() {
        return fqcn;
    }

    public void setFqcn(String fqcn) {
        this.fqcn = fqcn;
    }

    public String getMemberSignature() {
        return memberSignature;
    }

    public void setMemberSignature(String memberSignature) {
        this.memberSignature = memberSignature;
    }

    public Range getRange() {
        return range;
    }

    public void setRange(Range range) {
        this.range = range;
    }

    public boolean isHasJavadoc() {
        return hasJavadoc;
    }

    public void setHasJavadoc(boolean hasJavadoc) {
        this.hasJavadoc = hasJavadoc;
    }

    public boolean isSimpleDataClass() {
        return simpleDataClass;
    }

    public void setSimpleDataClass(boolean simpleDataClass) {
        this.simpleDataClass = simpleDataClass;
    }

    public int getComplexityScore() {
        return complexityScore;
    }

    public void setComplexityScore(int complexityScore) {
        this.complexityScore = complexityScore;
    }

    public List<String> getAnnotations() {
        return annotations;
    }

    public void setAnnotations(List<String> annotations) {
        this.annotations = annotations;
    }
}

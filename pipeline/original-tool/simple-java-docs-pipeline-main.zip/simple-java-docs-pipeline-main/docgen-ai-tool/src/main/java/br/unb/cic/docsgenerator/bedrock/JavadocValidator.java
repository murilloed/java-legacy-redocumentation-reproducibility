package br.unb.cic.docsgenerator.bedrock;

import br.unb.cic.docsgenerator.manifest.ManifestEntry;

import java.util.HashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class JavadocValidator {
    private static final Pattern PARAM_PATTERN = Pattern.compile("@param\\s+(\\w+)");
    private static final Pattern RETURN_PATTERN = Pattern.compile("@return");
    private static final Pattern THROWS_PATTERN = Pattern.compile("@throws\\s+(\\S+)");

    public static ValidationResult validate(String javadoc, ManifestEntry entry) {
        if (javadoc == null || javadoc.isEmpty()) {
            return ValidationResult.fail("Javadoc is empty");
        }

        javadoc = javadoc.trim();

        if (!javadoc.startsWith("/**") || !javadoc.endsWith("*/")) {
            return ValidationResult.fail("Javadoc must start with /** and end with */");
        }

        if (javadoc.contains("```")) {
            return ValidationResult.fail("Javadoc contains Markdown fences");
        }

        long lineCount = javadoc.lines().count();
        if (lineCount > 40) {
            return ValidationResult.fail("Javadoc exceeds 40 lines");
        }

        if ("METHOD".equals(entry.getKind()) || "CONSTRUCTOR".equals(entry.getKind())) {
            String signature = entry.getMemberSignature();
            if (signature != null) {
                Set<String> expectedParams = extractParamNames(signature);
                Set<String> actualParams = extractJavadocParams(javadoc);

                if (!expectedParams.isEmpty() && !actualParams.containsAll(expectedParams)) {
                    return ValidationResult.fail("@param tags do not match signature parameters");
                }

                if ("METHOD".equals(entry.getKind())) {
                    boolean isVoid = signature.startsWith("void ");
                    boolean hasReturn = RETURN_PATTERN.matcher(javadoc).find();

                    if (isVoid && hasReturn) {
                        return ValidationResult.fail("void method should not have @return");
                    }
                }
            }
        }

        return ValidationResult.success();
    }

    private static Set<String> extractParamNames(String signature) {
        Set<String> params = new HashSet<>();
        int start = signature.indexOf('(');
        int end = signature.indexOf(')');
        if (start >= 0 && end > start) {
            String paramList = signature.substring(start + 1, end).trim();
            if (!paramList.isEmpty()) {
                for (String param : paramList.split(",")) {
                    String[] parts = param.trim().split("\\s+");
                    if (parts.length >= 2) {
                        params.add(parts[parts.length - 1]);
                    }
                }
            }
        }
        return params;
    }

    private static Set<String> extractJavadocParams(String javadoc) {
        Set<String> params = new HashSet<>();
        Matcher matcher = PARAM_PATTERN.matcher(javadoc);
        while (matcher.find()) {
            params.add(matcher.group(1));
        }
        return params;
    }

    private static Set<String> extractDeclaredExceptions(String signature) {
        Set<String> exceptions = new HashSet<>();
        int throwsIdx = signature.indexOf("throws ");
        if (throwsIdx >= 0) {
            String exList = signature.substring(throwsIdx + 7).trim();
            for (String ex : exList.split(",")) {
                exceptions.add(ex.trim());
            }
        }
        return exceptions;
    }

    private static Set<String> extractJavadocExceptions(String javadoc) {
        Set<String> exceptions = new HashSet<>();
        Matcher matcher = THROWS_PATTERN.matcher(javadoc);
        while (matcher.find()) {
            exceptions.add(matcher.group(1));
        }
        return exceptions;
    }

    public static class ValidationResult {
        private final boolean valid;
        private final String errorMessage;

        private ValidationResult(boolean valid, String errorMessage) {
            this.valid = valid;
            this.errorMessage = errorMessage;
        }

        public static ValidationResult success() {
            return new ValidationResult(true, null);
        }

        public static ValidationResult fail(String message) {
            return new ValidationResult(false, message);
        }

        public boolean isValid() {
            return valid;
        }

        public String getErrorMessage() {
            return errorMessage;
        }
    }
}

package br.unb.cic.docsgenerator.bedrock;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

public class DocsValidator {
    private static final int MAX_LINES = 800;

    private static final Map<String, List<String>> README_HEADINGS = Map.of(
            "en", Arrays.asList("# Project Overview", "# How to Build and Run", "# Codebase Tour", "# Key Components"),
            "pt", Arrays.asList("# Visão Geral do Projeto", "# Como Construir e Executar", "# Tour pelo Código", "# Componentes Principais")
    );

    private static final Map<String, List<String>> ARCHITECTURE_HEADINGS = Map.of(
            "en", Arrays.asList("# Architecture Overview", "# Components and Responsibilities", "# Data Flow and Key Workflows", "# Extension Points"),
            "pt", Arrays.asList("# Visão Geral da Arquitetura", "# Componentes e Responsabilidades", "# Fluxo de Dados e Principais Fluxos", "# Pontos de Extensão")
    );

    private static final Map<String, List<String>> API_HEADINGS = Map.of(
            "en", Arrays.asList("# API Overview", "# Endpoints", "# Data Contracts", "# Error Handling"),
            "pt", Arrays.asList("# Visão Geral da API", "# Endpoints", "# Contratos de Dados", "# Tratamento de Erros")
    );

    private static final Map<String, List<String>> MANUAL_TESTS_HEADINGS = Map.of(
            "en", Arrays.asList("# Manual Test Cases"),
            "pt", Arrays.asList("# Casos de Teste Manual")
    );

    public static ValidationResult validateReadme(String content, String language) {
        return validate(content, headings(README_HEADINGS, language), "README");
    }

    public static ValidationResult validateArchitecture(String content, String language) {
        return validate(content, headings(ARCHITECTURE_HEADINGS, language), "ARCHITECTURE");
    }

    public static ValidationResult validateApi(String content, String language) {
        return validate(content, headings(API_HEADINGS, language), "API");
    }

    public static ValidationResult validateManualTests(String content, String language) {
        ValidationResult headingCheck = validate(content, headings(MANUAL_TESTS_HEADINGS, language), "MANUAL_TESTS");
        if (!headingCheck.isValid()) return headingCheck;
        // Also require at least one Markdown table row
        boolean hasTable = content != null && content.lines()
                .anyMatch(line -> line.startsWith("|") && line.chars().filter(c -> c == '|').count() >= 3);
        return hasTable ? ValidationResult.success()
                : ValidationResult.fail("MANUAL_TESTS has no test table (expected Markdown table with | Step | Action | Verification |)");
    }

    // Backward-compatible overloads defaulting to English
    public static ValidationResult validateReadme(String content) {
        return validateReadme(content, "en");
    }

    public static ValidationResult validateArchitecture(String content) {
        return validateArchitecture(content, "en");
    }

    public static ValidationResult validateApi(String content) {
        return validateApi(content, "en");
    }

    public static List<String> findMissingHeadings(String content, String docType, String language) {
        Map<String, List<String>> map = switch (docType) {
            case "README"        -> README_HEADINGS;
            case "ARCHITECTURE"  -> ARCHITECTURE_HEADINGS;
            case "API"           -> API_HEADINGS;
            case "MANUAL_TESTS"  -> MANUAL_TESTS_HEADINGS;
            default              -> Map.of();
        };
        List<String> required = headings(map, language);
        List<String> actual = content == null ? List.of()
                : content.lines().filter(l -> l.startsWith("#")).collect(Collectors.toList());
        return required.stream()
                .filter(heading -> {
                    String text = heading.replaceFirst("^#+\\s*", "").toLowerCase(Locale.ROOT);
                    return actual.stream().noneMatch(l -> l.toLowerCase(Locale.ROOT).contains(text));
                })
                .collect(Collectors.toList());
    }

    private static List<String> headings(Map<String, List<String>> map, String language) {
        return map.getOrDefault(language, map.get("en"));
    }

    private static ValidationResult validate(String content, List<String> requiredHeadings, String docType) {
        if (content == null || content.isEmpty()) {
            return ValidationResult.fail(docType + " content is empty");
        }

        long lineCount = content.lines().count();
        if (lineCount > MAX_LINES) {
            return ValidationResult.fail(docType + " exceeds " + MAX_LINES + " lines");
        }

        // Accept the heading at any level (# ## ### etc.), case-insensitively.
        // Strip the leading hashes from the required heading and check that some line
        // starts with '#' and contains the text (case-insensitive).
        List<String> actualHeadings = content.lines()
                .filter(line -> line.startsWith("#"))
                .collect(Collectors.toList());

        for (String heading : requiredHeadings) {
            String headingText = heading.replaceFirst("^#+\\s*", "").toLowerCase(Locale.ROOT);
            boolean found = actualHeadings.stream()
                    .anyMatch(line -> line.toLowerCase(Locale.ROOT).contains(headingText));
            if (!found) {
                String found_headings = actualHeadings.isEmpty() ? "none"
                        : String.join(", ", actualHeadings);
                return ValidationResult.fail(docType + " missing required heading: " + heading
                        + " | found headings: " + found_headings);
            }
        }

        return ValidationResult.success();
    }

    public static class ValidationResult {
        private final boolean valid;
        private final String errorMessage;

        private ValidationResult(boolean valid, String errorMessage) {
            this.valid = valid;
            this.errorMessage = errorMessage;
        }

        public static ValidationResult success() {
            return new ValidationResult(true, null);
        }

        public static ValidationResult fail(String message) {
            return new ValidationResult(false, message);
        }

        public boolean isValid() {
            return valid;
        }

        public String getErrorMessage() {
            return errorMessage;
        }
    }
}

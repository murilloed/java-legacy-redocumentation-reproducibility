package br.unb.cic.docsgenerator.bedrock;

import br.unb.cic.docsgenerator.ai.DocsClient;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import software.amazon.awssdk.auth.credentials.DefaultCredentialsProvider;
import software.amazon.awssdk.core.SdkBytes;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.bedrockruntime.BedrockRuntimeClient;
import software.amazon.awssdk.services.bedrockruntime.model.InvokeModelRequest;
import software.amazon.awssdk.services.bedrockruntime.model.InvokeModelResponse;

import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class BedrockDocsClient implements DocsClient {
    private final BedrockRuntimeClient client;
    private final String modelId;
    private final String language;
    private final ObjectMapper mapper = new ObjectMapper();

    public BedrockDocsClient(String region, String modelId, int timeoutSeconds, String language) {
        this.modelId = modelId;
        this.language = language;
        
        try {
            this.client = BedrockRuntimeClient.builder()
                    .region(Region.of(region))
                    .credentialsProvider(DefaultCredentialsProvider.create())
                    .overrideConfiguration(c -> c.apiCallTimeout(Duration.ofSeconds(timeoutSeconds)))
                    .build();
        } catch (Exception e) {
            throw new RuntimeException("Failed to initialize Bedrock docs client: " + e.getMessage(), e);
        }
    }

    public String generateReadme(DocsContext context) {
        String prompt = buildReadmePrompt(context);
        return invokeModel(prompt, 4000);
    }

    public String generateArchitecture(DocsContext context) {
        String prompt = buildArchitecturePrompt(context);
        return invokeModel(prompt, 4000);
    }

    public String generateApi(DocsContext context) {
        String prompt = buildApiPrompt(context);
        return invokeModel(prompt, 4000);
    }

    public String generateManualTestsForController(DocsContext.ControllerContext controllerContext, String language) {
        String prompt = buildManualTestsPrompt(controllerContext, language);
        return invokeModel(prompt, 8000);
    }

    private String buildReadmePrompt(DocsContext context) {
        String langName = "pt".equals(language) ? "Brazilian Portuguese (pt-BR)" : "English";
        StringBuilder prompt = new StringBuilder();
        prompt.append("Generate a README.md file for a Java project.\n\n");
        prompt.append("CRITICAL RULES:\n");
        prompt.append("- Return ONLY Markdown content\n");
        prompt.append("- Write all content in ").append(langName).append("\n");
        prompt.append("- Use ONLY the information provided below\n");
        prompt.append("- Do NOT invent endpoints, features, data stores, or workflows\n");
        prompt.append("- Be concise and suitable for onboarding a new developer\n");
        if ("pt".equals(language)) {
            prompt.append("- MUST include these exact headings: # Visão Geral do Projeto, # Como Construir e Executar, # Tour pelo Código, # Componentes Principais\n\n");
        } else {
            prompt.append("- MUST include these exact headings: # Project Overview, # How to Build and Run, # Codebase Tour, # Key Components\n\n");
        }
        
        prompt.append("Project Information:\n");
        prompt.append("- Name: ").append(context.getProjectName()).append("\n");
        prompt.append("- Files: ").append(context.getFileCount()).append("\n");
        prompt.append("- Public types: ").append(context.getPublicTypeCount()).append("\n");
        prompt.append("- Public methods: ").append(context.getPublicMethodCount()).append("\n");
        prompt.append("- Has pom.xml: ").append(context.isHasPomXml()).append("\n");
        if (context.getMainClass() != null) {
            prompt.append("- Main class: ").append(context.getMainClass()).append("\n");
        }
        
        prompt.append("\nTop-level packages:\n");
        context.getTopLevelPackages().forEach(pkg -> prompt.append("- ").append(pkg).append("\n"));
        
        if (!context.getHttpEndpoints().isEmpty()) {
            prompt.append("\nHTTP Endpoints detected: ").append(context.getHttpEndpoints().size()).append("\n");
        }
        
        if (!context.getServices().isEmpty()) {
            prompt.append("\nServices:\n");
            context.getServices().forEach(svc -> prompt.append("- ").append(svc).append("\n"));
        }
        
        if (!context.getRepositories().isEmpty()) {
            prompt.append("\nRepositories:\n");
            context.getRepositories().forEach(repo -> prompt.append("- ").append(repo).append("\n"));
        }
        
        return prompt.toString();
    }

    private String buildArchitecturePrompt(DocsContext context) {
        String langName = "pt".equals(language) ? "Brazilian Portuguese (pt-BR)" : "English";
        StringBuilder prompt = new StringBuilder();
        prompt.append("Generate an ARCHITECTURE.md file for a Java project.\n\n");
        prompt.append("CRITICAL RULES:\n");
        prompt.append("- Return ONLY Markdown content\n");
        prompt.append("- Write all content in ").append(langName).append("\n");
        prompt.append("- Use ONLY the information provided below\n");
        prompt.append("- Do NOT invent endpoints, features, data stores, or workflows\n");
        prompt.append("- Be concise and suitable for understanding the codebase structure\n");
        if ("pt".equals(language)) {
            prompt.append("- MUST include these exact headings: # Visão Geral da Arquitetura, # Componentes e Responsabilidades, # Fluxo de Dados e Principais Fluxos, # Pontos de Extensão\n\n");
        } else {
            prompt.append("- MUST include these exact headings: # Architecture Overview, # Components and Responsibilities, # Data Flow and Key Workflows, # Extension Points\n\n");
        }
        
        prompt.append("Project Information:\n");
        prompt.append("- Name: ").append(context.getProjectName()).append("\n");
        
        prompt.append("\nPackage structure:\n");
        context.getTopLevelPackages().forEach(pkg -> prompt.append("- ").append(pkg).append("\n"));
        
        prompt.append("\nPublic types by kind:\n");
        Map<String, Long> typesByKind = context.getPublicTypes().stream()
                .collect(Collectors.groupingBy(DocsContext.PublicType::getKind, Collectors.counting()));
        typesByKind.forEach((kind, count) -> prompt.append("- ").append(kind).append(": ").append(count).append("\n"));
        
        if (!context.getServices().isEmpty()) {
            prompt.append("\nService layer:\n");
            context.getServices().forEach(svc -> prompt.append("- ").append(svc).append("\n"));
        }
        
        if (!context.getRepositories().isEmpty()) {
            prompt.append("\nData access layer:\n");
            context.getRepositories().forEach(repo -> prompt.append("- ").append(repo).append("\n"));
        }
        
        if (!context.getHttpEndpoints().isEmpty()) {
            prompt.append("\nHTTP API layer detected with ").append(context.getHttpEndpoints().size()).append(" endpoints\n");
        }
        
        return prompt.toString();
    }

    private String buildApiPrompt(DocsContext context) {
        String langName = "pt".equals(language) ? "Brazilian Portuguese (pt-BR)" : "English";
        boolean pt = "pt".equals(language);
        StringBuilder prompt = new StringBuilder();
        prompt.append("Generate an API.md file for a Java project.\n\n");
        prompt.append("CRITICAL RULES:\n");
        prompt.append("- Return ONLY Markdown content\n");
        prompt.append("- Write all content in ").append(langName).append("\n");
        prompt.append("- Use ONLY the information provided below\n");
        prompt.append("- Do NOT invent endpoints, features, data stores, or workflows\n");
        prompt.append("- The document MUST contain EXACTLY these four top-level sections, each as a single-# heading, in this order:\n");
        if (pt) {
            prompt.append("    1. # Visão Geral da API\n");
            prompt.append("    2. # Endpoints\n");
            prompt.append("    3. # Contratos de Dados\n");
            prompt.append("    4. # Tratamento de Erros\n\n");
        } else {
            prompt.append("    1. # API Overview\n");
            prompt.append("    2. # Endpoints\n");
            prompt.append("    3. # Data Contracts\n");
            prompt.append("    4. # Error Handling\n\n");
        }

        prompt.append("SECTION GUIDANCE:\n");
        if (pt) {
            prompt.append("- # Visão Geral da API — um parágrafo resumindo o que a API faz e quantos endpoints expõe.\n");
            prompt.append("- # Endpoints — liste cada controlador/resource com seus métodos como sub-seções (##).\n");
            prompt.append("- # Contratos de Dados — descreva os tipos de dados de entrada e saída. Se os schemas não estiverem disponíveis, mencione que os payloads seguem convenções REST padrão e liste os controladores relevantes.\n");
            prompt.append("- # Tratamento de Erros — descreva os códigos HTTP de erro comuns (400, 401, 403, 404, 500) e quando cada um ocorre.\n\n");
        } else {
            prompt.append("- # API Overview — one paragraph summarising what the API does and how many endpoints it exposes.\n");
            prompt.append("- # Endpoints — list each controller/resource with its HTTP methods as sub-sections (##).\n");
            prompt.append("- # Data Contracts — describe request and response data types. If detailed schemas are unavailable, state that payloads follow standard REST conventions and list the relevant controllers.\n");
            prompt.append("- # Error Handling — describe common HTTP error codes returned (400, 401, 403, 404, 500) and when each occurs.\n\n");
        }

        if (context.getHttpEndpoints().isEmpty()) {
            prompt.append("No HTTP endpoints detected. Document public interfaces/classes grouped by package.\n\n");
            prompt.append("Public types:\n");
            Map<String, List<DocsContext.PublicType>> byPackage = context.getPublicTypes().stream()
                    .collect(Collectors.groupingBy(t -> extractPackage(t.getFqcn())));
            byPackage.forEach((pkg, types) -> {
                prompt.append("\nPackage: ").append(pkg).append("\n");
                types.forEach(type -> prompt.append("- ").append(type.getKind()).append(": ").append(extractClassName(type.getFqcn())).append("\n"));
            });
        } else {
            prompt.append("SIGNATURE INTERPRETATION GUIDE:\n");
            prompt.append("- Signature format: returnType methodName(paramType1, paramType2, ...)\n");
            prompt.append("- Non-primitive, non-Authentication parameters in POST/PUT are typically the @RequestBody payload\n");
            prompt.append("- Strip ResponseEntity<> to get the actual response type\n");
            prompt.append("- Use DTO/entity type names to describe what the payload contains\n\n");
            prompt.append("HTTP Endpoints (").append(context.getHttpEndpoints().size()).append(" total):\n");
            context.getHttpEndpoints().forEach(ep -> {
                prompt.append("- ").append(ep.getMethod()).append(" ").append(ep.getPath())
                        .append(" [").append(ep.getController()).append(".").append(ep.getMethodName()).append("]");
                if (ep.getSignature() != null && !ep.getSignature().isBlank()) {
                    prompt.append(" — ").append(ep.getSignature());
                }
                prompt.append("\n");
            });
        }

        return prompt.toString();
    }

    private String invokeModel(String prompt, int maxTokens) {
        int maxRetries = 3;
        int retryDelayMs = 1000;
        
        for (int attempt = 1; attempt <= maxRetries; attempt++) {
            try {
                String requestBody = buildRequestBody(prompt, maxTokens);
                
                InvokeModelRequest request = InvokeModelRequest.builder()
                        .modelId(modelId)
                        .body(SdkBytes.fromUtf8String(requestBody))
                        .build();

                InvokeModelResponse response = client.invokeModel(request);
                String responseBody = response.body().asUtf8String();
                
                return extractTextFromResponse(responseBody);
            } catch (Exception e) {
                if (attempt == maxRetries) {
                    throw new RuntimeException("Bedrock docs call failed after " + maxRetries + " attempts: " + e.getMessage(), e);
                }
                
                System.err.println("Bedrock docs call failed (attempt " + attempt + "/" + maxRetries + "): " + e.getMessage());
                try {
                    Thread.sleep(retryDelayMs * attempt); // Exponential backoff
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    throw new RuntimeException("Interrupted during retry", ie);
                }
            }
        }
        
        throw new RuntimeException("Bedrock docs call failed after retries");
    }

    private String buildRequestBody(String prompt, int maxTokens) throws Exception {
        Map<String, Object> body = new HashMap<>();

        if (modelId.contains("anthropic")) {
            body.put("anthropic_version", "bedrock-2023-05-31");
            body.put("max_tokens", maxTokens);
            body.put("temperature", 0.2);
            body.put("messages", List.of(Map.of("role", "user", "content", prompt)));
        } else if (modelId.contains("amazon")) {
            Map<String, Object> textGenConfig = new HashMap<>();
            textGenConfig.put("maxTokenCount", maxTokens);
            textGenConfig.put("temperature", 0.2);
            body.put("inputText", prompt);
            body.put("textGenerationConfig", textGenConfig);
        } else {
            body.put("prompt", prompt);
            body.put("max_tokens", maxTokens);
            body.put("temperature", 0.2);
        }

        return mapper.writeValueAsString(body);
    }

    private String extractTextFromResponse(String responseBody) throws Exception {
        JsonNode root = mapper.readTree(responseBody);
        String text = null;
        
        if (root.has("content")) {
            text = root.get("content").get(0).get("text").asText();
        } else if (root.has("results")) {
            text = root.get("results").get(0).get("outputText").asText();
        } else if (root.has("completion")) {
            text = root.get("completion").asText();
        } else if (root.has("output")) {
            text = root.get("output").asText();
        }
        
        if (text == null) {
            throw new RuntimeException("Could not extract text from Bedrock response");
        }
        
        return text.trim();
    }

    private String buildManualTestsPrompt(DocsContext.ControllerContext ctx, String lang) {
        boolean pt = "pt".equals(lang);
        String langName = pt ? "Brazilian Portuguese (pt-BR)" : "English";
        StringBuilder prompt = new StringBuilder();

        prompt.append("You are a QA analyst writing manual test cases for a Spring REST controller.\n");
        prompt.append("Generate a Markdown document with scenario-based manual test cases.\n\n");

        prompt.append("CRITICAL RULES:\n");
        prompt.append("- Return ONLY Markdown content\n");
        prompt.append("- Write all content in ").append(langName).append("\n");
        prompt.append("- Generate 3 to 6 BUSINESS SCENARIOS — not one test per endpoint\n");
        prompt.append("- A scenario represents a complete business workflow, possibly spanning multiple HTTP calls\n");
        prompt.append("- Use the source code to infer real paths, field names, and business rules\n");
        prompt.append("- Actions must describe what the TESTER DOES (e.g. 'Fill the form with...', 'Send POST to /path with body {...}')\n");
        prompt.append("- Verifications must describe OBSERVABLE BUSINESS OUTCOMES, not just HTTP codes\n");
        prompt.append("  (e.g. 'The record appears in the list', 'The status changes to FINALIZADO')\n");
        prompt.append("  HTTP codes may be mentioned alongside the business outcome\n");
        prompt.append("- Include concrete example values for fields when they can be inferred from the source\n\n");

        prompt.append("DOCUMENT STRUCTURE (follow exactly):\n");
        if (pt) {
            prompt.append("# Casos de Teste Manual — ").append(ctx.getControllerName()).append("\n\n");
            prompt.append("## Cenário N: [Nome do cenário de negócio]\n\n");
            prompt.append("**Objetivo:** [O que a regra de negócio ou fluxo este teste valida]\n\n");
            prompt.append("**Pré-condições:** [Dados de teste necessários e papel do usuário]\n\n");
            prompt.append("| Passo | Ação | Verificação |\n");
            prompt.append("|-------|------|-------------|\n");
            prompt.append("| N | [Ação concreta do testador com dados específicos] | [Resultado de negócio observável] |\n\n");
        } else {
            prompt.append("# Manual Test Cases — ").append(ctx.getControllerName()).append("\n\n");
            prompt.append("## Scenario N: [Business scenario name]\n\n");
            prompt.append("**Purpose:** [What business rule or workflow this validates]\n\n");
            prompt.append("**Preconditions:** [Required test data and user role]\n\n");
            prompt.append("| Step | Action | Verification |\n");
            prompt.append("|------|--------|---------------|\n");
            prompt.append("| N | [Concrete tester action with specific data] | [Observable business outcome] |\n\n");
        }

        prompt.append("SOURCE CODE (use this to identify real paths, field names, and business logic):\n");
        prompt.append("File: ").append(ctx.getFilePath()).append("\n\n");
        prompt.append("```java\n");
        prompt.append(ctx.getSourceCode());
        prompt.append("\n```\n");

        return prompt.toString();
    }

    private String extractPackage(String fqcn) {
        int lastDot = fqcn.lastIndexOf('.');
        return lastDot > 0 ? fqcn.substring(0, lastDot) : "(default)";
    }

    private String extractClassName(String fqcn) {
        int lastDot = fqcn.lastIndexOf('.');
        return lastDot > 0 ? fqcn.substring(lastDot + 1) : fqcn;
    }

    public void close() {
        if (client != null) {
            client.close();
        }
    }
}

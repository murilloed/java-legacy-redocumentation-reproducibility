package br.unb.cic.docsgenerator.javadoc;

import com.github.javaparser.ast.body.*;

import java.util.stream.Collectors;

public class JavadocGenerator {
    public static String generateClassJavadoc(String className) {
        String[] words = splitCamelCase(className);
        String summary = String.join(" ", words);
        return summary + ".\n@author docs-generator";
    }

    public static String generateMethodJavadoc(MethodDeclaration method) {
        StringBuilder sb = new StringBuilder();
        String verb = extractVerb(method.getNameAsString());
        sb.append("Executes ").append(verb).append(".");

        if (!method.getParameters().isEmpty() || !method.getType().isVoidType() || !method.getThrownExceptions().isEmpty()) {
            sb.append("\n");
        }

        method.getParameters().forEach(param ->
                sb.append("@param ").append(param.getNameAsString()).append(" the ").append(param.getNameAsString()).append("\n")
        );

        if (!method.getType().isVoidType()) {
            sb.append("@return the result\n");
        }

        method.getThrownExceptions().forEach(ex ->
                sb.append("@throws ").append(ex.asString()).append(" if an error occurs\n")
        );

        return sb.toString().trim();
    }

    public static String generateConstructorJavadoc(ConstructorDeclaration ctor) {
        StringBuilder sb = new StringBuilder();
        sb.append("Constructs a new ").append(ctor.getNameAsString()).append(".");

        if (!ctor.getParameters().isEmpty() || !ctor.getThrownExceptions().isEmpty()) {
            sb.append("\n");
        }

        ctor.getParameters().forEach(param ->
                sb.append("@param ").append(param.getNameAsString()).append(" the ").append(param.getNameAsString()).append("\n")
        );

        ctor.getThrownExceptions().forEach(ex ->
                sb.append("@throws ").append(ex.asString()).append(" if an error occurs\n")
        );

        return sb.toString().trim();
    }

    public static String generateEnumJavadoc(String enumName) {
        String[] words = splitCamelCase(enumName);
        String summary = String.join(" ", words);
        return summary + " enumeration.";
    }

    private static String[] splitCamelCase(String s) {
        return s.replaceAll("([a-z])([A-Z])", "$1 $2").split(" ");
    }

    private static String extractVerb(String methodName) {
        if (methodName.startsWith("get")) return "retrieval operation";
        if (methodName.startsWith("set")) return "update operation";
        if (methodName.startsWith("is") || methodName.startsWith("has")) return "check operation";
        if (methodName.startsWith("create")) return "creation operation";
        if (methodName.startsWith("delete")) return "deletion operation";
        if (methodName.startsWith("update")) return "update operation";
        if (methodName.startsWith("find")) return "search operation";
        if (methodName.startsWith("save")) return "save operation";
        return "operation";
    }
}

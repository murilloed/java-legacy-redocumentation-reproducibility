package br.unb.cic.docsgenerator.bedrock;

import br.unb.cic.docsgenerator.ai.PrioritizationClient;
import br.unb.cic.docsgenerator.manifest.ManifestEntry;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import software.amazon.awssdk.auth.credentials.DefaultCredentialsProvider;
import software.amazon.awssdk.core.SdkBytes;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.bedrockruntime.BedrockRuntimeClient;
import software.amazon.awssdk.services.bedrockruntime.model.InvokeModelRequest;
import software.amazon.awssdk.services.bedrockruntime.model.InvokeModelResponse;

import java.time.Duration;
import java.util.*;
import java.util.stream.Collectors;

public class BedrockPrioritizationClient implements PrioritizationClient {
    private final BedrockRuntimeClient client;
    private final String modelId;
    private final ObjectMapper mapper = new ObjectMapper();

    public BedrockPrioritizationClient(String region, String modelId, int timeoutSeconds) {
        this.modelId = modelId;
        this.client = BedrockRuntimeClient.builder()
                .region(Region.of(region))
                .credentialsProvider(DefaultCredentialsProvider.create())
                .overrideConfiguration(c -> c.apiCallTimeout(Duration.ofSeconds(timeoutSeconds)))
                .build();
    }

    /**
     * Returns entries reordered by documentation priority. Entries the LLM
     * considers trivial (pure getters, simple constructors, etc.) are dropped.
     * Falls back to the original list on any failure.
     */
    public List<ManifestEntry> prioritize(List<ManifestEntry> entries) {
        if (entries.isEmpty()) return entries;

        try {
            String prompt = buildPrompt(entries);
            String requestBody = buildRequestBody(prompt);

            InvokeModelRequest request = InvokeModelRequest.builder()
                    .modelId(modelId)
                    .body(SdkBytes.fromUtf8String(requestBody))
                    .build();

            InvokeModelResponse response = client.invokeModel(request);
            List<String> orderedIds = extractTargetIds(response.body().asUtf8String());
            return reorderByIds(entries, orderedIds);

        } catch (Exception e) {
            System.err.println("LLM prioritization failed, using original order: " + e.getMessage());
            return entries;
        }
    }

    private String buildPrompt(List<ManifestEntry> entries) {
        StringBuilder sb = new StringBuilder();
        sb.append("You are a documentation prioritization assistant for Java projects.\n");
        sb.append("Identify which code elements would benefit MOST from Javadoc documentation.\n\n");
        sb.append("OMIT from the result:\n");
        sb.append("- Trivial getters, setters, equals, hashCode, toString\n");
        sb.append("- Simple constructors that only assign fields\n");
        sb.append("- DTO/data classes with no real logic\n\n");
        sb.append("INCLUDE and RANK FIRST:\n");
        sb.append("- Complex business logic and service methods\n");
        sb.append("- Controller endpoints and public APIs\n");
        sb.append("- Non-obvious utility methods\n");
        sb.append("- Methods with complex signatures or declared exceptions\n\n");
        sb.append("Return ONLY a JSON array of targetIds in priority order (highest priority first).\n");
        sb.append("Example: [\"id1\", \"id2\", \"id3\"]\n\n");
        sb.append("Entries:\n");

        for (ManifestEntry e : entries) {
            sb.append("- id: ").append(e.getTargetId()).append("\n");
            sb.append("  type: ").append(e.getKind()).append("\n");
            sb.append("  class: ").append(e.getFqcn()).append("\n");
            if (e.getMemberSignature() != null) {
                sb.append("  signature: ").append(e.getMemberSignature()).append("\n");
            }
            if (!e.getAnnotations().isEmpty()) {
                sb.append("  annotations: ").append(String.join(", ", e.getAnnotations())).append("\n");
            }
            sb.append("  complexityScore: ").append(e.getComplexityScore()).append("\n");
        }

        return sb.toString();
    }

    private String buildRequestBody(String prompt) throws Exception {
        Map<String, Object> body = new HashMap<>();
        if (modelId.contains("anthropic")) {
            body.put("anthropic_version", "bedrock-2023-05-31");
            body.put("max_tokens", 4096);
            body.put("temperature", 0.1);
            body.put("messages", List.of(Map.of("role", "user", "content", prompt)));
        } else if (modelId.contains("amazon")) {
            body.put("inputText", prompt);
            body.put("textGenerationConfig", Map.of("maxTokenCount", 4096, "temperature", 0.1));
        } else {
            body.put("prompt", prompt);
            body.put("max_tokens", 4096);
            body.put("temperature", 0.1);
        }
        return mapper.writeValueAsString(body);
    }

    private List<String> extractTargetIds(String responseBody) throws Exception {
        JsonNode root = mapper.readTree(responseBody);
        String text = null;

        if (root.has("content")) {
            text = root.get("content").get(0).get("text").asText();
        } else if (root.has("results")) {
            text = root.get("results").get(0).get("outputText").asText();
        } else if (root.has("completion")) {
            text = root.get("completion").asText();
        } else if (root.has("output")) {
            text = root.get("output").asText();
        }

        if (text == null) throw new RuntimeException("Could not extract text from Bedrock response");

        int start = text.indexOf('[');
        int end = text.lastIndexOf(']');
        if (start < 0 || end <= start) throw new RuntimeException("No JSON array found in LLM response");

        JsonNode array = mapper.readTree(text.substring(start, end + 1));
        List<String> ids = new ArrayList<>();
        for (JsonNode node : array) {
            ids.add(node.asText());
        }
        return ids;
    }

    private List<ManifestEntry> reorderByIds(List<ManifestEntry> entries, List<String> orderedIds) {
        Map<String, ManifestEntry> byId = entries.stream()
                .collect(Collectors.toMap(ManifestEntry::getTargetId, e -> e));

        return orderedIds.stream()
                .map(byId::get)
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
    }

    public void close() {
        if (client != null) {
            client.close();
        }
    }
}

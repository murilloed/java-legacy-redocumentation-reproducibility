package br.unb.cic.docsgenerator.javadoc;

import br.unb.cic.docsgenerator.ai.JavadocClient;
import br.unb.cic.docsgenerator.bedrock.ContextExtractor;
import br.unb.cic.docsgenerator.bedrock.JavadocValidator;
import br.unb.cic.docsgenerator.manifest.Manifest;
import br.unb.cic.docsgenerator.manifest.ManifestEntry;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.github.javaparser.StaticJavaParser;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.body.*;
import com.github.javaparser.printer.lexicalpreservation.LexicalPreservingPrinter;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Collectors;

public class JavadocInjector {
    private final Path codeRoot;
    private final JavadocClient aiClient;
    private final int maxAiCalls;
    private final Manifest manifest;
    private final boolean computeMetrics;

    public JavadocInjector(Path codeRoot, JavadocClient aiClient, int maxAiCalls,
                           Manifest manifest, boolean computeMetrics) {
        this.codeRoot = codeRoot;
        this.aiClient = aiClient;
        this.maxAiCalls = maxAiCalls;
        this.manifest = manifest;
        this.computeMetrics = computeMetrics;
    }

    public void inject(SelectionResult selectionResult, Path reportPath) throws IOException {
        List<ManifestEntry> entries = selectionResult.entries();

        // outcome tracked per entry identity (ManifestEntry has no custom equals/hashCode)
        Map<ManifestEntry, String> outcomes = new IdentityHashMap<>();
        Map<ManifestEntry, String> generatedTexts = new IdentityHashMap<>();

        Map<String, List<ManifestEntry>> byFile = new LinkedHashMap<>();
        for (ManifestEntry entry : entries) {
            byFile.computeIfAbsent(entry.getFilePath(), k -> new ArrayList<>()).add(entry);
        }

        int totalAdded = 0;
        int totalSkipped = 0;
        int aiCallsAttempted = 0;
        int aiCallsSucceeded = 0;
        int aiCallsFailed = 0;
        int validationFailed = 0;
        List<Map<String, Object>> fileReports = new ArrayList<>();

        for (Map.Entry<String, List<ManifestEntry>> fileEntry : byFile.entrySet()) {
            Path javaFile = codeRoot.resolve(fileEntry.getKey());
            if (!Files.exists(javaFile)) {
                for (ManifestEntry e : fileEntry.getValue()) outcomes.put(e, "notInjected");
                continue;
            }

            try {
                InjectionResult result = processFile(javaFile, fileEntry.getValue(), aiCallsAttempted, outcomes, generatedTexts);
                totalAdded += result.added;
                totalSkipped += fileEntry.getValue().size() - result.added;
                aiCallsAttempted = result.aiCallsAttempted;
                aiCallsSucceeded += result.aiCallsSucceeded;
                aiCallsFailed += result.aiCallsFailed;
                validationFailed += result.validationFailed;

                Map<String, Object> fileReport = new LinkedHashMap<>();
                fileReport.put("file", fileEntry.getKey());
                fileReport.put("added", result.added);
                fileReport.put("skipped", fileEntry.getValue().size() - result.added);
                fileReports.add(fileReport);
            } catch (Exception e) {
                System.err.println("Error injecting into " + javaFile + ": " + e.getMessage());
                for (ManifestEntry entry : fileEntry.getValue()) {
                    outcomes.put(entry, "notInjected");
                }
            }
        }

        Map<String, Object> report = buildReport(selectionResult, entries, outcomes,
                totalAdded, totalSkipped, aiCallsAttempted, aiCallsSucceeded,
                aiCallsFailed, validationFailed, fileReports);

        ObjectMapper jsonMapper = new ObjectMapper();
        jsonMapper.enable(SerializationFeature.INDENT_OUTPUT);
        jsonMapper.writeValue(reportPath.toFile(), report);

        if (computeMetrics) {
            Path csvPath = reportPath.getParent().resolve("javadoc_metrics.csv");
            writeMetricsCsv(entries, outcomes, generatedTexts, csvPath);
        }

        System.out.println("Javadocs added: " + totalAdded + ", skipped: " + totalSkipped);
        if (aiClient != null) {
            System.out.println("AI calls: " + aiCallsAttempted + " attempted, " +
                aiCallsSucceeded + " succeeded, " + aiCallsFailed + " failed");
            System.out.println("Validation failures: " + validationFailed);

            if (aiCallsFailed > 0) {
                System.err.println("Warning: " + aiCallsFailed + " AI calls failed; template fallback was used where possible");
            }
        }
    }

    private Map<String, Object> buildReport(
            SelectionResult sel, List<ManifestEntry> entries,
            Map<ManifestEntry, String> outcomes,
            int totalAdded, int totalSkipped,
            int aiCallsAttempted, int aiCallsSucceeded,
            int aiCallsFailed, int validationFailed,
            List<Map<String, Object>> fileReports) {

        // Selection summary
        Map<String, Object> selectionSummary = new LinkedHashMap<>();
        selectionSummary.put("totalScanned", sel.totalScanned());
        selectionSummary.put("undocumented", sel.undocumented());
        if (sel.afterStructuralFilter() >= 0) selectionSummary.put("afterStructuralFilter", sel.afterStructuralFilter());
        if (sel.afterMetrics() >= 0)          selectionSummary.put("afterMetricsPrioritization", sel.afterMetrics());
        if (sel.afterLLM() >= 0)              selectionSummary.put("afterLLMPrioritization", sel.afterLLM());
        selectionSummary.put("finalSelected", entries.size());
        selectionSummary.put("strategiesApplied", sel.strategiesApplied());

        // Per-entry ranked targets
        List<Map<String, Object>> rankedTargets = new ArrayList<>();
        for (int i = 0; i < entries.size(); i++) {
            ManifestEntry e = entries.get(i);
            Map<String, Object> t = new LinkedHashMap<>();
            t.put("rank", i + 1);
            t.put("fqcn", e.getFqcn());
            t.put("kind", e.getKind());
            if (e.getMemberSignature() != null) t.put("memberSignature", e.getMemberSignature());
            t.put("complexityScore", e.getComplexityScore());
            t.put("isSimpleDataClass", e.isSimpleDataClass());
            t.put("outcome", outcomes.getOrDefault(e, "notInjected"));
            rankedTargets.add(t);
        }

        // Complexity stats
        IntSummaryStatistics stats = entries.stream()
                .mapToInt(ManifestEntry::getComplexityScore)
                .summaryStatistics();
        Map<String, Object> complexityStats = new LinkedHashMap<>();
        if (stats.getCount() > 0) {
            complexityStats.put("min", stats.getMin());
            complexityStats.put("max", stats.getMax());
            complexityStats.put("avg", Math.round(stats.getAverage() * 10.0) / 10.0);
        }
        Map<String, Long> countByKind = entries.stream()
                .collect(Collectors.groupingBy(ManifestEntry::getKind, Collectors.counting()));
        complexityStats.put("countByKind", countByKind);

        // Assemble full report
        Map<String, Object> report = new LinkedHashMap<>();
        report.put("selectionSummary", selectionSummary);
        report.put("rankedTargets", rankedTargets);
        report.put("complexityStats", complexityStats);
        report.put("totalTargets", entries.size());
        report.put("totalAdded", totalAdded);
        report.put("totalSkipped", totalSkipped);
        report.put("aiCallsAttempted", aiCallsAttempted);
        report.put("aiCallsSucceeded", aiCallsSucceeded);
        report.put("aiCallsFailed", aiCallsFailed);
        report.put("validationFailed", validationFailed);
        report.put("files", fileReports);
        return report;
    }

    private InjectionResult processFile(Path javaFile, List<ManifestEntry> entries,
                                        int currentAiCalls,
                                        Map<ManifestEntry, String> outcomes,
                                        Map<ManifestEntry, String> generatedTexts) throws IOException {
        CompilationUnit cu = StaticJavaParser.parse(javaFile);
        LexicalPreservingPrinter.setup(cu);

        InjectionResult result = new InjectionResult();
        result.aiCallsAttempted = currentAiCalls;

        for (ManifestEntry entry : entries) {
            if (entry.isHasJavadoc()) {
                outcomes.put(entry, "alreadyDocumented");
                continue;
            }

            String javadoc = null;
            boolean usedAi = false;

            if (aiClient != null && result.aiCallsAttempted < maxAiCalls) {
                try {
                    String context = ContextExtractor.extractContext(javaFile,
                        entry.getRange().getBeginLine() - 1, entry.getRange().getEndLine() - 1);

                    result.aiCallsAttempted++;
                    String aiJavadoc = aiClient.generateJavadoc(entry, context);

                    JavadocValidator.ValidationResult validation = JavadocValidator.validate(aiJavadoc, entry);

                    if (validation.isValid()) {
                        javadoc = extractJavadocContent(aiJavadoc);
                        result.aiCallsSucceeded++;
                        usedAi = true;
                    } else {
                        System.err.println("Validation failed for " + entry.getFqcn() + ": " + validation.getErrorMessage());
                        result.validationFailed++;
                    }
                } catch (Exception e) {
                    System.err.println("AI call failed for " + entry.getFqcn() + ": " + e.getMessage());
                    result.aiCallsFailed++;
                }
            }

            if (javadoc == null) {
                javadoc = generateFallbackJavadoc(entry, cu);
            }

            if (javadoc != null) {
                generatedTexts.put(entry, javadoc);
                boolean injected = injectJavadoc(cu, entry, javadoc);
                if (injected) {
                    result.added++;
                    outcomes.put(entry, usedAi ? "aiAdded" : "templateAdded");
                } else {
                    outcomes.put(entry, "notInjected");
                }
            } else {
                outcomes.put(entry, "notInjected");
            }
        }

        if (result.added > 0) {
            Files.writeString(javaFile, LexicalPreservingPrinter.print(cu));
        }

        return result;
    }

    private String extractJavadocContent(String fullJavadoc) {
        fullJavadoc = fullJavadoc.trim();
        if (fullJavadoc.startsWith("/**") && fullJavadoc.endsWith("*/")) {
            fullJavadoc = fullJavadoc.substring(3, fullJavadoc.length() - 2).trim();
        }

        String[] lines = fullJavadoc.split("\n");
        StringBuilder cleaned = new StringBuilder();
        for (String line : lines) {
            line = line.trim();
            if (line.startsWith("*")) {
                line = line.substring(1).trim();
            }
            cleaned.append(line).append("\n");
        }

        return cleaned.toString().trim();
    }

    private String generateFallbackJavadoc(ManifestEntry entry, CompilationUnit cu) {
        if ("CLASS".equals(entry.getKind())) {
            return cu.findAll(ClassOrInterfaceDeclaration.class).stream()
                .filter(cls -> cls.getBegin().isPresent() && cls.getBegin().get().line == entry.getRange().getBeginLine())
                .findFirst()
                .map(cls -> JavadocGenerator.generateClassJavadoc(cls.getNameAsString()))
                .orElse(null);
        } else if ("METHOD".equals(entry.getKind())) {
            return cu.findAll(MethodDeclaration.class).stream()
                .filter(method -> method.getBegin().isPresent() && method.getBegin().get().line == entry.getRange().getBeginLine())
                .findFirst()
                .map(JavadocGenerator::generateMethodJavadoc)
                .orElse(null);
        } else if ("CONSTRUCTOR".equals(entry.getKind())) {
            return cu.findAll(ConstructorDeclaration.class).stream()
                .filter(ctor -> ctor.getBegin().isPresent() && ctor.getBegin().get().line == entry.getRange().getBeginLine())
                .findFirst()
                .map(JavadocGenerator::generateConstructorJavadoc)
                .orElse(null);
        } else if ("ENUM".equals(entry.getKind())) {
            return cu.findAll(EnumDeclaration.class).stream()
                .filter(enm -> enm.getBegin().isPresent() && enm.getBegin().get().line == entry.getRange().getBeginLine())
                .findFirst()
                .map(enm -> JavadocGenerator.generateEnumJavadoc(enm.getNameAsString()))
                .orElse(null);
        }
        return null;
    }

    private boolean injectJavadoc(CompilationUnit cu, ManifestEntry entry, String javadocContent) {
        if ("CLASS".equals(entry.getKind())) {
            return injectClassJavadoc(cu, entry, javadocContent);
        } else if ("METHOD".equals(entry.getKind())) {
            return injectMethodJavadoc(cu, entry, javadocContent);
        } else if ("CONSTRUCTOR".equals(entry.getKind())) {
            return injectConstructorJavadoc(cu, entry, javadocContent);
        } else if ("ENUM".equals(entry.getKind())) {
            return injectEnumJavadoc(cu, entry, javadocContent);
        }
        return false;
    }

    private boolean injectClassJavadoc(CompilationUnit cu, ManifestEntry entry, String javadocContent) {
        return cu.findAll(ClassOrInterfaceDeclaration.class).stream()
                .filter(cls -> cls.getBegin().isPresent() && cls.getBegin().get().line == entry.getRange().getBeginLine())
                .filter(cls -> !cls.getJavadocComment().isPresent())
                .findFirst()
                .map(cls -> {
                    cls.setJavadocComment(formatJavadoc(javadocContent, 0));
                    return true;
                })
                .orElse(false);
    }

    private boolean injectMethodJavadoc(CompilationUnit cu, ManifestEntry entry, String javadocContent) {
        return cu.findAll(MethodDeclaration.class).stream()
                .filter(method -> method.getBegin().isPresent() && method.getBegin().get().line == entry.getRange().getBeginLine())
                .filter(method -> !method.getJavadocComment().isPresent())
                .findFirst()
                .map(method -> {
                    method.setJavadocComment(formatJavadoc(javadocContent, 4));
                    return true;
                })
                .orElse(false);
    }

    private boolean injectConstructorJavadoc(CompilationUnit cu, ManifestEntry entry, String javadocContent) {
        return cu.findAll(ConstructorDeclaration.class).stream()
                .filter(ctor -> ctor.getBegin().isPresent() && ctor.getBegin().get().line == entry.getRange().getBeginLine())
                .filter(ctor -> !ctor.getJavadocComment().isPresent())
                .findFirst()
                .map(ctor -> {
                    ctor.setJavadocComment(formatJavadoc(javadocContent, 4));
                    return true;
                })
                .orElse(false);
    }

    private boolean injectEnumJavadoc(CompilationUnit cu, ManifestEntry entry, String javadocContent) {
        return cu.findAll(EnumDeclaration.class).stream()
                .filter(enm -> enm.getBegin().isPresent() && enm.getBegin().get().line == entry.getRange().getBeginLine())
                .filter(enm -> !enm.getJavadocComment().isPresent())
                .findFirst()
                .map(enm -> {
                    enm.setJavadocComment(formatJavadoc(javadocContent, 0));
                    return true;
                })
                .orElse(false);
    }

    private String formatJavadoc(String content, int indent) {
        String indentStr = " ".repeat(indent);
        String[] lines = content.split("\n");
        StringBuilder sb = new StringBuilder("\n");
        for (int i = 0; i < lines.length; i++) {
            sb.append(indentStr).append(" * ").append(lines[i]).append("\n");
        }
        sb.append(indentStr).append(" ");
        return sb.toString();
    }

    private void writeMetricsCsv(List<ManifestEntry> entries,
                                  Map<ManifestEntry, String> outcomes,
                                  Map<ManifestEntry, String> generatedTexts,
                                  Path csvPath) throws IOException {
        Set<String> knownNames = MetricsComputer.buildKnownNames(manifest);

        StringBuilder csv = new StringBuilder();
        csv.append("fqcn,kind,outcome," +
                   "completeness,required_sections,present_sections,missing_sections," +
                   "truthfulness,mentioned_entities,verified_entities," +
                   "helpfulness,helpfulness_clarity,helpfulness_depth," +
                   "helpfulness_param_utility,helpfulness_guidance\n");

        int metricsComputed = 0;
        for (ManifestEntry entry : entries) {
            String outcome = outcomes.getOrDefault(entry, "notInjected");
            if (!"aiAdded".equals(outcome) && !"templateAdded".equals(outcome)) continue;

            String text = generatedTexts.getOrDefault(entry, "");

            MetricsComputer.CompletenessResult comp = MetricsComputer.computeCompleteness(entry, text);
            MetricsComputer.TruthfulnessResult truth = MetricsComputer.computeTruthfulness(text, knownNames);

            double[] help = null;
            if (aiClient != null && "aiAdded".equals(outcome) && entry.getMemberSignature() != null) {
                help = aiClient.evaluateHelpfulness(text, entry.getMemberSignature());
            }

            csv.append(csvEscape(entry.getFqcn())).append(",");
            csv.append(entry.getKind()).append(",");
            csv.append(outcome).append(",");
            csv.append(String.format("%.2f", comp.score())).append(",");
            csv.append(comp.required()).append(",");
            csv.append(comp.present()).append(",");
            csv.append(csvEscape(String.join("|", comp.missing()))).append(",");
            csv.append(String.format("%.2f", truth.score())).append(",");
            csv.append(truth.mentioned()).append(",");
            csv.append(truth.verified()).append(",");
            if (help != null) {
                double avg = (help[0] + help[1] + help[2] + help[3]) / 4.0;
                csv.append(String.format("%.2f,%.2f,%.2f,%.2f,%.2f", avg, help[0], help[1], help[2], help[3]));
            } else {
                csv.append(",,,," );
            }
            csv.append("\n");
            metricsComputed++;
        }

        Files.writeString(csvPath, csv.toString());
        System.out.println("Metrics computed for " + metricsComputed + " entries → " + csvPath);
    }

    private String csvEscape(String value) {
        if (value == null) return "";
        if (value.contains(",") || value.contains("\"") || value.contains("\n")) {
            return "\"" + value.replace("\"", "\"\"") + "\"";
        }
        return value;
    }

    private static class InjectionResult {
        int added = 0;
        int aiCallsAttempted = 0;
        int aiCallsSucceeded = 0;
        int aiCallsFailed = 0;
        int validationFailed = 0;
    }
}

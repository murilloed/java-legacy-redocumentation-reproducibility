package br.unb.cic.docsgenerator.ai;

import br.unb.cic.docsgenerator.manifest.ManifestEntry;

public interface JavadocClient {
    String generateJavadoc(ManifestEntry entry, String contextSnippet);

    /**
     * Evaluates javadoc quality on four dimensions (1–5 scale).
     * Returns [clarity, depth, paramUtility, guidance], or null on failure.
     */
    double[] evaluateHelpfulness(String javadocText, String signature);

    void close();
}

package br.unb.cic.docsgenerator.javadoc;

import br.unb.cic.docsgenerator.ai.PrioritizationClient;
import br.unb.cic.docsgenerator.manifest.ManifestEntry;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class TargetSelector {

    public static SelectionResult select(
            List<ManifestEntry> entries,
            boolean useStructuralFilter,
            boolean useMetricsPrioritization,
            int minComplexityScore,
            boolean useLLMPrioritization,
            PrioritizationClient llmClient,
            int maxTargets) {

        List<String> strategies = new ArrayList<>();

        // Start: all undocumented entries
        List<ManifestEntry> candidates = entries.stream()
                .filter(e -> !e.isHasJavadoc())
                .toList();

        int undocumented = candidates.size();
        int afterStructuralFilter = -1;
        if (useStructuralFilter) {
            strategies.add("structuralFilter");
            candidates = candidates.stream()
                    .filter(e -> !e.isSimpleDataClass())
                    .toList();
            afterStructuralFilter = candidates.size();
        }

        int afterMetrics = -1;
        if (useMetricsPrioritization) {
            strategies.add("metricsPrioritization");
            candidates = candidates.stream()
                    .filter(e -> e.getComplexityScore() >= minComplexityScore)
                    .sorted(Comparator.comparingInt(ManifestEntry::getComplexityScore).reversed())
                    .toList();
            afterMetrics = candidates.size();
        }

        int afterLLM = -1;
        if (useLLMPrioritization && llmClient != null && !candidates.isEmpty()) {
            strategies.add("llmPrioritization");
            System.out.println("Running LLM prioritization on " + candidates.size() + " candidates...");
            candidates = llmClient.prioritize(candidates);
            afterLLM = candidates.size();
            System.out.println("LLM prioritization returned " + afterLLM + " targets");
        }

        if (maxTargets > 0 && candidates.size() > maxTargets) {
            System.out.println("Limiting to top " + maxTargets + " targets (from " + candidates.size() + " ranked candidates)");
            candidates = candidates.subList(0, maxTargets);
        }

        return new SelectionResult(candidates, entries.size(), undocumented, afterStructuralFilter, afterMetrics, afterLLM, strategies);
    }

    public static List<ManifestEntry> selectTargetsNeedingJavadoc(List<ManifestEntry> entries) {
        return entries.stream()
                .filter(e -> !e.isHasJavadoc())
                .toList();
    }
}

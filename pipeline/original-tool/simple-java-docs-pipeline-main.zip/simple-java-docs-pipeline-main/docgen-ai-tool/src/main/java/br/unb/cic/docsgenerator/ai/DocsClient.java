package br.unb.cic.docsgenerator.ai;

import br.unb.cic.docsgenerator.bedrock.DocsContext;

public interface DocsClient {
    String generateReadme(DocsContext context);
    String generateArchitecture(DocsContext context);
    String generateApi(DocsContext context);
    String generateManualTestsForController(DocsContext.ControllerContext controllerContext, String language);
    void close();
}

package br.unb.cic.docsgenerator.javadoc;

import br.unb.cic.docsgenerator.manifest.ManifestEntry;

import java.util.List;

public record SelectionResult(
        List<ManifestEntry> entries,
        int totalScanned,
        int undocumented,            // count after !hasJavadoc filter, before any strategy
        int afterStructuralFilter,   // -1 when strategy not applied
        int afterMetrics,            // -1 when strategy not applied
        int afterLLM,                // -1 when strategy not applied
        List<String> strategiesApplied
) {}
